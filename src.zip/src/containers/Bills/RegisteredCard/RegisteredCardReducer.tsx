import {
  DeleteRegisteredCardAction,
  DeleteRegisteredCardActionType
} from './RegisteredCardAction';
import {DeleteRegisteredCardPayload} from '../../../model/types.d';

export interface InitialState {
  deleteRegisteredCard: DeleteRegisteredCardPayload | null;
  deleteRegisteredCardError: Error | null;
}

const initialState: InitialState = {
  deleteRegisteredCard: null,
  deleteRegisteredCardError: null
};

export default (state = initialState, action: DeleteRegisteredCardAction) => {
  switch (action.type) {
    case DeleteRegisteredCardActionType.DELETE_REGISTERED_CARD_SUCCESS:
      return {
        ...state,
        deleteRegisteredCard: action.payload
      };
    case DeleteRegisteredCardActionType.DELETE_REGISTERED_CARD_ERROR:
      return {
        ...state,
        deleteRegisteredCardError: action.payload
      };
    case DeleteRegisteredCardActionType.DELETE_REGISTERED_CARD_RESET:
      return initialState;
    default:
      return state;
  }
};