import {
  BillsActionType,
  FetchServicesAction,
  FetchServicesErrorAction
} from './SubscriptionDetailAction';
import {Account} from '../../model/types.d';

export interface InitialState {
  account: Account | null;
  accountError: Error | null;
}

const initialState: InitialState = {
  account: null,
  accountError: null
};

type BillsAction = FetchServicesAction |
FetchServicesErrorAction

export default (state = initialState, action: BillsAction) => {
  switch (action.type) {
    case BillsActionType.FETCH_SERVICES_INFO:
      return {
        ...state,
        account: action.payload
      };
    case BillsActionType.FETCH_SERVICES_INFO_ERROR:
      return {
        ...state,
        accountError: action.payload
      };
    default:
      return state;
  }
};
