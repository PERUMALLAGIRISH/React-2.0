import * as React from 'react';
import {Radio} from '../../../components/Radio/Radio';
import {Loader} from '../../../components/Loader/Loader';
import {Button} from '../../../components/Form/Button/Button';
import {OrderAccountStatementInput, OrderAccountStatementPayload, Optional, AccountStatementMethod, PayloadStatus} from '../../../model/types.d';
import {Success} from '../../../components/Success/Success';
import {Popup} from '../../../components/Popup/Popup';
import I18n from '../../../utils/helper/I18n';
import {BillsDeliveryConstants} from '../BillsConstants';

interface BillsOrderAccountStatementState {
  accountStatementValue: string;
  isLoading: boolean;
  formStatus: boolean;
  isTooltip: boolean;
  selectedTooltip: string;
}

interface BillsOrderAccountStatementProps {
  billingAddress: string[];
  email: Optional<string>;
  orderAccountStatementPayload: OrderAccountStatementPayload;
  orderAccountStatementPayloadError: Error;
  imgOverallSuccessMail?: string;
  orderAccountStatementRequest: (orderAccountStatementInput: OrderAccountStatementInput) => void;
  showHideAccountStatementPopup: (event: React.MouseEvent<HTMLButtonElement>) => void;
  resetOrderAccountStatement: () => void;
}

interface ToolTipData {
  title?: string;
  text?: string;
  buttonLabel?: string
}

export class BillsOrderAccountStatement extends React.Component<BillsOrderAccountStatementProps, BillsOrderAccountStatementState> {
  constructor(props: BillsOrderAccountStatementProps) {
      super(props);
      this.state = {
        accountStatementValue: '',
        isLoading: false,
        formStatus: true,
        isTooltip: false,
        selectedTooltip: ''
      }
  }

  static getDerivedStateFromProps(nextProps: BillsOrderAccountStatementProps, prevState: BillsOrderAccountStatementState): any | null {
    if ((nextProps.orderAccountStatementPayload || nextProps.orderAccountStatementPayloadError) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  componentWillUnmount(): void {
    const {resetOrderAccountStatement} = this.props;
    resetOrderAccountStatement();
  }

  handleOrderStatement = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {accountStatementValue} = this.state;
    const {orderAccountStatementRequest} = this.props;
    event.preventDefault();
    let accountStatement: AccountStatementMethod = AccountStatementMethod.EMAIL;
    if (accountStatementValue === AccountStatementMethod.POST) {
      accountStatement = AccountStatementMethod.POST;
    }
    const requestAccountStatementInput: OrderAccountStatementInput = {accountStatementMethod: accountStatement};
    orderAccountStatementRequest(requestAccountStatementInput);
    this.setState({
      formStatus: false,
      isLoading: true
    });
  }

  handleChange = (id: string): void => {
    this.setState({
      accountStatementValue: id
    });
  }

  orderAccountStatementSuccess(): JSX.Element {
    const {orderAccountStatementPayload, orderAccountStatementPayloadError, imgOverallSuccessMail, showHideAccountStatementPopup} = this.props;
    let label: string = '';
    let title: string = '';
    if (orderAccountStatementPayloadError || (orderAccountStatementPayload && orderAccountStatementPayload.payloadStatus === PayloadStatus.NOK)) {
      label = I18n.translate('BillsOrderAccountStatement.Error.Label');
      title = I18n.translate('BillsOrderAccountStatement.Error.Title');
    } else if (orderAccountStatementPayload && orderAccountStatementPayload.payloadStatus === PayloadStatus.OK) {
      label = I18n.translate('BillsOrderAccountStatement.Success.Label');
      title = I18n.translate('BillsOrderAccountStatement.Success.Title');
    }
    return (
      <Success
        imageSource={imgOverallSuccessMail || ''}
        heading = {title}
        text = {label}
        button = {I18n.translate('BillsOrderAccountStatement.Close.Button.Label')}
        handleClick = {showHideAccountStatementPopup}
      />
    );
  }

  showHideTooltip = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {isTooltip} = this.state;
    const element: HTMLButtonElement = event.currentTarget as HTMLButtonElement;
    const id: string = element.id;
    event.persist();
    this.setState({
      isTooltip: !isTooltip,
      selectedTooltip: id
    });
  }

  renderEmailField = (): JSX.Element => {
    const {email} = this.props;
    return (
      <div className='price_bottom_aligned product_item product_item--mobile-price_below'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <Radio
              id= {BillsDeliveryConstants.EMAIL}
              name= {BillsDeliveryConstants.ORDER_ACCOUNT}
              htmlFor= {BillsDeliveryConstants.EMAIL}
              className= {'text-small bold inline text-left tooltip'}
              onChange= {(e: React.ChangeEvent<HTMLInputElement>) => this.handleChange(AccountStatementMethod.EMAIL)}
              disabled= {email ? false : true}
              label= {I18n.translate('BillsOrderAccountStatement.Email.Statement.Label')}
              onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.showHideTooltip(e)}
            />
            <div className='text-small grey-brown text-left align_with_radio_button--mobile'>
            {(!email) ? (I18n.translate('BillsOrderAccountStatement.Email.NotRegister.Label') ) : `${I18n.translate('BillsOrderAccountStatement.Email.Title')} ${email}`}
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'>{I18n.translate('BillsOrderAccountStatement.Email.Cost.Title')}</div>
        </div>
      </div>
    );
  }

  renderPostField = (): JSX.Element => {
    const {billingAddress} = this.props;
    return(
      <div className='price_bottom_aligned product_item product_item--mobile-price_below product_item__stiched_bellow'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <Radio
              id= {BillsDeliveryConstants.POST}
              name= {BillsDeliveryConstants.ORDER_ACCOUNT}
              htmlFor= {BillsDeliveryConstants.POST}
              className= {'text-small bold inline text-left tooltip'}
              onChange= {(e: React.ChangeEvent<HTMLInputElement>) => this.handleChange(AccountStatementMethod.POST)}
              label= {I18n.translate('BillsOrderAccountStatement.Post.MailStatement.Label')}
              onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.showHideTooltip(e)}
            />
            <div className='text-small grey-brown text-left align_with_radio_button--mobile'>
              {I18n.translate('BillsOrderAccountStatement.Post.Letter.Text')}{billingAddress}
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'>{I18n.translate('BillsOrderAccountStatement.Post.Cost.Title')}</div>
        </div>
      </div>
    )
  }

  renderButton(): JSX.Element {
    const {showHideAccountStatementPopup} = this.props;
    const {accountStatementValue} = this.state;
    return(
      <div className='form-item'>
        <div className='form-item__button full_width_on_mobile'>
          <Button
            className='button extra_wide full_width_on_mobile transparent_background'
            label={I18n.translate('BillsOrderAccountStatement.Cancel.Button.Label')}
            handleClick={showHideAccountStatementPopup}
          />
          <Button
            className='button button--flex extra_wide full_width_on_mobile'
            label={I18n.translate('BillsOrderAccountStatement.ConfirmOrder.Label')}
            handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.handleOrderStatement(e)}
            disabled = {accountStatementValue ? false : true}
          />
        </div>
      </div>
    )
  }

  getTooltipData = (id: string) => {
    const data: ToolTipData = {};
    switch (id) {
      case BillsDeliveryConstants.EMAIL:
        data.title = I18n.translate('BillsOrderAccountStatement.Email.Label');
        data.text = I18n.translate('BillsOrderAccountStatement.Email.SentEmail.Text');
        data.buttonLabel = I18n.translate('BillsOrderAccountStatement.Close.Button.Label');
        return data;
      case BillsDeliveryConstants.POST:
        data.title = I18n.translate('BillsOrderAccountStatement.Post.Label');
        data.text = I18n.translate('BillsOrderAccountStatement.Post.SentPost.Text');
        data.buttonLabel = I18n.translate('BillsOrderAccountStatement.Close.Button.Label');
        return data;
      default:
        data.title = '';
        data.text = '';
        data.buttonLabel = I18n.translate('BillsOrderAccountStatement.Close.Button.Label');
        return data;
    }
  }

  renderTooltip(): JSX.Element {
    const {selectedTooltip} = this.state;
    const data: ToolTipData = this.getTooltipData(selectedTooltip);
    return (
      <Popup
        title = {data.title}
        data = {[data!.text!]}
        buttonLabel = {data.buttonLabel}
        onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.showHideTooltip(e)}
      />
    );
  }

  orderAccountStatementForm(): JSX.Element {
    const {isTooltip} = this.state;
    return(
      <React.Fragment>
        {isTooltip ? this.renderTooltip() : null}
        <div className='popup-message-box popup-message-box--free-buttons'>
          <h2 className='title-large'>
            {I18n.translate('BillsOrderAccountStatement.OrderAccount.Statement.Title')}
          </h2>
          <div className='text-small centered-text text-pad-lr-10perc'>
            {I18n.translate('BillsOrderAccountStatement.OrderAccount.StatementSub.Title')}
          </div>
          <div className='vertical_spacer x8'></div>
          {this.renderEmailField()}
          {this.renderPostField()}
          <div className='vertical_spacer x8'></div>
          {this.renderButton()}
        </div>
      </React.Fragment>
    )
  }

  render(): React.ReactNode {
    const {formStatus, isLoading} = this.state;
    return (
      <React.Fragment>
        <div className='overlay'></div>
        <div className='popup__container'>
          <div className='popup'>
            {isLoading ? <Loader /> : null}
            {!formStatus ? this.orderAccountStatementSuccess() : null}
            {formStatus ? this.orderAccountStatementForm() : null}
          </div>
        </div>
      </React.Fragment>
    );
  }
}