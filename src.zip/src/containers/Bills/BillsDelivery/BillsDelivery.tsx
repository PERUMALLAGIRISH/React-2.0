import * as React from 'react';
import {connect} from 'react-redux';
import {ActionCreatorsMapObject, Dispatch, bindActionCreators} from 'redux';
import {Account, BillAnonymizationLevelPayload, BillAnonymizationLevelInput, SetBillDeliveryMethodInput, Service, Optional, BillInfo, BillSettings, BillDeliveryNotification, BillAnonymizationLevel, BillDeliveryMethod, PayloadStatus, PaymentMethodType, SetBillDeliveryMethodPayload} from '../../../model/types.d';
import {fetchBillsInfo, setbillAnonymizationLevel, resetbillAnonymizationLevel, setbillDeliveryMethod, resetbillDeliveryMethod} from '../BillsAction';
import {Select} from '../../../components/Form/Select/Select';
import {Radio} from '../../../components/Radio/Radio';
import {StickyBar} from '../../../components/StickyBar/StickyBar';
import {Success} from '../../../components/Success/Success';
import {Popup} from '../../../components/Popup/Popup';
import {Button} from '../../../components/Form/Button/Button';
import {Loader} from '../../../components/Loader/Loader';
import I18n from '../../../utils/helper/I18n';
import {BillsDeliveryConstants} from '../BillsConstants';
import {BillsRoutes} from '../BillsRoutes.enum';
import {History} from 'history';

export interface BillsDeliveryProps {
  account: Account;
  billAnonymizationLevelPayload: BillAnonymizationLevelPayload;
  imgOverallSuccessMail?: string;
  billAnonymizationLevelPayloadError: Error | null;
  billDeliveryMethodPayload: SetBillDeliveryMethodPayload;
  billDeliveryMethodPayloadError: Error | null;
  setbillAnonymizationLevel: (BillAnonymizationLevelInput: BillAnonymizationLevelInput) =>  Function;
  setbillDeliveryMethod: (SetBillDeliveryMethodInput: SetBillDeliveryMethodInput) => Function;
  resetbillAnonymizationLevel: () => void;
  resetbillDeliveryMethod: () => void;
  fetchBillsInfo: () => void;
  history: History;
  location: {
    state: Account
  };
}

interface BillsDeliveryState {
  deliveryForm: any;
  renderStatus: boolean;
  isPopup: boolean,
  selectedPopup: string,
  smsShowLength: number;
  smsShowHide: string;
  smsNumberDisabled: boolean;
  isChecked: boolean[];
  isLoading: boolean;
  defaultCheckbox: boolean;
}

class BillsDelivery extends React.Component<BillsDeliveryProps, BillsDeliveryState> {
  constructor(props: BillsDeliveryProps) {
    super(props);
    this.state = {
      deliveryForm: {
        displayNumberFormat: '',
        displayNumberName: '',
        selectedOption: '',
        smsNotificationNumber: [],
      },
      renderStatus: true,
      isPopup: false,
      selectedPopup: '',
      smsShowLength: 6,
      smsShowHide: I18n.translate('BillsDelivery.ShowMore.Label'),
      smsNumberDisabled: false,
      isChecked: [],
      isLoading: true,
      defaultCheckbox: true
    }
  }

  static getDerivedStateFromProps(nextProps: BillsDeliveryProps, prevState: BillsDeliveryState): any | null {
    if ((nextProps.billDeliveryMethodPayload || nextProps.billDeliveryMethodPayloadError || nextProps.billAnonymizationLevelPayload || nextProps.billAnonymizationLevelPayloadError || prevState.renderStatus) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  public componentDidMount(): void {
    const {account, fetchBillsInfo} = this.props;
    fetchBillsInfo();
    let defaultContactNumberCount: number;
    if (account) {
      const services: (Optional<Service>)[] = account.services;
      const billInfo: Optional<BillInfo> = account.billInfo;
      const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
      const billAnonymizationLevel: Optional<BillAnonymizationLevel> = billSettings && billSettings.billAnonymizationLevel;
      const billDeliveryMethod: Optional<BillDeliveryMethod> = billSettings && billSettings.billDeliveryMethod;
      const billDeliveryNotification: Optional<BillDeliveryNotification> = billSettings && billSettings.billDeliveryNotification;
      const billDeliveryNotificationContactNumbers: Optional<(Optional<string>)[]> = billDeliveryNotification && billDeliveryNotification.contactNumbers;
      this.setIscheckedDefault();
      if ((services ? services.length : 0) > 6) {
        defaultContactNumberCount = services ? 6 : 0;
      } else  {
        defaultContactNumberCount = services ? services.length : 0;
      }
      const deliveryForm: any = {...this.state.deliveryForm}
      deliveryForm['displayNumberFormat'] = billAnonymizationLevel;
      deliveryForm['selectedOption'] = billDeliveryMethod;
      deliveryForm['smsNotificationNumber'] = billDeliveryNotificationContactNumbers ? billDeliveryNotificationContactNumbers : [];
      this.setState({deliveryForm, smsShowLength: defaultContactNumberCount});
    }
    window.scrollTo(0, 0);
  }

  componentWillUnmount(): void {
    const {resetbillAnonymizationLevel, resetbillDeliveryMethod} = this.props;
    resetbillAnonymizationLevel();
    resetbillDeliveryMethod();
  }

  /* render Spineer if isLoading = true*/
  renderLoader(): JSX.Element | null {
    const {isLoading} = this.state;
    if (isLoading) {
      return (
        <Loader />
      );
    }
    return null;
  }

  setIscheckedDefault = () => {
    const {account} = this.props;
    const {isChecked} = this.state;
    if (account) {
      const services: (Optional<Service>)[] = account.services;
      const billInfo: Optional<BillInfo> = account.billInfo;
      const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
      const billDeliveryNotification: Optional<BillDeliveryNotification> = billSettings && billSettings.billDeliveryNotification;
      const billDeliveryNotificationContactNumbers: Optional<(Optional<string>)[]> = billDeliveryNotification && billDeliveryNotification.contactNumbers;
      const servicesIds: string[] = services.map((ids: any ) => { return ids.id});
      if (servicesIds && billDeliveryNotificationContactNumbers) {
        for (let i: number = 0; i < servicesIds.length;  i += 2) {
          billDeliveryNotificationContactNumbers && billDeliveryNotificationContactNumbers.includes(servicesIds[i]) ? isChecked[i] = true : isChecked[i] = false;
          billDeliveryNotificationContactNumbers && billDeliveryNotificationContactNumbers.includes(servicesIds[i + 1]) ? isChecked[i + 1] = true : isChecked[i + 1] = false;
        }
        this.setState({isChecked});
      } else {
        this.setState({defaultCheckbox: false, smsNumberDisabled: true});
      }
    }
  }

  getDisplayNumberOptions(): string[] {
    const {account} = this.props;
    const displayNumberOptions:  Array<any> = [];
    const displayOption: object[] = [{name: I18n.translate('BillsDelivery.DisplayNumber.None.Label'), value: BillAnonymizationLevel.NONE}, {name: I18n.translate('BillsDelivery.DisplayNumber.Option2.Name'), value: BillAnonymizationLevel.LAST_2_DIGITS}, {name: I18n.translate('BillsDelivery.DisplayNumber.Option4.Name'), value: BillAnonymizationLevel.LAST_4_DIGITS}];
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const billAnonymizationLevel: Optional<BillAnonymizationLevel> = billSettings && billSettings.billAnonymizationLevel;
    if (billAnonymizationLevel) {
      const defaultDisplayNumber: object | undefined = displayOption.find((key: any) => { return key.value === billAnonymizationLevel});
      displayNumberOptions.push(defaultDisplayNumber);
    }
    displayOption.forEach((option: any) => {
      if (option.value !== billAnonymizationLevel) {
        displayNumberOptions.push(option)
      }
    });
    return displayNumberOptions;
  }

  getPopupData = (name: string) => {
    const data: any = {};
    switch (name) {
      case BillsDeliveryConstants.EMAIL_WITH_LINK:
        data.title = I18n.translate('BillsDelivery.EmailWith.BillLink.Title')
        data.text = I18n.translate('BillsDelivery.DeliveryMethod.Direct.Link.Title')
        data.buttonLabel = I18n.translate('BillsDelivery.Ok.Button.Label');
        return data;
      case BillsDeliveryConstants. EMAIL_WITH_PDF:
        data.title = I18n.translate('BillsDelivery.EmailWith.BillPDF.Title')
        data.text = I18n.translate('BillsDelivery.DeliveryMethod.Email.Pdf.Title')
        data.buttonLabel = I18n.translate('BillsDelivery.Ok.Button.Label');
        return data;
      case BillsDeliveryConstants.PAPERBILL_WITHOUT_CALL:
        data.title = I18n.translate('BillsDelivery.PaperBillWithout.Call.Title')
        data.text = I18n.translate('BillsDelivery.DeliveryPaper.BillWithout.Call.Text');
        data.buttonLabel = I18n.translate('BillsDelivery.Ok.Button.Label');
        return data;
      case BillsDeliveryConstants.PAPERBILL_WITH_CALL:
        data.title = I18n.translate('BillsDelivery.PaperBillWith.Call.Title');
        data.text = I18n.translate('BillsDelivery.DeliveryPaper.BillWith.Call.Text');
        data.buttonLabel = I18n.translate('BillsDelivery.Ok.Button.Label');
        return data;
      default:
        data.title = '';
        data.text = '';
        data.buttonLabel = I18n.translate('BillsDelivery.Ok.Button.Label');
        return data;
    }
  }

  displayPopup(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
    const element: HTMLButtonElement = event.currentTarget as HTMLButtonElement;
    const {isPopup} = this.state;
    this.setState({
      isPopup: !isPopup,
      selectedPopup: element.id
    });
  }

  renderPopup = (): JSX.Element => {
    const {selectedPopup} = this.state;
    const data: any = this.getPopupData(selectedPopup);
    return (
      <Popup
        title = {data.title}
        data = {[data.text]}
        buttonLabel = {data.buttonLabel}
        onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}
      />
    );
  }

  displayNumberFormatonChange = (value: string): void => {
    const selectedDisplayNumberOption: any = this.getDisplayNumberOptions().find((option: any) => option.value === value );
    const deliveryForm: any = {...this.state.deliveryForm};
    deliveryForm['displayNumberFormat'] = value;
    deliveryForm['displayNumberName'] = selectedDisplayNumberOption.name;
    this.setState({deliveryForm});
  }

  deliveryMethodOptionChange = (id: string): void => {
    const deliveryForm: any = {...this.state.deliveryForm};
    deliveryForm['selectedOption'] = id;
    this.setState({deliveryForm});
  }

  saveDeliveryMethod = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {setbillAnonymizationLevel, setbillDeliveryMethod} = this.props;
    const {deliveryForm, defaultCheckbox} = this.state;
    const setbillAnonymizationLevelInput: BillAnonymizationLevelInput = {billAnonymizationLevel: deliveryForm.displayNumberFormat};
    const setbillDeliveryMethodPost: SetBillDeliveryMethodInput = {billDeliveryMethod: deliveryForm.selectedOption, billDeliveryNotification : {emailAddress: '', contactNumbers: defaultCheckbox ? deliveryForm.smsNotificationNumber : []}};
    setbillAnonymizationLevel(setbillAnonymizationLevelInput);
    setbillDeliveryMethod(setbillDeliveryMethodPost);
    this.setState({isLoading: true, renderStatus: false});
  }

  deliveryMethodSuccess = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {history} = this.props;
    history.push({
      pathname: BillsRoutes.BILLS_HOME
    })
  }

  billDeliveryMethodSuccess(): JSX.Element | null {
    const {billAnonymizationLevelPayload, billAnonymizationLevelPayloadError, billDeliveryMethodPayload, billDeliveryMethodPayloadError, imgOverallSuccessMail} = this.props;
    const {renderStatus} = this.state;
    let label: string = '';
    let title: string = '';
    if (billAnonymizationLevelPayloadError && billDeliveryMethodPayloadError || ((billAnonymizationLevelPayload && billAnonymizationLevelPayload ? billAnonymizationLevelPayload.payloadStatus === PayloadStatus.NOK : '') && (billDeliveryMethodPayload ? billDeliveryMethodPayload.payloadStatus === PayloadStatus.NOK : ''))) {
      label = I18n.translate('BillsDelivery.PaymentMethod.Error.Label');
      title = I18n.translate('BillsDelivery.PaymentMethod.Error.Title');
    } else if (billAnonymizationLevelPayload && billDeliveryMethodPayload || ((billAnonymizationLevelPayload && billAnonymizationLevelPayload ? billAnonymizationLevelPayload.payloadStatus === PayloadStatus.OK : '') && (billDeliveryMethodPayload ? billDeliveryMethodPayload.payloadStatus === PayloadStatus.OK : ''))) {
      label = I18n.translate('BillsDelivery.DeliveryFormat.Success.Text');
      title = I18n.translate('BillsDelivery.DeliveryFormat.Success.Title');
    } else if (billAnonymizationLevelPayload && !billDeliveryMethodPayload || (billAnonymizationLevelPayload && billAnonymizationLevelPayload.payloadStatus === PayloadStatus.OK)) {
      label = I18n.translate('BillsDelivery.DeliveryMethod.SMSError.Text');
      title = I18n.translate('BillsDelivery.DeliveryFormat.Success.Title');
    } else if (billDeliveryMethodPayload && !billAnonymizationLevelPayload || (billDeliveryMethodPayload && billDeliveryMethodPayload.payloadStatus === PayloadStatus.OK)) {
      label = I18n.translate('BillsDelivery.DisplayNumber.Error.Text');
      title = I18n.translate('BillsDelivery.DeliveryFormat.Success.Title');
    }
    if (!renderStatus) {
      return (
        <Success
          imageSource={imgOverallSuccessMail || ''}
          heading = {title}
          text = {label}
          button = {I18n.translate('BillsDelivery.BackToBills.Label')}
          href = {''}
          handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.deliveryMethodSuccess(e)}
          />
        );
    }
    return null;
  }

  smsListShowHide = (value: string, contactNumber: Optional<(Optional<string>)[]>): any => {
    const {smsShowHide} = this.state;
    if (smsShowHide === BillsDeliveryConstants.SHOW_MORE &&  (contactNumber ? contactNumber.length : 0) > 6) {
      this.setState({
        smsShowLength: contactNumber ? contactNumber.length : 0,
        smsShowHide: value === BillsDeliveryConstants.SHOW_MORE ? I18n.translate('BillsDelivery.Showfewer.Label') : I18n.translate('BillsDelivery.ShowMore.Label')
      })
    } else  {
      this.setState({
        smsShowLength: contactNumber ? 6 : 0,
        smsShowHide: value === BillsDeliveryConstants.SHOW_MORE ? I18n.translate('BillsDelivery.Showfewer.Label') : I18n.translate('BillsDelivery.ShowMore.Label')
      })
    }
  }

  disableSMSNotificationOption = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const {smsNumberDisabled, defaultCheckbox} = this.state;
    this.setState({
      smsNumberDisabled: smsNumberDisabled ? false : true,
      defaultCheckbox: !defaultCheckbox
    });
  }

  contactNumberCheck = (index: number, value: any): void => {
    const {isChecked} = this.state;
    const {smsNotificationNumber} = this.state.deliveryForm;
    isChecked[index] = !isChecked[index];
    if (isChecked[index]) {
      const smsNumberPush: string[] = smsNotificationNumber.find((phoneNumber: string) => {
        return phoneNumber === value;
      });
      if (!smsNumberPush) {
        smsNotificationNumber.push(value)
      }
    } else {
      const smsNumberPop: string[] = smsNotificationNumber.filter((phoneNumber: string) => {
        return phoneNumber !== value;
      });
      const deliveryForm: any = {...this.state.deliveryForm}
      deliveryForm['smsNotificationNumber'] = smsNumberPop;
      this.setState({deliveryForm});
    }
    this.setState({isChecked})
  }

  ebillHelp = (): void => {
    window.open(I18n.translate('BillsDelivery.EbillHelp.Link.Text'), '_blank');
  }

  renderContactNumber = (serviceIds: string[], i: number) => {
    const {defaultCheckbox, isChecked, smsNumberDisabled} = this.state;
    return(
      serviceIds && serviceIds[i] ?
      <td>
        {
          defaultCheckbox ?
          <input id= {`billDeliveryNotificationcontactNumbers_${i}`} type='checkbox' checked={isChecked[i] } onChange = {(e: React.ChangeEvent<HTMLInputElement>) =>
          this.contactNumberCheck(i, serviceIds ? serviceIds[i] : i) } disabled={smsNumberDisabled}></input> :
          <input id= {`billDeliveryNotificationcontactNumbers_${i}`} type='checkbox' checked={false} onChange = {(e: React.ChangeEvent<HTMLInputElement>) =>
          this.contactNumberCheck(i, serviceIds ? serviceIds[i] : i)} disabled={smsNumberDisabled}></input>
        }
        <label className='checkbox__bck_img form_radio_label grey-brown img__tickmark--square--grey slightly-bold text-small' htmlFor={`billDeliveryNotificationcontactNumbers_${i}`}>{( serviceIds ? serviceIds[i] : '' )}
        </label>
      </td> : <td></td>
    );
  }

  findSMSNumber = () => {
    const {account} = this.props;
    const {smsShowLength} = this.state;
    if (account) {
      const services: (Optional<Service>)[] = account.services;
      const servicesIds: string[] = services.map((ids: any ) => { return ids.id});
      const smsNotificationNumbers: Array<any> = [];
      if (servicesIds) {
        for (let i: number = 0; i < smsShowLength;  i += 2) {
            smsNotificationNumbers.push(
            <tr>
              {this.renderContactNumber(servicesIds, i)}
              {this.renderContactNumber(servicesIds, i + 1)}
            </tr>
            )
        }
        return smsNotificationNumbers;
      }
    }
  }

  renderDisplayNumber = () => {
    const {deliveryForm} = this.state;
    const displayNumberOptions: string[] = this.getDisplayNumberOptions();
    return (
      /* Display Number Start */
      <div className='content-box bigger_horizontal_padding'>
        <div className='title-middle--grey centered-text'>
          {I18n.translate('BillsDelivery.DisplayNumber.Title')}
        </div>
        <div className='vertical_spacer x8'></div>
        <div className='text-small grey-brown centered-text'>
          {I18n.translate('BillsDelivery.DisplayNumber.Text')}
        </div>
        <div className='vertical_spacer x16'></div>
        <div className='form-item'>
        <Select
            options={displayNumberOptions}
            name={deliveryForm.displayNumberName}
            value={deliveryForm.displayNumberFormat}
            className={'form_input'}
            labelClassName = {'form__label form__text_field-label form__space_select_widget'}
            label = {I18n.translate('BillsDelivery.DisplayNumber.Dropdown.Title')}
            onChange = {this.displayNumberFormatonChange}
          />
        </div>
      </div>
    /* Display Number End */
   );
  }

  renderSMSNotification = () => {
    const {account} = this.props;
    if (account) {
      const services: (Optional<Service>)[] = account.services;
      const servicesIds: string[] = services.map((ids: any ) => { return ids.id});
      const {smsShowHide, defaultCheckbox} = this.state;
      const contactNumberEmpty: any = {};
      contactNumberEmpty['checked'] = defaultCheckbox ? false : true;
      return(
        <div className='content-box bigger_horizontal_padding'>
          <div className='title-middle--grey centered-text'>
           {I18n.translate('BillsDelivery.SMS.Title')}
          </div>
          <div className='vertical_spacer x8'></div>
          <div className='text-small grey-brown centered-text'>
           {I18n.translate('BillsDelivery.SMS.Title')}
          </div>
          <div className='vertical_spacer x24'></div>
          <div className='table-responsive'>
            <table className='desktop_half_width bills__shipping_delivery_table'>
              <tbody>
                {this.findSMSNumber()}
              </tbody>
            </table>
          </div>
          <div className='vertical_spacer x8'></div>
          <div className='centered-text'>
            {servicesIds && servicesIds.length > 6 && defaultCheckbox ?
            <Button
              className= 'button button__no-responsive-arrow--mobile-right cta-button dark_grey_text extra_wide'
              handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.smsListShowHide(smsShowHide, servicesIds)}
              label = {smsShowHide}
              /> : null
            }
          </div>
          <div className='vertical_spacer x16'></div>
          <div className='hr-line'></div>
          <div className='vertical_spacer x24'></div>
          <input className='checkbox__bck_img' id= 'bills_shipping_SMS_notification' type='checkbox' {...contactNumberEmpty} onChange = {(e: React.ChangeEvent<HTMLInputElement>) => this.disableSMSNotificationOption(e)} />
          <label className='form_radio_label img__tickmark t-strong text-small' htmlFor='bills_shipping_SMS_notification'>{I18n.translate('BillsDelivery.SMS.Disabled.Text')}</label>
        </div>
      );
    }
  }

  deliveryMethodTypeEmailWithLink = () => {
    const {account} = this.props;
    const {deliveryForm} = this.state;
    if (!account) {
      return (<Loader />);
    }
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const billDeliveryMethod: Optional<BillDeliveryMethod> = billSettings && billSettings.billDeliveryMethod;
    const billDeliveryNotification: Optional<BillDeliveryNotification> = billSettings && billSettings.billDeliveryNotification;
    const billDeliveryNotificationEmailAddress: Optional<string> = billDeliveryNotification && billDeliveryNotification.emailAddress;
    const billDeliveryMethodCheckedDefault: Optional<BillDeliveryMethod> = deliveryForm.selectedOption === '' ? billDeliveryMethod : deliveryForm.selectedOption;
    return (
      <div className='product_item product_item--mobile-price_below'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <div className='form-item item-tooltip no-bottom-margin'>
              <Radio
                id= {'bills_shipping_delivery_method_1'}
                name= {'bills_shipping_delivery_method'}
                htmlFor= {'bills_shipping_delivery_method_1'}
                onChange= { (e: React.ChangeEvent<HTMLInputElement>) => this.deliveryMethodOptionChange(BillDeliveryMethod.EMAIL_WITH_LINK) }
                value= {BillDeliveryMethod.EMAIL_WITH_LINK}
                checked = {billDeliveryMethodCheckedDefault === BillDeliveryMethod.EMAIL_WITH_LINK}
              />
              <label className='form_radio_label' htmlFor='bills_shipping_delivery_method_1'>
                <span className='text-small bold inline'>
                  <span>{I18n.translate('BillsDelivery.DeliveryMethod.EmailLink.Text')} </span>
                  <span className='tooltip lower--case' id='emailwithlink' onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}>{billDeliveryNotificationEmailAddress}</span>
                </span>
              </label>
            </div>
            <div className='form-item content-box--flexbox align_with_radio_button'>
              <div className='text-small grey-brown no-bottom-margin margin-top-8'>
              {I18n.translate('BillsDelivery.DeliveryMethod.DirectLink.Text')}
              </div>
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'>{I18n.translate('BillsDelivery.DeliveryMethod.ProductPrice.Text')}</div>
        </div>
      </div>
    );
  }

  deliveryMethodTypeEmailWithLinkPDF = () => {
    const {account} = this.props;
    const {deliveryForm} = this.state;
    if (!account) {
      return (<Loader />);
    }
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const billDeliveryMethod: Optional<BillDeliveryMethod> = billSettings && billSettings.billDeliveryMethod;
    const billDeliveryNotification: Optional<BillDeliveryNotification> = billSettings && billSettings.billDeliveryNotification;
    const billDeliveryNotificationEmailAddress: Optional<string> = billDeliveryNotification && billDeliveryNotification.emailAddress;
    let   billDeliveryMethodCheckedDefault:  Optional<BillDeliveryMethod>;
    if (deliveryForm.selectedOption === '') {
      billDeliveryMethodCheckedDefault = billDeliveryMethod;
    } else {
      billDeliveryMethodCheckedDefault = deliveryForm.selectedOption;
    }
    return (
      /* Delivery Method - Email with link PDF start */
      <div className='bg_text position-relative product_item product_item--mobile-price_below product_item__stiched_bellow'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <div className='form-item item-tooltip no-bottom-margin'>
              <Radio
                id= {'bills_shipping_delivery_method_2'}
                name= {'bills_shipping_delivery_method'}
                htmlFor= {'bills_shipping_delivery_method_21'}
                onChange= { (e: React.ChangeEvent<HTMLInputElement>) => this.deliveryMethodOptionChange(BillDeliveryMethod.EMAIL_WITH_BILL_IN_PDF_FORMAT) }
                value= {BillDeliveryMethod.EMAIL_WITH_BILL_IN_PDF_FORMAT}
                checked = {billDeliveryMethodCheckedDefault === BillDeliveryMethod.EMAIL_WITH_BILL_IN_PDF_FORMAT}
              />
              <label className='form_radio_label' htmlFor='bills_shipping_delivery_method_2'>
                <span className='text-small bold inline'>
                  <span>{I18n.translate('BillsDelivery.DeliveryMethod.Email.Pdf.Title')} </span>
                    <span className='tooltip lower--case' id='emaillinkwithpdf' onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}>{billDeliveryNotificationEmailAddress}</span>
                  </span>
                </label>
            </div>
            <div className='form-item content-box--flexbox align_with_radio_button'>
              <div className='text-small grey-brown no-bottom-margin margin-top-8'>
                {I18n.translate('BillsDelivery.DeliveryMethod.EmailPdf.Text')}
              </div>
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'>{I18n.translate('BillsDelivery.DeliveryMethod.ProductPrice.Text')}</div>
        </div>
      </div>
      /* Delivery Method - Email with link PDF End */
    );
  }

  deliveryMethodTypeEbill = () => {
    const {deliveryForm} = this.state;
    return (
      /* Delivery Method - E-Bill start */
      <div className='product_item product_item__no-bottom-border product_item__stiched_bellow'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <Radio
              id= {'bills_shipping_delivery_method_3'}
              name= {'bills_shipping_delivery_method'}
              htmlFor= {'bills_shipping_delivery_method_3'}
              onChange= { (e: React.ChangeEvent<HTMLInputElement>) => this.deliveryMethodOptionChange('bills_shipping_delivery_method_3') }
              value= 'bills_shipping_delivery_method_3'
              checked = {deliveryForm.selectedOption === 'bills_shipping_delivery_method_3'}
              disabled = {true}
            />
            <label className='checkbox__bck_img form_radio_label img__ebill' htmlFor='bills_shipping_delivery_method_3'>
              <div className='vert-centered-text'>
                <div className='text-small bold no-bottom-margin inline_text'>
                {I18n.translate('BillsDelivery.DeliveryMethod.Ebill.Label')}
                </div>
              </div>
            </label>
            <div className='form-item content-box--flexbox bills-shipping-responsive align_with_radio_button'>
              <div className='text-small slightly-bold grey-brown'>
                {I18n.translate('BillsDelivery.DeliveryMethod.Ebill.Title')}
              </div>
              <div className='inline_spacer x2'></div>
              <div>
                <Button
                  className= 'button button--no-responsive-arrow--mobile-narrow-center button__no-responsive-arrow--mobile-right button__no-responsive-arrow--mobile-right-top cta-button extra_wide'
                  handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.ebillHelp()}
                  label = {I18n.translate('BillsDelivery.DeliveryMethod.Help.Label')}
                />
              </div>
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'></div>
        </div>
      </div>
      /* Delivery Method - E-Bill End */
    );
  }

  deliveryMethodTypePaperBillWithoutCallDetails = () => {
    const {account} = this.props;
    const {deliveryForm} = this.state;
    if (!account) {
      return (<Loader />);
    }
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const billDeliveryMethod: Optional<BillDeliveryMethod> = billSettings && billSettings.billDeliveryMethod;
    const billDeliveryMethodCheckedDefault:  Optional<BillDeliveryMethod> = deliveryForm.selectedOption === '' ? billDeliveryMethod : deliveryForm.selectedOption;
    return (
      /* Delivery Method - Paper without call details start */
      <div className='product_item product_item__stiched_bellow'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <div className='form-item no-bottom-margin'>
              <Radio
                id= {'bills_shipping_delivery_method_4'}
                name= {'bills_shipping_delivery_method'}
                htmlFor= {'bills_shipping_delivery_method_4'}
                onChange= { (e: React.ChangeEvent<HTMLInputElement>) => this.deliveryMethodOptionChange(BillDeliveryMethod.PAPER_BILL_WITHOUT_CALL_DETAILS) }
                value= {BillDeliveryMethod.PAPER_BILL_WITHOUT_CALL_DETAILS}
                checked = {billDeliveryMethodCheckedDefault === BillDeliveryMethod.PAPER_BILL_WITHOUT_CALL_DETAILS}
              />
              <label className='form_radio_label' htmlFor='bills_shipping_delivery_method_4'>
                <span className='text-small bold inline'>
                  <span className='tooltip lower--case' id='paperbillwithoutcall' onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}>{I18n.translate('BillsDelivery.DeliveryPaper.BillWithout.Call.Text')}</span>
                </span>
              </label>
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'>{I18n.translate('BillsDelivery.PaperBillWithout.CallAmout.Text')}</div>
        </div>
      </div>
      /* Delivery Method - Paper without call details End */
    );
  }

  deliveryMethodTypePaperBillWithCallDetails = () => {
    const {account} = this.props;
    const {deliveryForm} = this.state;
    if (!account) {
      return (<Loader />);
    }
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const billDeliveryMethod: Optional<BillDeliveryMethod> = billSettings && billSettings.billDeliveryMethod;
    const billDeliveryMethodCheckedDefault:  Optional<BillDeliveryMethod> = deliveryForm.selectedOption === '' ? billDeliveryMethod : deliveryForm.selectedOption;
    return (
      /* Delivery Method - Paper with call details start */
      <div className='product_item product_item__stiched_bellow'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <div className='form-item no-bottom-margin'>
              <Radio
                id= {'bills_shipping_delivery_method_5'}
                name= {'bills_shipping_delivery_method'}
                htmlFor= {'bills_shipping_delivery_method_5'}
                onChange= {(e: React.ChangeEvent<HTMLInputElement>) => this.deliveryMethodOptionChange(BillDeliveryMethod.PAPER_BILL_WITH_CALL_DETAILS)}
                value= {BillDeliveryMethod.PAPER_BILL_WITH_CALL_DETAILS}
                checked = {billDeliveryMethodCheckedDefault === BillDeliveryMethod.PAPER_BILL_WITH_CALL_DETAILS}
              />
              <label className='form_radio_label' htmlFor='bills_shipping_delivery_method_5'>
                <span className='text-small bold inline'>
                  <span className='tooltip lower--case' id='paperbillwithcall' onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}>{I18n.translate('BillsDelivery.DeliveryPaper.BillWith.Call.Text')}</span>
                </span>
              </label>
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'>{I18n.translate('BillsDelivery.PaperBillWith.CallAmout.Text')}</div>
        </div>
      </div>
      /* Delivery Method - Paper with call details End */
    );
  }

  renderPaySlip = () => {
    const {account} = this.props;
    if (!account) {
      return (<Loader />);
    }
    return (
      <React.Fragment>
        <div className='content-box'>
          <div className='title-middle--grey blue centered-text'>
            {I18n.translate('BillsDelivery.DeliveryMethod.Savings.Label')}
          </div>
          <div className='vertical_spacer x8'></div>
            {this.deliveryMethodTypeEmailWithLink()}
            {this.deliveryMethodTypeEmailWithLinkPDF()}
            {this.deliveryMethodTypeEbill()}
        </div>
        <div className='padding-lr-30'>
          {this.deliveryMethodTypePaperBillWithoutCallDetails()}
          {this.deliveryMethodTypePaperBillWithCallDetails()}
        </div>
      </React.Fragment>
    );
  }

  renderEbill = () => {
    return(
      <React.Fragment>
        <div className='text-small grey-brown centered-text'>
          {I18n.translate('BillsDelivery.DeliveryMethod.Ebill.Text')}
        </div>
        <div className='centered-text'>
          <Button
            className= 'button button__no-responsive-arrow--mobile-right cta-button extra_wide'
            handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.ebillHelp()}
            label = {I18n.translate('BillsDelivery.DeliveryMethod.Help.Label')}
          />
        </div>
      </React.Fragment>
    );
  }

  renderDeliveryType = () => {
    const {account} = this.props;
    if (!account) {
      return (<Loader />);
    }
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    return(
      <React.Fragment>
          <div className='title-middle--grey centered-text'>
            {I18n.translate('BillsDelivery.DeliveryMethod.Label')}
          </div>
          <div className='vertical_spacer x8'></div>
          <div className='text-small grey-brown centered-text'>
            {I18n.translate('BillsDelivery.DeliveryMethod.Text')}
          </div>
          {billSettings && billSettings.paymentMethod === 'PAY_SLIP' ? this.renderPaySlip() : billSettings && billSettings.paymentMethod === 'EBILL' ? this.renderEbill() : this.renderPaySlip()}
      </React.Fragment>
    );
  }

  renderDeliveryMethod = () => {
    const {account} = this.props;
    const {renderStatus} = this.state;
    if (!account) {
      return (<Loader />);
    }
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    return(
      <React.Fragment>
        {renderStatus ?
          <React.Fragment>
            <div className='title-middle--grey centered-text mb-24'>
              {I18n.translate('BillsDelivery.DeliveryMethod.Edit.Text')}
            </div>
            <div className='l-flexbox-row bills-shipping-responsive'>
              <div className='l-col-flexbox l-col-flexbox-even bills-shipping-responsive'>
                {this.renderSMSNotification()}
                {this.renderDisplayNumber()}
              </div>
              <div className='l-col-flexbox l-col-flexbox-even bills-shipping-responsive'>
                {billSettings && billSettings.paymentMethod === PaymentMethodType.EBILL ? <div className='content-box bigger_horizontal_padding'> {this.renderDeliveryType()} </div> :
                <div className='content-box content_box--padding-y10'> {this.renderDeliveryType()} </div>
                }
              </div>
            </div>
          </React.Fragment> : null
        }
      </React.Fragment>
    );
  }

  renderStickyBar(): JSX.Element {
    const {renderStatus} = this.state;
    return(
      <React.Fragment>
        {renderStatus ?
        <StickyBar
          url='/'
          label= {I18n.translate('BillsDelivery.Save.Button.Label')}
          className='text-small bold'
          backToLabel = {I18n.translate('BillsDelivery.BackToBills.Label')}
          handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.saveDeliveryMethod(e)}
        /> : null}
      </React.Fragment>
    );
  }

  render(): React.ReactNode {
    const {account} = this.props;
    const {isPopup} = this.state;
    if (!account) {
      return (<Loader />);
    }
    return(
      <React.Fragment>
        <div className='l-center-xxl'>
          {isPopup && this.renderPopup()}
          <div className='l-grid'>
            <div className='l-col l-1of1'>
              {this.renderLoader()}
              {this.renderDeliveryMethod()}
              {this.billDeliveryMethodSuccess()}
            </div>
          </div>
        </div>
        {this.renderStickyBar()}
      </React.Fragment>
    );
  }
}

const mapStateToProps: any = ({ billsReducer }: any) => {
  return {
    account: billsReducer.account,
    billAnonymizationLevelPayload: billsReducer.billAnonymizationLevelPayload,
    billAnonymizationLevelPayloadError: billsReducer.billAnonymizationLevelPayloadError,
    billDeliveryMethodPayload: billsReducer.billDeliveryMethodPayload,
    billDeliveryMethodPayloadError: billsReducer.billDeliveryMethodPayloadError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({fetchBillsInfo, setbillAnonymizationLevel, resetbillAnonymizationLevel, setbillDeliveryMethod, resetbillDeliveryMethod}, dispatch);
};

export default connect(mapStateToProps, mapDispatchToProps)(BillsDelivery);
