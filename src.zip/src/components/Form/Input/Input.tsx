import * as React from 'react';

interface InputProps {
  name: string;
  placeholder?: string;
  value: string;
  className: string;
  type?: string;
  labelClassName: string;
  label: string;
  tooltipId: string;
  onBlur?: (fieldName: string, value: string) => void;
  onChange: (fieldName: string, value: string) => void;
  onClick(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void;
}

export class Input extends React.Component<InputProps> {
  constructor(props: InputProps) {
    super(props);
  }

  render(): React.ReactNode {
    const {type, name, className, value, placeholder, onChange, onBlur, labelClassName, label, onClick, tooltipId } = this.props;
    return (
      <React.Fragment>
        <label className={labelClassName}>{label}
          <span className='tooltip' id= {tooltipId} onClick= {onClick}></span>
        </label>
        <input
          type={type}
          name={name}
          className={className}
          placeholder={placeholder}
          value={value}
          onBlur = {(e: React.ChangeEvent<HTMLInputElement>) => onBlur ? onBlur(e.target.name, e.target.value) : null}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => onChange(e.target.name, e.target.value)}
        />
      </React.Fragment>
    );
  }
}
