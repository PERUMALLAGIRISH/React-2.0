
export interface Map<T> {
    [key: string]: T;
}
export const SubscriptionDetailChangeOwnerConstants: Map<any> = {
  STEP1                                 : 1,
  STEP2                                 : 2,
  ERROR                                 : 'ERROR',
  PENDING_TRANSFER_CASES                : 'PENDING_TRANSFER_CASES',
  IN_DUNNING_PROCESS                    : 'IN_DUNNING_PROCESS',
  NOT_ELIGIBLE_FOR_MTV_PRODUCTS         : 'NOT_ELIGIBLE_FOR_MTV_PRODUCTS',
  TRANSFER_DEVICE_PLAN                  : 'TRANSFER_DEVICE_PLAN',
  OPEN_INVOICES_30_DAYS_PAST            : 'OPEN_INVOICES_30_DAYS_PAST',
  APPLY_ETF_AMOUNT                      : 'APPLY_ETF_AMOUNT',
  WAIVE_OFF_ETF                         : 'WAIVE_OFF_ETF',
  DATA_SHARING_PRODUCT_IS_ACTIVE        : 'DATA_SHARING_PRODUCT_IS_ACTIVE',
  DIFF_SUBSCRIBER_INFO                  : 'DIFF_SUBSCRIBER_INFO',
  AMOUNT_ACCESSORIES_EXCEED_5_ITEMS     : 'AMOUNT_ACCESSORIES_EXCEED_5_ITEMS',
  INVALID_SERIAL_NUMBER                 : 'INVALID_SERIAL_NUMBER',
  SUNRISE_PROD_NOT_ALLOWED_FOR_CUSTOMER : 'SUNRISE_PROD_NOT_ALLOWED_FOR_CUSTOMER',
  CAN_NOT_TRANSFER_ON_SAME_SITE         : 'CAN_NOT_TRANSFER_ON_SAME_SITE',
  CREDIT_CHECK_FAILED                   : 'CREDIT_CHECK_FAILED',
  MAX_SUB_REACHED                       : 'MAX_SUB_REACHED',
  CAN_NOT_TRANSFER_BUS_TO_RES           : 'CAN_NOT_TRANSFER_BUS_TO_RES',
  CAN_NOT_TRANSFER_RES_TO_BUS           : 'CAN_NOT_TRANSFER_RES_TO_BUS',
  HALBTAX_OPTION                        : 'HALBTAX_OPTION',
  UNKNOWN_ERROR                         : 'UNKNOWN_ERROR',
  UNKNOWN_WARNING                       : 'UNKNOWN_WARNING',
  NOT_ELIGIBLE_FOR_OWNER_CHANGE         : 'NOT_ELIGIBLE_FOR_OWNER_CHANGE',
  SUNRISE_HOME_UNLIMITED                : 'SUNRISE HOME UNLIMITED',
	MOBILE                                : 'MOBILE'
}
