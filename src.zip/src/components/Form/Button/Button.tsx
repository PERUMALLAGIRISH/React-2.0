import * as React from 'react';

export interface ButtonProps {
  label?: string;
  disabled?: boolean;
  className: string;
  onMouseDown?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  onKeyPress?: (event: React.KeyboardEvent<HTMLElement>) => void;
  handleClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

export class Button extends React.Component<ButtonProps> {
  constructor(props: ButtonProps) {
    super(props);
  }
  render(): React.ReactNode {
    const {className, handleClick, disabled, onMouseDown, onKeyPress, label} = this.props;
    return (
      <button
        className= {className}
        onClick={handleClick}
        disabled= {disabled}
        onMouseDown={onMouseDown}
        onKeyPress={onKeyPress}
      >{label}</button>
    );
  }
}