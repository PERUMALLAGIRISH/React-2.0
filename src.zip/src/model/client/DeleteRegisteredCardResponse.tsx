import { DeleteRegisteredCardPayload } from '../types.d';

export interface DeleteRegisteredCardResponse {
  deleteRegisteredCard: DeleteRegisteredCardPayload;
}