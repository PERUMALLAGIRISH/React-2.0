import { Country } from '../../model/types.d';
export interface CountriesResponse {
    countries: Country[];
  }