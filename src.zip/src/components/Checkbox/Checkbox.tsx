import * as React from 'react';

export interface Props {
  id: string;
  label?: string;
  className?: string;
  disabled?: boolean;
  handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export const Checkbox: React.StatelessComponent<Props> = (props) => {
  return (
  <React.Fragment>
      {props.label !== undefined ?
        <div className={props.className}>
          <input
            id={props.id}
            type='checkbox'
            onChange = {props.handleChange}
            disabled = {props.disabled}
          />
          <label className='form_radio_label' htmlFor={props.id}>
            <div className='text-small bold inline'>
              {props.label}
            </div>
          </label>
        </div> : <input
          id={props.id}
          type='checkbox'
          onChange = {props.handleChange}
          disabled = {props.disabled}
        />
      }
  </React.Fragment>
  );
};
