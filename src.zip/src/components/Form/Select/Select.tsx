import * as React from 'react';

interface SelectProps {
  options: object | null;
  name?: string;
  value?: string;
  className: string;
  labelClassName: string;
  label: string;
  tooltipId?: string;
  onChange: (fieldName: string, value: string) => void;
  onClick?(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void;
}

export class Select extends React.Component<SelectProps> {
  constructor(props: SelectProps) {
    super(props);
  }

  generateOptions = () => {
    const {options} = this.props;
    const selectOptions: JSX.Element[]  = [];
    if (Array.isArray(options)) {
      options.forEach((option, index) => {
        selectOptions.push(<option value={option.value || option.isocode} key={index}>{option.name}</option>);
      });
    }
    return selectOptions;
  }

  render(): React.ReactNode {
    const {name, value, className, onChange, labelClassName, tooltipId, onClick, label} = this.props;
    return (
      <React.Fragment>
        <label className={labelClassName}>
          {tooltipId ? <span className='form__label tooltip' id={tooltipId} onClick={onClick}>{label}</span> : label}
        </label>
        <select
          value={value}
          name={name}
          className={className}
          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => onChange(e.target.name, e.target.value)}>
          {this.generateOptions()}
        </select>
      </React.Fragment>
    )
  }
}
