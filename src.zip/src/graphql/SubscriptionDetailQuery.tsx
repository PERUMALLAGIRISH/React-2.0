import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const SubscriptionDetailQuery: DocumentNode = gql`
query account($language: Language) {
  account(language: $language) {
    id
    services {
      id
    }
  }
}`;

export default SubscriptionDetailQuery;