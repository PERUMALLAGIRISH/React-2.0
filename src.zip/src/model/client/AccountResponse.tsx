export interface AccountResponse {
  account: Account;
}