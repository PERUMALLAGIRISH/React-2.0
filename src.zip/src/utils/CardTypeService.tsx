export enum CardType {
  ECA = 'Mastercard',
  VIS = 'Visa',
  AMX = 'American Express',
  PFC = 'PostFinance Card',
  PEF = 'PostFinance E-Finance'
}

class CardTypeService {
  getCardType = (type: string) => {
    switch (type.toLowerCase()) {
      case 'eca':
        return CardType.ECA;
      case 'vis':
        return CardType.VIS;
      case 'amx':
        return CardType.AMX;
      case 'pfc':
        return CardType.PFC;
      case 'pef':
        return CardType.PEF;
      default:
        return type;
    }
  }
}

export default new CardTypeService();