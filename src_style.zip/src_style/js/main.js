// Taken from modernizr.js
function detectIE() {
    var ua = window.navigator.userAgent;

    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        // IE 10 or older => return version number
        return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }

    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
        // IE 11 => return version number
        var rv = ua.indexOf('rv:');
        return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
    }

    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
        // Edge (IE 12+) => return version number
        return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    }

    // other browser
    return false;
}




function resizeTitle() {
    var titles = document.querySelectorAll('.js-resize-title');

    [].forEach.call(titles, function(title) {
        title.removeAttribute('style');

        const scaleSecureMargin = 0.01; // to avoid potential scrolling
        const textSecureMargin = 15; // to avoid cutting text

        const titleElementWidth = title.scrollWidth + textSecureMargin;
        const titleTextWidth = title.clientWidth;

        const titleScaleRatio = Math.floor((titleTextWidth / titleElementWidth - scaleSecureMargin) * 100) / 100;
        const styleTransformScale = titleScaleRatio < 1 ? titleScaleRatio : 1;

        title.setAttribute('style', 'width: ' + titleElementWidth + 'px; transform: scale(' + styleTransformScale + '); -webkit-transform: scale(' + styleTransformScale + ');');
    });
}

function setRainbowVisualisationBarWidth() {
    var bars = document.getElementsByClassName("whatsapp-benefits");
    var barColor = null;

    for (var i = 0; i < bars.length; ++i) {
        var percentage = +bars[i].dataset.percentage;

        if (percentage < 0) {
            percentage = 0;
        }
        if (percentage > 100) {
            percentage = 100;
        }

        bars[i].style.width = percentage + "%";

        var type = bars[i].dataset.type;
        if (type === "meter") {
            bars[i].style.backgroundImage = "none";

            if (percentage <= 25) {
                barColor = "#aa1937";
            } else if (percentage <= 50) {
                barColor = "#ffc805";
            } else {
                barColor = "#02d6a1";
            }
            bars[i].style.backgroundColor = barColor;
        }
    }
}



//
// Progress tracker
//
function setProgressTrackerClasses() {
    var progressTrackerEl = document.getElementsByClassName('progress_tracker')[0];
    if (!progressTrackerEl) return;

    //convert data attributes to js vars
    var steps = [];
    // max 10 steps
    if (progressTrackerEl.dataset.step0) steps[0] = progressTrackerEl.dataset.step0;
    if (progressTrackerEl.dataset.step1) steps[1] = progressTrackerEl.dataset.step1;
    if (progressTrackerEl.dataset.step2) steps[2] = progressTrackerEl.dataset.step2;
    if (progressTrackerEl.dataset.step3) steps[3] = progressTrackerEl.dataset.step3;
    if (progressTrackerEl.dataset.step4) steps[4] = progressTrackerEl.dataset.step4;
    if (progressTrackerEl.dataset.step5) steps[5] = progressTrackerEl.dataset.step5;
    if (progressTrackerEl.dataset.step6) steps[6] = progressTrackerEl.dataset.step6;
    if (progressTrackerEl.dataset.step7) steps[7] = progressTrackerEl.dataset.step7;
    if (progressTrackerEl.dataset.step8) steps[8] = progressTrackerEl.dataset.step7;
    if (progressTrackerEl.dataset.step9) steps[9] = progressTrackerEl.dataset.step8;
    var activeStep = +progressTrackerEl.dataset.active;

    var firstStep = null;
    if (activeStep === 0)
        firstStep = 0;
    if (activeStep === steps.length - 1)
        firstStep = Math.max(steps.length - 3, 0);
    if (activeStep > 0 && activeStep < steps.length - 1)
        firstStep = activeStep - 1;

    var breakWordsClass = "";
    for (i = firstStep; i <= firstStep + 2; ++i) {
        if (i < steps.length) {
            console.log(steps[i]);
            if (/\s/.test(steps[i]))
                breakWordsClass = " progress_tracker__break_words";
        }
    }

    if (activeStep - 2 < 0)
        firstStep = 0;
    else {
        var missingFromRight = activeStep + 3 - steps.length;
        if (missingFromRight > 0)
            firstStep = Math.max(activeStep - 2 - missingFromRight, 0);
        else
            firstStep = activeStep - 2;
    }

    var progressSignInvisibleClass = "";
    var progressSignClasses = "";
    var dashEl = document.getElementsByClassName('progress_tracker__dash');
    var signEl = document.getElementsByClassName('progress_step_sign');

    var j = 0;
    for (i = firstStep; i <= firstStep + 4; ++i) {
        if (i >= steps.length) {
            signEl[j + firstStep].classList.add('progress_sign_invisible');
            dashEl[j + firstStep - 1].classList.add('progress_sign_dash_invisible');
        }
        else {
            document.getElementsByClassName("progress_step_number")[j].innerHTML = (j + firstStep + 1).toString();
            document.getElementsByClassName("progress_step_title")[j].innerHTML = steps[j + firstStep];

            // Calculate progress signs classes
            if (steps.length > 3 && ((i === firstStep && i !== activeStep) || (activeStep === 0 && i === 4)))
                progressSignInvisibleClass = " progress_sign--mobile-invisible";
            else
                progressSignInvisibleClass = "";
            if (i === activeStep)
                progressSignClasses = "progress_step_sign inline_progress_sign progress_step_number--mobile-small" + breakWordsClass;
            else if (Math.abs(i - activeStep) < 2 || (activeStep === 0 && i === 2) || (activeStep === steps.length - 1 && i === steps.length - 3))
                progressSignClasses = "progress_step_sign inline_progress_sign progress_step_number--small" + progressSignInvisibleClass + breakWordsClass;
            else
                progressSignClasses = "progress_step_sign inline_progress_sign progress_step_number--no-number" + progressSignInvisibleClass + breakWordsClass;
            signEl[i - firstStep].className = progressSignClasses;

            // Calculate dashes classes
            if (i < Math.min(firstStep + 4, steps.length - 1)) {
                if ((activeStep - i > 1 || i - activeStep > 0) && !((activeStep === 0 || activeStep === steps.length - 1) && Math.abs(activeStep - i) === 1))
                    if (steps.length > 3 && ((j === 0 && activeStep !== 0) || (activeStep === 0 && j === 3))) {
                        dashEl[j].classList.add('progress_tracker__dash-small');
                        dashEl[j].classList.add('progress_tracker__dash--mobile-invisible');
                    } else
                        dashEl[j].classList.add('progress_tracker__dash-small');
                else if (steps.length > 3 && ((j === 0 && activeStep !== 0) || (activeStep === 0 && j === 3)))
                    dashEl[j].classList.add('progress_tracker__dash--mobile-invisible');
            }
        }
        ++j;
    }
}



//
// Drawing of SVG circle arcs
//
function polarToCartesian(centerX, centerY, radius, angleInDegrees) {
    var angleInRadians = (angleInDegrees-90) * Math.PI / 180.0;

    return {
        x: centerX + (radius * Math.cos(angleInRadians)),
        y: centerY + (radius * Math.sin(angleInRadians))
    };
}
function describeArc(x, y, radius, startAngle, endAngle) {

    var start = polarToCartesian(x, y, radius, endAngle);
    var end = polarToCartesian(x, y, radius, startAngle);

    var largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

    var d = [
        "M", start.x, start.y,
        "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
    ].join(" ");

    return d;
}
function drawDataArcs() {
    var arcs_info = document.getElementsByClassName("subscription__arc_description");
    for (var i = 0; i < arcs_info.length; ++i) {

        var arc_info = arcs_info[i];

        var percentage = +arc_info.dataset.percentage;
        if (percentage <= 0) continue;
        if (percentage > 100) {
            percentage = 100;
        }

        var arcColor = null;
        if (percentage <= 25) {
            arcColor = "#aa1937";
        } else if (percentage <= 50) {
            arcColor = "#ffc805";
        } else {
            arcColor = "#02d6a1";
        }

        var variant = arc_info.dataset.variant;
        percentage = percentage * 3.6; // convert to degrees

        var cssSelector = '#' + arc_info.id + ' + svg path';
        var arc = document.querySelector(cssSelector);


        arc.setAttribute("stroke", arcColor);
        if (variant === 'small') {
            arc.setAttribute("d", describeArc(80, 80, 74, -percentage, 0));
        } else {
            arc.setAttribute("d", describeArc(120, 120, 110, -percentage, 0));
        }
    }
}



//
// Subscriptions Line table
//
var lineTableElement = null;
var tableFlexBottom = null;
var defaultTableColumnHeight = null;
var tableBackgroundsContainer = null;
var tableOverlayShadeContainerLeft = null;
var tableOverlayShadeContainerRight = null;
var tableFirstRow = null;
var tableLastRow = null;
var TableColumnWidth = null;
var columnsToMoveLeft = 0;
var maxColumnsScreenFit = 1;
var tableWidth = 0;
var screenWidth = 0;
// Subscription line table initialization
function initLineTable() {
    var lineTable = document.getElementsByClassName('js-subscriptions_line_table');
    if (lineTable.length === 0) return;

    if (document.querySelector('.subscriptions__line_table__container.js-inner_table')) {
        if (window.matchMedia("(max-width: 750px)").matches) {
            screenWidth = document.getElementsByClassName('subscriptions__line_table__content_box')[0].getBoundingClientRect().width - 2 * 20;
        } else {
            screenWidth = document.getElementsByClassName('subscriptions__line_table__content_box')[0].getBoundingClientRect().width - 2 * 83;
        }
    } else {
        screenWidth = document.body.clientWidth;
    }

    var tableRows = document.querySelectorAll('table tr');
    tableFirstRow = tableRows[0];
    tableLastRow = tableRows[tableRows.length - 3];

    var tableColumnBackgrounds = document.getElementsByClassName('js-subscriptions__line-table_column');

    var extraColumnSpace = Math.floor((screenWidth - 128) / 310) - tableColumnBackgrounds.length;
    if (extraColumnSpace > 3) {
        extraColumnSpace = 3;
    }

    var screenContainers = document.getElementsByClassName('subscriptions__line_table__screen_container');
    tableFlexBottom = document.getElementsByClassName('subscriptions__line_table__flex-bottom')[1];
    lineTableElement = document.getElementsByClassName('subscriptions__line_table')[0];
    var lineTableContainer = document.getElementsByClassName('subscriptions__line_table__table_container')[0];
    tableWidth = lineTableContainer.getBoundingClientRect().width;

    var columnMinWidth = 310;
    if (window.matchMedia("(max-width: 750px)").matches) {
        columnMinWidth = 280;
    }
    lineTableContainer.style.minWidth = tableColumnBackgrounds.length * columnMinWidth + 'px';
    tableBackgroundsContainer = document.getElementsByClassName('subscriptions__line_table__column_content_boxes')[0];
    tableBackgroundsContainer.style.minWidth = tableColumnBackgrounds.length * columnMinWidth + 'px';
    tableOverlayShadeContainerLeft = document.getElementsByClassName('subscriptions__line_table__column_content_boxes')[1];
    tableOverlayShadeContainerLeft.style.minWidth = tableColumnBackgrounds.length * columnMinWidth + 'px';
    tableOverlayShadeContainerRight = document.getElementsByClassName('subscriptions__line_table__column_content_boxes')[2];
    lineTableElement = lineTable[0];

    for (var i = 0; i < tableBackgroundsContainer.children.length; ++i) {
        tableBackgroundsContainer.children[i].classList.remove('js-inactive-table-column');
        tableOverlayShadeContainerLeft.children[i].classList.remove('js-inactive-table-column');
        tableOverlayShadeContainerRight.children[i].classList.remove('js-inactive-table-column');
        tableFirstRow.children[i].classList.remove('js-inactive-table-column');
    }

    var tableContainer = document.getElementsByClassName('subscriptions__line_table__screen_container__table')[0];
    tableContainer.classList.remove('subscriptions__line_table__screen_container--overflow_container');
    tableContainer.classList.remove('subscriptions__line_table__screen_container--show-nav-buttons');


    for (i = 0; i < screenContainers.length; ++i) {
        screenContainers[i].classList.remove('x3');
        screenContainers[i].classList.remove('x2');
        screenContainers[i].classList.remove('x1');
        screenContainers[i].classList.remove('x0');

        switch (extraColumnSpace) {
            case 3:
                screenContainers[i].classList.add('x3');
                break;
            case 2:
                screenContainers[i].classList.add('x2');
                break;
            case 1:
                screenContainers[i].classList.add('x1');
                break;
            case 0:
                screenContainers[i].classList.add('x0');
                break;
            default:
                screenContainers[i].classList.add('x0');
        }

        screenContainers[i].style.minWidth = tableColumnBackgrounds.length * columnMinWidth + 128 + 'px';
    }


    var columnContentBoxes = document.querySelectorAll('.js-subscriptions_line_table .column_content_box');
    for (i = 0; i < columnContentBoxes.length; ++i) {
        columnContentBoxes[i].style.width = 100 / tableColumnBackgrounds.length + "%";
    }
    var flexColumnContentBoxes = document.querySelectorAll('.subscriptions__line_table__flex-bottom .cell_content-box');
    for (i = 0; i < flexColumnContentBoxes.length; ++i) {
        flexColumnContentBoxes[i].style.width = 100 / tableColumnBackgrounds.length + "%";
    }
    var tableCells = document.querySelectorAll('.subscriptions__line_table > tbody > tr > td');
    for (i = 0; i < tableCells.length; ++i) {
        tableCells[i].style.width = 100 / tableColumnBackgrounds.length + "%";
    }

    defaultTableColumnHeight = document.getElementsByClassName('subscriptions__line_table__column_content_boxes')[0].clientHeight + 'px';

    TableColumnWidth = columnMinWidth;
    var backgroundColumns = document.querySelectorAll('.subscriptions__line_table__column_content_boxes .column_content_box');

    for (i = 0; i < backgroundColumns.length - 1; ++i) {
        backgroundColumns[i].style.height = defaultTableColumnHeight;
    }

    if (extraColumnSpace < 0) {
        for (i = 0; i < screenContainers.length; ++i) {
            screenContainers[i].style.minWidth = '0';
        }

        tableContainer.classList.add('subscriptions__line_table__screen_container--overflow_container');

        //re-calculate extraColumnSpace
        extraColumnSpace = Math.floor(screenWidth / 310) - tableColumnBackgrounds.length;

        if (extraColumnSpace < 0) {

            tableContainer.classList.add('subscriptions__line_table__screen_container--overflow_container--scroll');
            tableContainer.classList.add('subscriptions__line_table__screen_container--show-nav-buttons');

            // calculate initial columns position
            maxColumnsScreenFit = Math.floor(document.documentElement.clientWidth / (TableColumnWidth + 10));
            if (tableBackgroundsContainer.children.length - maxColumnsScreenFit < 2) {
                maxColumnsScreenFit -= 1;
            }
            if (maxColumnsScreenFit < 1) {
                maxColumnsScreenFit = 1;
            }
            columnsToMoveLeft = Math.ceil(tableBackgroundsContainer.children.length / 2) - Math.ceil(maxColumnsScreenFit / 2);

            var scrollToLeft = TableColumnWidth * columnsToMoveLeft - (document.documentElement.clientWidth - (maxColumnsScreenFit * TableColumnWidth)) / 2;
            lineTable[0].scrollLeft = scrollToLeft;

            detectInactiveTableColumns(scrollToLeft);
            lineTable[0].addEventListener('scroll', lineTableHorScroll, false);

            const contentBlockNavigationItems = document.querySelectorAll('.js-content-block__navigation');
            for(var i = 0; i < contentBlockNavigationItems.length; i++) {
                item = contentBlockNavigationItems[i];
                item.addEventListener('click', reactToNavigationButtons);
            }
        } else {
            tableContainer.classList.remove('subscriptions__line_table__screen_container--overflow_container--scroll');
            tableContainer.classList.remove('subscriptions__line_table__screen_container--show-nav-buttons');

            for (i = 0; i < tableBackgroundsContainer.children.length; ++i) {
                tableBackgroundsContainer.children[i].classList.remove('js-inactive-table-column');
                tableBackgroundsContainer.children[i].style.height = '';
                tableFirstRow.children[i].classList.remove('js-inactive-table-column');
                if (!tableFlexBottom.children[i].classList.contains('line_table_element_hidden')) {
                    tableLastRow.children[i].style.visibility = 'visible';
                    tableFlexBottom.children[i].style.visibility = 'visible';
                }
            }
        }
    } else {
        tableContainer.classList.remove('subscriptions__line_table__screen_container--overflow_container');
    }

    var showHideButtons = document.getElementsByClassName('js-show_hide_button');

    var insertedSavingTip = null;
    var savingTips = document.getElementsByClassName('js-saving_tip');
        for (i = 0; i < showHideButtons.length; ++i) {
        insertedSavingTip = document.getElementsByClassName('js-inserted-saving-tip-' + i)[0];
        if (insertedSavingTip) {
            insertedSavingTip.remove();
        }
        if (savingTips[i]) {
            savingTips[i].classList.add('js-is-hidden');
        }
        showHideButtons[i].innerHTML = "<div class='text-s-14px grey-brown t-bold inline_text'>More product details&nbsp;</div><img src='../../img/new/arrow-down.svg'/>";

        showHideButtons[i].addEventListener('click', showHideLineTableSavingTip, false);
    }
}


var LineTableTimeOut = null;
var LineTableCurrentScrollLeft = null;
function lineTableHorScroll(event) {
    LineTableCurrentScrollLeft = event.currentTarget.scrollLeft;
    columnsToMoveLeft = Math.ceil(LineTableCurrentScrollLeft / TableColumnWidth);

    // debounce call to to detectInactiveTableColumns to 100ms
    clearTimeout(LineTableTimeOut);
    LineTableTimeOut = setTimeout(function() {
        LineTableTimeOut = null;
        detectInactiveTableColumns(LineTableCurrentScrollLeft);
    }, 100);
    if (!LineTableTimeOut) detectInactiveTableColumns(LineTableCurrentScrollLeft);
}
function detectInactiveTableColumns(scrollToLeft) {
    var tableColumnBackgrounds = document.getElementsByClassName('js-subscriptions__line-table_column');

    var visibleColumnsReached = false;
    var lastVisibleColumnIndex = 0;
    for (i = 0; i < tableBackgroundsContainer.children.length; ++i) {
        var leftEdge = i * TableColumnWidth - scrollToLeft;
        var rightEdge = Math.floor(leftEdge + TableColumnWidth - 16);

        var leftButton = document.querySelector('.js-content-block__navigation[data-navigation-direction=left]');
        var rightButton = document.querySelector('.js-content-block__navigation[data-navigation-direction=right]');

        if (leftEdge >= 0 && rightEdge <= screenWidth) {
            tableBackgroundsContainer.children[i].classList.remove('js-inactive-table-column');
            tableFirstRow.children[i].classList.remove('js-inactive-table-column');
            if (!tableFlexBottom.children[i].classList.contains('line_table_element_hidden')) {
                tableLastRow.children[i].style.visibility = 'visible';
                tableFlexBottom.children[i].style.visibility = 'visible';
            }
            if (i === 1) {
                leftButton.style.display = 'none';
            }
            if (i === tableBackgroundsContainer.children.length - 2) {
                rightButton.style.display = 'none';
            }

            if (!visibleColumnsReached) {
                tableOverlayShadeContainerLeft.style.left = -((tableBackgroundsContainer.children.length - i) * (TableColumnWidth) + 16) + "px";
                visibleColumnsReached = true;
            }

            tableColumnBackgrounds[i].style.height = '100%';
            lastVisibleColumnIndex = i;
        } else {
            tableBackgroundsContainer.children[i].classList.add('js-inactive-table-column');
            tableFirstRow.children[i].classList.add('js-inactive-table-column');
            tableLastRow.children[i].style.visibility = 'hidden';
            tableFlexBottom.children[i].style.visibility = 'hidden';
            if (i === 1) {
                leftButton.style.display = 'block';
            }
            if (i === tableBackgroundsContainer.children.length - 2) {
                rightButton.style.display = 'block';
            }

            var tableTop = document.getElementsByClassName('subscriptions__line_table__container')[0].getBoundingClientRect().top;
            var tableFacts = document.querySelectorAll('td.last_fact');
            if (tableFacts.length > 0) {
                var factsBottom = tableFacts[tableFacts.length - 1].getBoundingClientRect().bottom;
                tableColumnBackgrounds[i].style.height = factsBottom - tableTop + 'px';
            }
        }
    } // end loop
    var shaderColumns = document.getElementsByClassName('column_content_box__shade');
    for (i = 0; i < shaderColumns.length; ++i) {
        shaderColumns[i].style.height = factsBottom - tableTop + 'px';
    }

    for (i = 0; i < tableBackgroundsContainer.children.length; ++i) {
        tableOverlayShadeContainerRight.children[i].style.display = 'block';
    }
    for (i = 0; i <= lastVisibleColumnIndex; ++i) {
        tableOverlayShadeContainerRight.children[i].style.display = 'none';
    }
    tableOverlayShadeContainerRight.style.width = (tableBackgroundsContainer.children.length - lastVisibleColumnIndex - 1) * TableColumnWidth + 'px';
    tableOverlayShadeContainerRight.style.left = (lastVisibleColumnIndex + 1) * (TableColumnWidth) + 16 + "px";
    for (i = lastVisibleColumnIndex + 1; i <= tableBackgroundsContainer.children.length; ++i) {
        if (tableOverlayShadeContainerRight.children[i - 1].style.display !== 'none') {
            tableOverlayShadeContainerRight.children[i - 1].style.width = 100 / (tableBackgroundsContainer.children.length - lastVisibleColumnIndex - 1) + '%';
        }
    }


}
function reactToNavigationButtons(event) {
    event.preventDefault();
    if (animationInterval) return;

    if(this.dataset.navigationDirection === 'left') {
        if (columnsToMoveLeft >= 1) {
            columnsToMoveLeft -= 1;
        }
    } else if (this.dataset.navigationDirection === 'right') {
        if (columnsToMoveLeft < tableBackgroundsContainer.children.length - maxColumnsScreenFit) {
            columnsToMoveLeft += 1;
        }
    }
    EaseOutScrollToAnimation(lineTableElement, lineTableElement.scrollLeft, TableColumnWidth * columnsToMoveLeft + - (document.documentElement.clientWidth - (maxColumnsScreenFit * TableColumnWidth)) / 2,
        700, 40);
    // lineTableElement.scrollLeft = TableColumnWidth * columnsToMoveLeft + - (document.documentElement.clientWidth - (maxColumnsScreenFit * TableColumnWidth)) / 2;
}
// Subscription line table show-hide saving tip event handler
function showHideLineTableSavingTip(event) {
    var tableColumnBackgrounds = document.getElementsByClassName('js-subscriptions__line-table_column');
    for (i = 0; i < tableColumnBackgrounds.length; ++i) {
        var buttonClassName = "js-show_hide_button__column-" + i;
        if (event.currentTarget.classList.contains(buttonClassName)) {
            var savingTips = document.getElementsByClassName('js-saving_tip');

            if (savingTips[i].classList.contains('js-is-hidden')) {
                var savingTip = savingTips[i].cloneNode(true);
                savingTip.classList.remove('is-hidden');
                savingTip.classList.add('js-inserted-saving-tip-' + i);
                event.currentTarget.parentNode.insertBefore(savingTip, event.currentTarget);

                event.currentTarget.innerHTML = "<div class='text-s-14px grey-brown t-bold inline_text'>Hide product details&nbsp;</div><img src='../../img/new/arrow-down.svg' class='vert-upside-down'/>";
            } else {
                var insertedSavingTip = document.getElementsByClassName('js-inserted-saving-tip-' + i)[0];
                insertedSavingTip.remove();

                event.currentTarget.innerHTML = "<div class='text-s-14px grey-brown t-bold inline_text'>More product details&nbsp;</div><img src='../../img/new/arrow-down.svg'/>";
            }

            savingTips[i].classList.toggle('js-is-hidden');
        }
    }
    for (i = 0; i < tableColumnBackgrounds.length; ++i) {
        if (!tableColumnBackgrounds[i].classList.contains('js-inactive-table-column')) {
            if (savingTips[i].classList.contains('js-is-hidden')) {
                tableColumnBackgrounds[i].style.height = defaultTableColumnHeight;
            } else {
                tableColumnBackgrounds[i].style.height = "100%";
            }
        }
    }
}
// End line table


//
// Subscriptions Inner Line table
//
// Subscription inner line table initialization
function initInnerLineTable() {
    var lineTable = document.getElementsByClassName('js-subscriptions_inner_line_table');
    if (lineTable.length === 0) return;

    var tableContainer = document.getElementsByClassName('subscriptions__line_table__screen_container__table')[0];
    tableContainer.classList.remove('subscriptions__line_table__screen_container--overflow_container');

    var screenWidth = document.getElementsByClassName('subscriptions__line_table__content_box')[0].getBoundingClientRect().width;

    var columnMinWidth = 310;
    if (window.matchMedia("(max-width: 750px)").matches) {
        columnMinWidth = 280;
    }

    var extraColumnSpace = Math.floor((screenWidth - 128) / columnMinWidth) - 2;

    console.log(extraColumnSpace);

    if (extraColumnSpace < 0) {
        tableContainer.classList.add('subscriptions__line_table__screen_container--overflow_container');
    }

}

// Scroll animation
var animationInterval = null;
function EaseOutScrollToAnimation(element, currentPosition, targetPosition, duration, steps) {
    var positionParts = [];
    var i;
    var t;

    for(i = 1; i <= steps; i++) {
        t = i / steps;
        t = t * (2 - t); // easeOutQuad
        positionParts.push(currentPosition + (targetPosition - currentPosition) * t);
    }

    intervalI = 0;

    animationInterval = setInterval(
        function() {
            if(intervalI === steps - 1) {
                clearInterval(animationInterval);
                animationInterval = null;
            }
            element.scrollLeft = positionParts[intervalI];
            intervalI++;
        },
        duration / steps
    );
}



//
// Pack slide show
//
var packSlideShowOffset = 0;
var packSlide = null;
function InitPackSlideShow() {
    packSlide = document.getElementsByClassName('js-pack-slide');
    if (packSlide.length === 0) return;
    packSlide = packSlide[0];

    // packSlide.style.left = (packSlide.children.length -1) * 10 + "px";

    packSlideShowOffset = packSlideShowOffset < 0 ? packSlide.children.length - 1 : packSlideShowOffset;
    packSlideShowOffset = packSlideShowOffset > packSlide.children.length - 1 ? 0 : packSlideShowOffset;
    console.log("packSlideShowOffset:" + packSlideShowOffset);

    var activeSlideDimensions = null;
    if (!document.querySelector('.js-pack-slide .active')) {
        activeSlideDimensions = packSlide.children[packSlide.children.length - 1].getBoundingClientRect();
    } else {
        activeSlideDimensions = document.querySelector('.js-pack-slide .active').getBoundingClientRect();
    }
    packSlide.style.height = activeSlideDimensions.height + 'px';
    packSlide.style.left = (packSlide.getBoundingClientRect().width - activeSlideDimensions.width)/2 + 'px';

    var i = 0;
    var index = 0;
    do {
        index = i + packSlideShowOffset > packSlide.children.length - 1 ? i + packSlideShowOffset - packSlide.children.length : i + packSlideShowOffset;
        packSlide.children[index].style.transform = "translateZ(" + (i - packSlide.children.length + 1) * 30 + "px) scale(1." + (packSlide.children.length - 1 - i) + ", 1)";
        if (i === packSlide.children.length - 1) {
            packSlide.children[index].classList.add('active');
        } else {
            packSlide.children[index].classList.remove('active');
        }

        ++i;
        i = i > packSlide.children.length - 1 ? 0 : i;
        console.log('i: ' + i);
    } while (i !== 0);

    var item = null;
    const contentBlockNavigationItems = document.querySelectorAll('.js-content-block__navigation');
    for(i = 0; i < contentBlockNavigationItems.length; i++) {
        item = contentBlockNavigationItems[i];
        item.addEventListener('click', reactToPackSlideNavigationButtons);
    }
}
function reactToPackSlideNavigationButtons(event) {
    event.preventDefault();

    if(this.dataset.navigationDirection === 'left') {
        --packSlideShowOffset;
    } else if (this.dataset.navigationDirection === 'right') {
        ++packSlideShowOffset;
    }
    InitPackSlideShow();
}




document.addEventListener('DOMContentLoaded', function() {
    var ieVersion = detectIE();
    if (ieVersion) {
        if (ieVersion < 12) {
            document.documentElement.classList.add('lt-ie12');
        }
        else {
            document.documentElement.classList.add('browser-edge');
        }
    }
    var ua = navigator.userAgent.toLowerCase();
    if (ua.indexOf('safari') !== -1 && !(ua.indexOf('chrome') > -1)) {
        document.documentElement.classList.add('browser-safari');
    }

    resizeTitle();
    setProgressTrackerClasses();

    drawDataArcs();
    setRainbowVisualisationBarWidth();
    contentBlockNavigation();
    selectionUpdater();
    headerHeight();

    if (document.getElementsByClassName('popup').length > 0) {
        document.documentElement.style.position = "fixed";
        document.documentElement.style.width = "100%";
    }

    initLineTable();
    initInnerLineTable();
    window.addEventListener('resize', initLineTable, false);
    window.addEventListener('resize', initInnerLineTable, false);

    // switchSubscriptionDashboardMobileDesktop();
    // window.addEventListener('resize', switchSubscriptionDashboardMobileDesktop, false);

    InitPackSlideShow();
    window.addEventListener('resize', InitPackSlideShow, false);
});

window.addEventListener("resize", function(){
    resizeTitle();
    headerHeight();
});


window.addEventListener('scroll', function(){
    stickyHeader();
});


var selectFlag = false;

function DropDown(el) {
    this.dd = el;
    this.placeholder = this.dd.querySelector('span');
    this.opts = this.dd.querySelectorAll('ul.dropdown > li');
    this.val = '';
    this.initEvents();
}

DropDown.prototype = {
    initEvents : function() {
        var obj = this;

        obj.dd.addEventListener('click', function(event){
            if (event.target.tagName === 'BUTTON') return;
            selectFlag = true;
            this.classList.toggle('active');
            return false;
        });

        obj.val = obj.opts[0].textContent;
        obj.placeholder.textContent=obj.val;

        obj.opts.forEach(function(opt) {
            opt.addEventListener('click', function () {
                var opt = this;
                obj.val = opt.textContent;
                obj.placeholder.textContent=obj.val;
            });
        });
    },
    getValue : function() {
        return this.val;
    }
}

// var dd = new DropDown( document.getElementsByClassName('select_container')[0] );
selects = document.getElementsByClassName('select_container');
for(var i = 0; i < selects.length; i++){
    new DropDown(selects[i]);
}
document.addEventListener('click', function(event, nesto){
    if(selectFlag){
        selectFlag = false;
        return;
    }
    for(var i = 0; i < selects.length; i++){
        selects[i].classList.remove('active');
    }
});




// sticky header

function headerHeight() {
    var header = document.querySelector('.js-sticky-header');
    var headerWrapper = document.querySelector('.js-sticky-header-wrapper');
    console.log('>>>', header.offsetHeight);
    headerWrapper.style.height = header.offsetHeight + 'px';
}

function stickyHeader() {
    var scrollPosition = Math.round(window.scrollY);
    var header = document.querySelector('.js-sticky-header');
    var headerWrapper = document.querySelector('.js-sticky-header-wrapper');

    if(scrollPosition > 1) {
        header.classList.add('is-detached');
        headerWrapper.classList.add('is-detached');
    } else {
        header.classList.remove('is-detached');
        headerWrapper.classList.add('is-detached');
    }
}


// Make subscription dashboard possible without CSS show/hide
// function switchSubscriptionDashboardMobileDesktop() {
//     // check if we are on subscriptions dashboard page
//     if (document.getElementsByClassName("subscription__options_visual__content-box").length === 0) return;
//
//     var x = window.matchMedia("(max-width : 950px)");
//
//     // top tag buttons section
//     var tagButtons = document.querySelectorAll(".js-subscriptions_dashboard__tag_button");
//
//     var tagButtonsInsertPlaces = document.getElementsByClassName("js-subscription__circles__tag_buttons_section");
//
//     if (x.matches) {
//         for (var i = 0; i < tagButtons.length; ++i) {
//             tagButtonsInsertPlaces[0].children[0].appendChild(tagButtons[i]);
//         }
//     } else {
//         for (var i = 0; i < tagButtons.length; ++i) {
//             tagButtonsInsertPlaces[1].appendChild(tagButtons[i]);
//         }
//     }
//
//
//     // Options section
//     var optionsSection = document.getElementsByClassName("subscriptions__options_section")[0];
//
//     var optionsSectionInsertPlaces = document.getElementsByClassName("js-subscription__circles__options_section");
//
//     if (x.matches) {
//         // options section
//         optionsSectionInsertPlaces[1].appendChild(optionsSection);
//
//         var jsInserted = document.getElementsByClassName("js-inserted--subscription_dashboard");
//         if (jsInserted.length > 0) {
//             jsInserted[0].remove();
//         }
//
//         var spaceEl = document.createElement('div');
//         spaceEl.className = "vertical_spacer x16 js-inserted--subscription_dashboard";
//         optionsSectionInsertPlaces[1].appendChild(spaceEl);
//     } else {
//         optionsSectionInsertPlaces[0].appendChild(optionsSection);
//     }
//
//
//     // Below circles section
//     var usageDetailsButton = document.getElementsByClassName("js-subscriptions_dashboard__usage_details_button")[0];
//     var usageDetailsWriteup = document.getElementsByClassName("js-subscriptions_dashboard__usage_writeup")[0];
//
//     var middleSectionInsertPlaces = document.getElementsByClassName("js-subscription__circles__details_button_insert_place");
//
//
//     if (x.matches) {
//         middleSectionInsertPlaces[1].appendChild(usageDetailsWriteup);
//         middleSectionInsertPlaces[1].appendChild(usageDetailsButton);
//         var baloonElMob = document.getElementsByClassName("subscription__options_visual__baloon--mobile");
//
//         if (baloonElMob.length > 0) {
//             var baloonTextEl = document.getElementsByClassName("js-subscriptions_dashboard__baloon_text")[0];
//             baloonElMob[0].appendChild(baloonTextEl);
//         }
//     } else {
//         var baloonEl = document.getElementsByClassName("subscription__options_visual__baloon");
//
//         if (baloonEl.length === 0) {
//             middleSectionInsertPlaces[0].appendChild(usageDetailsWriteup);
//         } else {
//             middleSectionInsertPlaces[0].insertBefore(usageDetailsWriteup, baloonEl[0]);
//             baloonTextEl = document.getElementsByClassName("js-subscriptions_dashboard__baloon_text")[0];
//             baloonEl[0].appendChild(baloonTextEl);
//         }
//         middleSectionInsertPlaces[0].appendChild(usageDetailsButton);
//     }
// }














function contentBlockNavigation() {
    const contentBlockNavigationItems = document.querySelectorAll('.js-content-block__navigation');
    if (contentBlockNavigationItems.length === 0) return;

    for(var i = 0; i < contentBlockNavigationItems.length; i++) {
        item = contentBlockNavigationItems[i];
        item.addEventListener('click', function(event) {
            event.preventDefault();
            const contentBlock = this.closest('.js-content-block');
            if (!contentBlock) return;
            const grid = contentBlock.querySelector('.js-content-block__grid');
            const gridContent = grid.querySelector('.js-content-block__grid__content');

            const gridWidth = grid.scrollWidth;
            const gridContentWidth = gridContent.scrollWidth;

            const currentX = gridContent.scrollLeft;
            var newX = 0;
            var differenceX = 0;

            if(this.dataset.navigationDirection === 'left') {
                newX = Math.max(currentX - gridWidth, 0);
                differenceX = differenceX - gridWidth;
            } else if (this.dataset.navigationDirection === 'right') {
                newX = Math.min(currentX + gridWidth, gridContentWidth);
                differenceX = differenceX + gridWidth;
            }

            gridContent.scrollBy(differenceX, 0);
            // gridContent.scrollTo(newX, 0);
            // scrollToAnimation(gridContent, newX, 500, this.dataset.navigationDirection);
        });
    }
}

// todo: not working, but may be fixed
/*function scrollToAnimation(element, position, duration, direction) {
    const steps = 10;
    var positionParts = [];
    var i;

    if(direction === 'right') {
        for(i = 1; i <= steps; i++) {
            positionParts.push(element.scrollLeft + position * i / steps);
        }
    } else if (direction === 'left') {
        for(i = steps; i >= 0; i--) {
            positionParts.push(element.scrollLeft + position * i / steps);
        }
    }

    console.log(positionParts);

    intervalI = 0;

    var interval = setInterval(
        function() {
            if(intervalI === steps - 1) {
                clearInterval(interval);
            }
            element.scrollTo(positionParts[intervalI], 0);
            intervalI++;
        },
        duration / steps
    );
}*/










function selectionUpdater() {
    const selectionUpdaterItems = document.querySelectorAll('.js-selection-updater');

    for(var i = 0; i < selectionUpdaterItems.length; i++) {
        item = selectionUpdaterItems[i];

        selectionUpdaterSetter(item);

        item.addEventListener('change', function(event) {
            selectionUpdaterSetter(item);
        });
    }
}

function selectionUpdaterSetter(item) {
    var selection = item.querySelector(':checked');
    if(selection && selection.dataset.displayText) {
        item.querySelector('.js-selection-updater__text').innerHTML = selection.dataset.displayText;
    }
}
