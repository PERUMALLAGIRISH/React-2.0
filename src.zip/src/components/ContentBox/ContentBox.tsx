import * as React from 'react';
import { Link } from 'react-router-dom';

export interface ContentBoxProps {
  imageSource: string;
  label: string;
  href: string;
  data?: object;
}

export class ContentBox extends React.Component<ContentBoxProps> {
  constructor(props: ContentBoxProps) {
    super(props);
  }
  render(): React.ReactNode {
    const {label, imageSource, data, href} = this.props;
    return (
      <div className='content-box'>
        <Link to= {{
          pathname: href,
          state: data
          }} className='content-box__link'>
          <img className='content-box__link__icon' src={imageSource} />
          <span className='content-box__link__label'>
            {label}
          </span>
        </Link>
      </div>
    );
  }
}