import * as React from 'react';
import {Button} from '../../../components/Form/Button/Button';
import {Optional, DunningHistoryEntry} from '../../../model/types.d';
import I18n from '../../../utils/helper/I18n';

interface BillsDunningProps {
  dunningLevel: number;
  dunningHistory: Optional<(Optional<DunningHistoryEntry>)[]>;
  handleClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
}
interface BillsDunningState {
}

export class BillsDunning extends React.Component<BillsDunningProps, BillsDunningState> {
  constructor(props: BillsDunningProps) {
    super(props);
  }

  renderCurrentDunningStatus(): JSX.Element {
    const blockedOutgoingCalls: {__html: string} = {__html: I18n.translate('BillsDunning.BlockedOutgoingCalls.Text.Description')};
    return (
      <div className='form'>
        <div className='form-item'>
          <div className='form__label burgund'>
            {I18n.translate('BillsDunning.CurrentDunning.Label.Status')}
          </div>
          <div className='text-small' dangerouslySetInnerHTML={blockedOutgoingCalls}></div>
        </div>
      </div>
    );
  }
  renderNextAction(): JSX.Element {
    return (
      <div className='content-box content-box--bills_disable_warning content-box--icon__clock centered-text text-middle text-pad-lr-15perc'>
        {I18n.translate('BillsDunning.NextAction.Text.Title')}
      </div>
    );
  }

  renderDunningHistoryButton(): JSX.Element {
    const {handleClick} = this.props;
    return (
      <Button
        className='button cta-button dark_grey_text'
        label={I18n.translate('BillsDunning.OpenDunningHistory.Label.HistoryTitle')}
        handleClick={handleClick}
      />
    );
  }

  render(): React.ReactNode {
    return (
      <div className='l-col l-1of1 l-1of1-mobile'>
        <div className='content-box content-box--flexbox content-box--flexbox-mobile-column flex-align-items-center'>
          {this.renderCurrentDunningStatus()}
          {this.renderNextAction()}
          {this.renderDunningHistoryButton()}
        </div>
      </div>
    );
  }
}