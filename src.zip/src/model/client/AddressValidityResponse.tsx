import { AddressValidityStatus } from '../../model/types.d';
export interface AddressValidityResponse {
    addressValidity: AddressValidityStatus;
}