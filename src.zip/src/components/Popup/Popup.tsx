import * as React from 'react';

export interface PopupProps {
  title?: string | JSX.Element;
  data?: string[];
  buttonLabel?: string | JSX.Element;
  onClick?(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void;
}

export class Popup extends React.Component<PopupProps> {
  constructor(props: PopupProps) {
    super(props);
  }
  render(): React.ReactNode {
    const {data, title, onClick, buttonLabel} = this.props;
    const newdata: Array<string> = []
    if (data && data.length) {
      data.forEach((value: string, index: number) => {
        newdata.push(value);
      });
    }
    return (
      <React.Fragment>
        <div className='overlay'></div>
        <div className='popup__container'>
          <div className='popup'>
            <div className='popup-message-box'>
              <h2 className='popup-message-box__title'>{title}</h2>
              <p className='popup-message-box__text'>{newdata}
              </p>
              <div className='vertical_spacer x16'></div>
              <div className='form-item--flexbox form-item--flexbox--column-on-mobile'>
                <button className='button extra_wide full_width_on_mobile popup_single_default_button' onClick = {onClick}>{buttonLabel}</button>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
