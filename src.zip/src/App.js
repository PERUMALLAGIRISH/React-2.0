import 'babel-polyfill';
import ReactHabitat from 'react-habitat';
import ReduxDomFactory		from './ReduxDomFactory';
import ConfigureStore from './store/ConfigureStore';

class App extends ReactHabitat.Bootstrapper {

	constructor() {
    super();

    // Create a new container
    const containerBuilder = new ReactHabitat.ContainerBuilder();

    // Create a redux store
    const { store } = ConfigureStore();

    // Set the container to use our redux factory
    containerBuilder.factory = new ReduxDomFactory(store);

    // Register our components that we want to expose to the DOM
    containerBuilder.registerAsync(() => System.import('./components/Login/Login')).as('RLogin');
    containerBuilder.registerAsync(() => System.import('./components/Routes/RoutesProfile')).as('RProfile');
    containerBuilder.registerAsync(() => System.import('./components/Routes/RoutesBills')).as('RBills');
    containerBuilder.registerAsync(() => System.import('./components/Routes/RoutesSubscriptionDetail')).as('RSubscriptionDetail');

    // Set the DOM container
    this.setContainer(containerBuilder.build());
	}
}

export default new App();
