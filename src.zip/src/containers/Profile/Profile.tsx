import * as React from 'react';
import {
  Account,
  Address,
  BillInfo,
  BillingAddress,
  BillSettings,
  Optional,
  PayloadStatus,
  PaymentMethodType,
  SendVerificationEmailPayload,
  Subscriber
} from '../../model/types.d';
import {fetchAccount, validateEmail} from './ProfileAction';
import {DataList} from '../../components/DataList/DataList';
import {ContentBox} from '../../components/ContentBox/ContentBox';
import {ActionCreatorsMapObject, bindActionCreators, Dispatch} from 'redux';
import {WarningContent} from '../../components/WarningContent/WarningContent';
import {Popup} from '../../components/Popup/Popup';
import {ProfileEmailValidation} from './ProfileEmailValidation/ProfileEmailValidation';
import DateService from '../../utils/DateService';
import LanguageService from '../../utils/LanguageService';
import SegmentService from '../../utils/SegmentService';
import caseChange from 'change-case';
import Login from '../../components/Login/Login';
import {Loader} from '../../components/Loader/Loader';
import I18n from '../../utils/helper/I18n';
import {Segment} from '../../model/Segment.enum';
import {ProfileRoutes} from './ProfileRoutes.enum';
import {ProfileConstants} from './ProfileConstants';
import {History, Location} from 'history';
import {connect} from 'react-redux';
import {DataListConfig} from '../../components/DataList/DataListConfig';

export interface ProfileProps {
  account: Account;
  accountError: Error;
  accountFetchError: Error;
  sendVerificationEmailPayload: SendVerificationEmailPayload;
  sendVerificationEmailPayloadError: Error;
  imgMailVerify?: string;
  imgMailFailure?: string;
  imgMail?: string;
  imgBill?: string;
  imgRelocation?: string;
  history: History;
  location: Location;
  fetchAccount: () => void;
  validateEmail: () => void;
}

interface ProfileState {
  isLoading: boolean;
  isContactPopupOpen: boolean;
}

class Profile extends React.Component<ProfileProps, ProfileState> {
  constructor(props: ProfileProps) {
    super(props);
    this.state = {
      isLoading: false,
      isContactPopupOpen: false
    }
  }

  componentDidMount(): void {
    const {fetchAccount} = this.props;
    fetchAccount();
    window.addEventListener('resize', () => {
      this.resizeTitle();
    });
  }

  componentDidUpdate(): void {
    this.resizeTitle();
  }

  static getDerivedStateFromProps(nextProps: ProfileProps, prevState: ProfileState): any | null {
    if (nextProps && nextProps.accountFetchError) {
      window.location.reload();
    }
    if ((nextProps.account || nextProps.accountError) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  handleEmailValidation(event: React.MouseEvent<HTMLButtonElement>): void {
    const {validateEmail} = this.props;
    validateEmail();
    this.setState({
      isLoading: true
    });
  }

  renderDifferentAddress = (): JSX.Element | null => {
    const {account} = this.props;
    const owner: Subscriber = account.owner;
    const primaryAddress: Optional<Address> = account.primaryAddress;
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billingAddress: Optional<BillingAddress> = billInfo && billInfo.billingAddress;
    const differentBillingAddress:  Optional<Address> = billingAddress && billingAddress.differentBillingAddress;
    const billingStreetDetails: string = `${differentBillingAddress && differentBillingAddress.streetName ? differentBillingAddress.streetName : ''} ${ differentBillingAddress && differentBillingAddress.streetNumber ? differentBillingAddress.streetNumber : ''}`;
    const billingCityDetails: string = `${differentBillingAddress && differentBillingAddress.postalCode ? differentBillingAddress.postalCode : ''} ${differentBillingAddress && differentBillingAddress.town ? differentBillingAddress.town : ''}`;
    const billingName: string = `${(differentBillingAddress && differentBillingAddress.salutation ) ? caseChange.pascalCase(differentBillingAddress.salutation) : (primaryAddress && primaryAddress.salutation) ? caseChange.pascalCase(primaryAddress.salutation) : null } ${differentBillingAddress && differentBillingAddress.firstName ? differentBillingAddress.firstName : owner.firstName} ${differentBillingAddress && differentBillingAddress.lastName ? differentBillingAddress.lastName : owner.lastName}`;
    const differentBillingAddressItems: string[] = [];
    differentBillingAddressItems.push(billingName, billingStreetDetails, billingCityDetails);
    if (billingAddress && !billingAddress.sameAsCustomerAddress) {
      return (
        <DataList
          data = {differentBillingAddressItems}
          label = {I18n.translate('Profile.Label.BillingAddress')}
        />);
    }
    return null;
  }

  renderBillingAddress = (): JSX.Element => {
    const {account} = this.props;
    const owner: Subscriber = account.owner;
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billingAddress: string[] = [];
    let billingAddressLabel: string = I18n.translate('Profile.Label.AddressAndBillingAddressTitle');
    if (account.primaryAddress) {
      const streetDetails: string = `${account.primaryAddress.streetName || null} ${account.primaryAddress.streetNumber || null}`,
        cityDetails: string = `${account.primaryAddress.postalCode || null} ${account.primaryAddress.town || null}`;
      if (SegmentService.getCode() === Segment.SOHO && owner.companyName) {
        billingAddress.push(owner.companyName);
      }
      billingAddress.push(streetDetails, cityDetails);
    }
    if (billInfo && billInfo.billingAddress && !billInfo.billingAddress.sameAsCustomerAddress) {
      billingAddressLabel = I18n.translate('Profile.Label.AddressTitle');
    }
    return (
      <DataList
        data = {billingAddress}
        label = {billingAddressLabel}
      />
    )
  }

  renderEmailValidation = (): JSX.Element => {
    const {isLoading} = this.state;
    const {imgMailVerify, imgMailFailure} = this.props;
    return (
      <ProfileEmailValidation
        title= {I18n.translate('Profile.EmailValidation.Label.Title')}
        description= {I18n.translate('Profile.EmailValidation.Text.Description')}
        buttonLabel= {I18n.translate('Profile.EmailValidation.Button.SendValidation')}
        onClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handleEmailValidation(e)}
        isLoading = {isLoading}
        imgMailVerify = {imgMailVerify}
        imgMailFailure = {imgMailFailure}
      />);
  }

  renderEmailValidationResult = (emailValidationStatus: any): JSX.Element => {
    const {isLoading} = this.state;
    const {imgMailVerify, imgMailFailure} = this.props;
    const title: string = emailValidationStatus.payloadStatus === PayloadStatus.OK ? I18n.translate('Profile.EmailValidation.Label.SuccessTitle') : I18n.translate('Profile.EmailValidation.Label.ErrorTitle');
    const description: string = emailValidationStatus.payloadStatus === PayloadStatus.OK ? I18n.translate('Profile.EmailValidation.Text.SuccessDescription') : I18n.translate('Profile.EmailValidation.Text.ErrorDescription');
    if (emailValidationStatus.payloadStatus === PayloadStatus.OK) {
      emailValidationStatus = ProfileConstants.SUCCESS;
    }
    return (
      <ProfileEmailValidation
        title= {title}
        description= {description}
        buttonLabel= {I18n.translate('Profile.EmailValidation.Button.ResendValidation')}
        onClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handleEmailValidation(e)}
        result = {emailValidationStatus}
        isLoading = {isLoading}
        imgMailVerify = {imgMailVerify}
        imgMailFailure = {imgMailFailure}
      />);
  }

  renderEmailEmpty: (() => JSX.Element) = () => {
    return (
      <WarningContent
        title = {I18n.translate('Profile.EmailWarning.Label.Title')}
        data = {I18n.translate('Profile.EmailWarning.Text.Description')}
        buttonLabel = {I18n.translate('Profile.EmailWarning.Button.Label')}
        handleClick = {this.handleClick}
      />);
  }

  displayClosePopup(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
    const {isContactPopupOpen} = this.state;
    this.setState({
      isContactPopupOpen: !isContactPopupOpen
    });
  }

  handleClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {account, history} = this.props;
    history.push({
      pathname: ProfileRoutes.EDIT_PROFILE,
      state: account
    })
  }

  handlePasswordClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {history} = this.props;
    event.preventDefault();
    history.push({
      pathname: ProfileRoutes.CHANGE_PASSWORD
    })
  }

  renderSuccessUpdateContactDetails = (): JSX.Element | null => {
    const {imgMailVerify, location} = this.props;
    const label: string = location.state;
    if (label) {
      return (
        <ContentBox
          href= '#'
          imageSource = {imgMailVerify || ''}
          label = {label}
        />
      );
    }
    return null;
  }

  resizeTitle(): void {
    const titles: NodeListOf<Element> = document.querySelectorAll('.js-resize-title');
    [].forEach.call(titles, (title: any) => {
      title.removeAttribute('style');
      const scaleSecureMargin: number = 0.01; // to avoid potential scrolling
      const textSecureMargin: number = 15; // to avoid cutting text
      const titleElementWidth: number = title.scrollWidth + textSecureMargin;
      const titleTextWidth: number = title.clientWidth;
      const titleScaleRatio: number = Math.floor((titleTextWidth / titleElementWidth - scaleSecureMargin) * 100) / 100;
      const styleTransformScale: number = titleScaleRatio < 1 ? titleScaleRatio : 1;
      title.setAttribute('style', `width: ${titleElementWidth}px; transform: scale(${styleTransformScale}); -webkit-transform: scale(${styleTransformScale});`);
    });
  }

  renderEditPassword = (): JSX.Element => {
    return (
      <DataList
        label = {I18n.translate('Profile.Password.Label.PasswordTitle')}
        value= '• • • • • • • • •'
        isButton = {true}
        buttonLabel = {I18n.translate('Profile.EditPassword.Button.Edit')}
        handleClick = {this.handlePasswordClick}
      />
    );
  }

  renderEditProfile = (): JSX.Element => {
    const {imgMail} = this.props;
    return (
      <ContentBox
        href= {ProfileRoutes.EDIT_PROFILE}
        imageSource = {imgMail || ''}
        label = {I18n.translate('Profile.Label.ChangeMailTitle')}
      />
    );
  }

  renderChangeBillingAddress = (): JSX.Element => {
    const {account, imgBill} = this.props;
    return (
      <ContentBox
        href= {ProfileRoutes.CHANGE_BILLING_ADDRESS}
        imageSource = {imgBill || ''}
        label = {I18n.translate('Profile.Label.ChangeBillingAddressTitle')}
        data = {account}
      />
    );
  }

  renderReportToMove = (): JSX.Element => {
    const {imgRelocation} = this.props;
    return (
      <ContentBox
        href= ''
        imageSource = {imgRelocation || ''}
        label = {I18n.translate('Profile.Label.ReportMoveTitle')}
      />
    );
  }

  renderCustomerNumber = (): JSX.Element => {
    const {account} = this.props;
    return (
      <DataList
        label = {I18n.translate('Profile.Label.CustomerNumberTitle')}
        value= {account.id}
      />
    );
  }

  renderContact = (): JSX.Element => {
    const {account} = this.props;
    const owner: Subscriber = account.owner;
    const contactDetails: string[] = [];
    const dataListConfig: DataListConfig = {};
    if (owner.email) {
      contactDetails.push(owner.email);
      if (!owner.emailConfirmed) {
        dataListConfig.value = owner.email;
        dataListConfig.className = 'email__validate';
      }
    }
    if (owner.phone) {
      contactDetails.push(owner.phone);
    }
    if (owner.language) {
      contactDetails.push(LanguageService.getLanguageName(owner.language));
    }
    return (
      <DataList
        data = {contactDetails}
        label = {I18n.translate('Profile.Label.ContactTitle')}
        hasTooltip= {true}
        onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayClosePopup(e)}
        config = {dataListConfig}
      />
    );
  }

  renderBirthDate = (): JSX.Element => {
    const {account} = this.props;
    const owner: Subscriber = account.owner;
    return (
      <DataList
        label = {I18n.translate('Profile.Label.BirthdayTitle')}
        value= {owner.birthDate ? DateService.formatDate(owner.birthDate) : I18n.translate('Profile.Label.BirthdayNotAvailable')}
        isButton = {true}
        buttonLabel = {I18n.translate('Profile.Button.Edit')}
        handleClick = {this.handleClick}
      />
    );
  }

  renderContactTooltip = (): JSX.Element => {
    return (
      <Popup
        title = {I18n.translate('Profile.ToolTip.ContactTitle')}
        data = {[I18n.translate('Profile.ToolTip.ContactDescription')]}
        buttonLabel = {I18n.translate('Profile.ToolTip.ContactButton')}
        onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayClosePopup(e)}
      />);
  }

  render(): React.ReactNode {
    const {accountError, account, sendVerificationEmailPayloadError, sendVerificationEmailPayload} = this.props;
    const {isContactPopupOpen} = this.state;
    if (accountError ) {
      return (<Login />);
    }
    if (!account) {
      return (<Loader />);
    }
    const owner: Subscriber = account.owner;
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const paymentMethod: Optional<PaymentMethodType> = billSettings && billSettings.paymentMethod;
    const emailValidation: JSX.Element[] = [];
    if (owner.email && !owner.emailConfirmed) {
      if (!sendVerificationEmailPayload) {
        if (sendVerificationEmailPayloadError) {
          emailValidation.push(this.renderEmailValidationResult(PayloadStatus.NOK));
        } else {
          emailValidation.push(this.renderEmailValidation());
        }
      } else {
        emailValidation.push(this.renderEmailValidationResult(sendVerificationEmailPayload));
      }
    }
    if (!owner.firstName && !owner.lastName) {
      return ( <div className='load_spinner'>{I18n.translate('Profile.Label.LoadingTitle')}</div> );
    }

    return (
      <div className='l-center-l'>
        {!owner.email ? this.renderEmailEmpty() : null}
        {isContactPopupOpen ? this.renderContactTooltip() : null}
        <div className='l-grid'>
          <div className='l-col l-1of1'>
            <div className='l-flexbox-row'>
              <div className='l-col-flexbox l-col-flexbox-60 l-col-flexbox-even'>
                <div className='content-box'>
                  <div className='page-title-wrapper'>
                    <div className='page-title--rainbow js-resize-title'>{owner.firstName} {owner.lastName}</div>
                  </div>
                  <div className='form'>
                    {this.renderCustomerNumber()}
                    {this.renderBillingAddress()}
                    {this.renderDifferentAddress()}
                    {this.renderContact()}
                    {this.renderBirthDate()}
                  </div>
                </div>
              </div>
              <div className='l-col-flexbox l-col-flexbox-40 l-col-flexbox-even'>
                {this.renderSuccessUpdateContactDetails()}
                {emailValidation}
                <div className='content-box content-box--icon content-box--icon__password'>
                  <div className='form'>
                    {this.renderEditPassword()}
                  </div>
                </div>
                {SegmentService.getCode() !== Segment.SOHO ? this.renderReportToMove() : null }
                {this.renderEditProfile()}
                {paymentMethod && paymentMethod !== PaymentMethodType.EBILL ? this.renderChangeBillingAddress() : null}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps: any = ({ profileReducer }: any) => {
  return {
    account: profileReducer.account,
    accountError: profileReducer.accountError,
    accountFetchError: profileReducer.accountFetchError,
    sendVerificationEmailPayload: profileReducer.sendVerificationEmailPayload,
    sendVerificationEmailPayloadError: profileReducer.sendVerificationEmailPayloadError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({ fetchAccount, validateEmail }, dispatch);
};

export default connect<ProfileProps>(mapStateToProps, mapDispatchToProps)(Profile);
