import { PaymentState } from '../../model/types.d';

export interface PaymentStateResponse {
  paymentState: PaymentState;
}