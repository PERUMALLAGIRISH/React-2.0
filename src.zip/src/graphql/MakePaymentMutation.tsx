import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const makePaymentMutation: DocumentNode = gql`
    mutation makePayment($input: PaymentInput!) {
        makePayment(input: $input) {
            payloadStatus
        }
    }
`;

export default makePaymentMutation;