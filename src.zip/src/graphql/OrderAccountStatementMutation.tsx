import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const orderAccountStatementMutation: DocumentNode = gql`
  mutation orderAccountStatement($input: OrderAccountStatementInput!) {
    orderAccountStatement(input: $input) {
      payloadStatus
    }
  }
`;

export default orderAccountStatementMutation;