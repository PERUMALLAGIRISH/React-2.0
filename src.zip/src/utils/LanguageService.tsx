class LanguageService {
    getLanguageName(languageCode: string): string {
        switch (languageCode) {
            case 'EN': return 'English';
            case 'DE': return 'German';
            case 'FR': return 'French';
            case 'IT': return 'Italian';
            default:
            return 'German';
        }
    }

    getLanguageOptions (): Array<object> {
        return [{name: 'English', value: 'EN'}, {name: 'German', value: 'DE'}, {name: 'French', value: 'FR'}, {name: 'Italian', value: 'IT'}];
    }
}

export default new LanguageService();