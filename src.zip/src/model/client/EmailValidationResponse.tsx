import { EmailValidationStatus } from '../../model/types.d';
export interface EmailValidationResponse {
  sendVerificationEmail: EmailValidationStatus;
}