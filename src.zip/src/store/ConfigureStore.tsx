/**
 * Description: To configure store with initial reducer
 */
import {createStore, applyMiddleware, Reducer, Store} from 'redux';
import appReducer from '../reducers/Reducer';
import thunk from 'redux-thunk';
import { persistStore, persistReducer, PersistConfig, Persistor } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
const persistConfig: PersistConfig = {
  key: 'root',
  blacklist: ['profileReducer', 'billsReducer', 'registeredCardReducer', 'paymentReducer', 'subscriptionDetailChangeOwnerReducer', 'changeOwner', 'sendChangeOwner'],
  storage
};
const persistedReducer: Reducer = persistReducer(persistConfig, appReducer);
export default () => {
  const store: Store = createStore(persistedReducer,
    applyMiddleware(thunk));
  const persistor: Persistor = persistStore(store);
  return { store, persistor };
};
