export type Optional<T> = T | null | undefined;

export interface AddressValidityInput {
  postalCode: string;

  streetName: string;

  streetNumber: string;

  town: string;

  additional?: Optional<string>;

  minConfidence?: Optional<number>;
}

export interface PpaInstallmentOptionsInput {
  amount: number;
}

export interface SetBillingAddressInput {
  sameAsCustomerAddress?: Optional<boolean>;

  differentBillingAddress?: Optional<AddressInput>;
}

export interface AddressInput {
  salutation?: Optional<Salutation>;

  countryIsocode?: Optional<string>;

  firstName?: Optional<string>;

  lastName?: Optional<string>;

  postalCode?: Optional<string>;

  streetName?: Optional<string>;

  streetNumber?: Optional<string>;

  town?: Optional<string>;
}

export interface BillAnonymizationLevelInput {
  billAnonymizationLevel: BillAnonymizationLevel;
}

export interface OrderAccountStatementInput {
  accountStatementMethod: AccountStatementMethod;
}

export interface OrderBillCopyInput {
  billId?: Optional<string>;
}

export interface SetBillDeliveryMethodInput {
  billDeliveryMethod: BillDeliveryMethod;

  billDeliveryNotification?: Optional<BillDeliveryNotificationInput>;
}

export interface BillDeliveryNotificationInput {
  emailAddress?: Optional<string>;

  contactNumbers?: Optional<(Optional<string>)[]>;
}

export interface PaymentMethodTypeInput {
  paymentMethodType: PaymentMethodType;
}

export interface OrderAdditionalPaymentSlipInput {
  amount?: Optional<number>;
}

export interface PaymentInput {
  amount: number;

  paymentTransaction: PaymentTransaction;
}

export interface PaymentTransaction {
  /** Authorization code returned by credit card issuing bank (length depending on payment method) */
  acqAuthorizationCode: string;
  /** Original authorization code */
  authorizationCode: string;
  /** Unique transaction identifier */
  uppTransactionId: string;

  merchantId: string;
  /** Payment Card */
  paymentCard?: Optional<PaymentCard>;
  /** Payment Service */
  paymentService?: Optional<PaymentServiceType>;

  useAlias?: Optional<boolean>;
  /** Alias for credit card number, for PostFinance or for PayPal Reference Transactions */
  aliasCc?: Optional<string>;
  /** Expiry month of the card */
  expiryMonth?: Optional<string>;
  /** Expiry year of the card */
  expiryYear?: Optional<string>;
  /** Number */
  number?: Optional<string>;
}

export interface DeleteRegisteredCardInput {
  registeredCard: RegisteredCardInput;
}

export interface RegisteredCardInput {
  aliasCc: string;

  expiryMonth: string;

  expiryYear: string;

  number: string;

  paymentCard: PaymentCard;
}

export interface UpdateContactInput {
  email?: Optional<string>;

  languageCode?: Optional<Language>;

  phone?: Optional<string>;
}

export interface UpdatePasswordInput {
  newPassword: string;

  oldPassword: string;
}

export interface MakePpaAgreementInput {
  /** invoiceIds */
  invoiceIds?: Optional<(Optional<string>)[]>;
  /** sapDocumentIds */
  sapDocumentIds?: Optional<(Optional<string>)[]>;
  /** invoicesAmount */
  invoicesAmount: number;
  /** installment */
  numberOfInstallments?: Optional<number>;
}

export enum Language {
  EN = 'EN',
  DE = 'DE',
  FR = 'FR',
  IT = 'IT'
}

export enum OpenIn {
  NATIVE = 'NATIVE',
  WEBVIEW = 'WEBVIEW',
  BROWSER = 'BROWSER',
  POPUP = 'POPUP'
}

export enum BucketCategory {
  MOBILE_DATA = 'MOBILE_DATA',
  FIXNET = 'FIXNET',
  VOICE = 'VOICE',
  TV = 'TV',
  MESSAGES = 'MESSAGES'
}

export enum GroupType {
  NATIONAL = 'NATIONAL',
  INTERNATIONAL = 'INTERNATIONAL',
  ROAMING = 'ROAMING'
}

export enum BucketCredit {
  DATA = 'DATA',
  SMS = 'SMS',
  MMS = 'MMS',
  VOICE = 'VOICE',
  WHATSAPP = 'WHATSAPP',
  SNAPCHAT = 'SNAPCHAT'
}

export enum BillDeliveryMethod {
  EMAIL_WITH_LINK = 'EMAIL_WITH_LINK',
  EMAIL_WITH_BILL_IN_PDF_FORMAT = 'EMAIL_WITH_BILL_IN_PDF_FORMAT',
  PAPER_BILL_WITHOUT_CALL_DETAILS = 'PAPER_BILL_WITHOUT_CALL_DETAILS',
  PAPER_BILL_WITH_CALL_DETAILS = 'PAPER_BILL_WITH_CALL_DETAILS'
}

export enum BillAnonymizationLevel {
  NONE = 'NONE',
  LAST_4_DIGITS = 'LAST_4_DIGITS',
  LAST_2_DIGITS = 'LAST_2_DIGITS'
}

export enum PaymentMethodType {
  PAY_SLIP = 'PAY_SLIP',
  DIRECT_DEBIT = 'DIRECT_DEBIT',
  EBILL = 'EBILL'
}

export enum RatePlanType {
  MOBILE_PREPAID = 'MOBILE_PREPAID',
  MOBILE_POSTPAID = 'MOBILE_POSTPAID',
  TV = 'TV',
  LANDLINE_PHONE = 'LANDLINE_PHONE',
  FIX_INTERNET = 'FIX_INTERNET',
  UNDEFINED = 'UNDEFINED'
}

export enum BucketMeasureUnit {
  SECOND = 'SECOND',
  MINUTE = 'MINUTE',
  VOICE = 'VOICE',
  CHF = 'CHF',
  SMS = 'SMS',
  MMS = 'MMS',
  KB = 'KB',
  MB = 'MB',
  GB = 'GB',
  GBPS = 'GBPS',
  MBPS = 'MBPS',
  PIECE = 'PIECE'
}

export enum BucketType {
  LIMITED = 'LIMITED',
  UNLIMITED = 'UNLIMITED',
  THROTTLED = 'THROTTLED',
  NOT_INCLUDED = 'NOT_INCLUDED'
}

export enum RatePlanLifecycle {
  ACTIVE = 'ACTIVE',
  OBSOLETE = 'OBSOLETE'
}

export enum BillDocumentType {
  B1 = 'B1',
  YP = 'YP',
  YT = 'YT',
  YU = 'YU',
  YW = 'YW',
  CH = 'CH',
  YC = 'YC',
  MB = 'MB',
  IP = 'IP',
  RT = 'RT'
}

export enum BillStatus {
  NEW = 'NEW',
  OPEN = 'OPEN',
  PARTIALY_CLOSED = 'PARTIALY_CLOSED',
  CLOSED = 'CLOSED',
  IN_DISPUTE = 'IN_DISPUTE',
  DUNNED = 'DUNNED',
  OVERDUE = 'OVERDUE'
}

export enum Salutation {
  MR = 'MR',
  MRS = 'MRS',
  MS = 'MS',
  HERR = 'HERR',
  FRAU = 'FRAU',
  SIGNOR = 'SIGNOR',
  SIGNORA = 'SIGNORA',
  MONSIEUR = 'MONSIEUR',
  MADAME = 'MADAME'
}

export enum PaymentCard {
  ECA = 'ECA',
  VIS = 'VIS',
  AMX = 'AMX',
  PEF = 'PEF',
  PFC = 'PFC'
}

export enum PaymentMethodOption {
  CREDIT_CARD = 'CREDIT_CARD',
  REGISTERED_CARD = 'REGISTERED_CARD',
  E_BANKING = 'E_BANKING',
  PAYMENT_SLIP = 'PAYMENT_SLIP',
  PAYMENT_SERVICE = 'PAYMENT_SERVICE'
}

export enum PaymentServiceType {
  MPW = 'MPW',
  PAP = 'PAP'
}

export enum EmailValidationStatus {
  VALID = 'VALID',
  INVALID = 'INVALID'
}

export enum EmailValidationMessage {
  BAD_ADDRESS = 'BAD_ADDRESS',
  DOMAIN_NOT_QUALIFIED = 'DOMAIN_NOT_QUALIFIED',
  MX_LOOKUP_ERROR = 'MX_LOOKUP_ERROR',
  NO_REPLY_ADDRESS = 'NO_REPLY_ADDRESS',
  ADDRESS_REJECTED = 'ADDRESS_REJECTED',
  SERVER_UNAVAILABLE = 'SERVER_UNAVAILABLE',
  ADDRESS_UNAVAILABLE = 'ADDRESS_UNAVAILABLE',
  DOMAIN_MISSPELLED = 'DOMAIN_MISSPELLED',
  VALIDATION_DELAYED = 'VALIDATION_DELAYED',
  RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED',
  API_KEY_INVALID = 'API_KEY_INVALID',
  TASK_ACCEPTED = 'TASK_ACCEPTED',
  LOCAL_ADDRESS = 'LOCAL_ADDRESS',
  IP_ADDRESS_LITERAL = 'IP_ADDRESS_LITERAL',
  DISPOSABLE_ADDRESS = 'DISPOSABLE_ADDRESS',
  ROLE_ADDRESS = 'ROLE_ADDRESS',
  DUPLICATE_ADDRESS = 'DUPLICATE_ADDRESS',
  SERVER_REJECT = 'SERVER_REJECT',
  VALID_ADDRESS = 'VALID_ADDRESS',
  CATCH_ALL_ACTIVE = 'CATCH_ALL_ACTIVE',
  CATCH_ALL_TEST_DELAYED = 'CATCH_ALL_TEST_DELAYED',
  VALIDATION_OFF = 'VALIDATION_OFF',
  REGULAR_EXP_ERROR = 'REGULAR_EXP_ERROR',
  TECHNICAL_ERROR = 'TECHNICAL_ERROR'
}

export enum AddressValidityStatus {
  VALID = 'VALID',
  INVALID = 'INVALID',
  SUGGESTION = 'SUGGESTION'
}

export enum PayloadStatus {
  OK = 'OK',
  NOK = 'NOK'
}

export enum AccountStatementMethod {
  EMAIL = 'EMAIL',
  POST = 'POST'
}

export type LocalDate = any;

export type DateTime = string;

// ====================================================
// Scalars
// ====================================================

// ====================================================
// Types
// ====================================================

export interface Query {
  config: ConfigGql;

  account?: Optional<Account>;

  inAppNotifications: InAppNotification[];

  countries?: Optional<(Optional<Country>)[]>;

  paymentState: PaymentState;

  emailValidationState: EmailValidationState;

  addressValidity: AddressValidity;

  ppaInstallmentOptions?: Optional<PpaInstallmentOption[]>;
}

export interface ConfigGql {
  quickLinkConfig?: Optional<QuickLinkConfig>;

  serviceWidget?: Optional<ServiceWidget>;

  notificationCenterConfig?: Optional<NotificationCenterConfig>;

  bannerInfo?: Optional<BannerInfo>;

  billConfig?: Optional<BillConfig>;

  menu?: Optional<MenuWidget>;

  appSettings?: Optional<AppSettings>;
}

export interface QuickLinkConfig {
  canEditQuickLinks?: Optional<boolean>;

  dashboardComponentTitle: string;

  dashboardComponentActionTitle: string;

  manageScreenTitle: string;

  manageScreenText: string;

  manageScreenIncludedTitle: string;

  manageScreenMoreTitle: string;

  quickLinks?: Optional<QuickLink[]>;
}

export interface QuickLink {
  id: string;

  name: string;

  icon?: Optional<string>;

  action?: Optional<ClickableAction>;
}

export interface ClickableAction {
  link?: Optional<string>;

  openIn?: Optional<OpenIn>;
}

/** SUBSCRIPTIONS - UI */
export interface ServiceWidget {
  serviceSelectorWidget?: Optional<ServiceSelectorWidget>;

  serviceTabs?: Optional<ServiceTab[]>;

  groups?: Optional<(Optional<GroupConfig>)[]>;

  usageWidget?: Optional<UsageWidget>;

  fixnetWidget?: Optional<FixnetWidget>;

  tvWidget?: Optional<TvWidget>;

  ongoingCostWidget?: Optional<OngoingCostWidget>;

  remainingBalanceWidget?: Optional<RemainingBalanceWidget>;

  roamingWidget?: Optional<RoamingWidget>;
}

export interface ServiceSelectorWidget {
  viewAllButton?: Optional<Button>;

  outOfSubscriptionsText?: Optional<string>;

  manageButton?: Optional<Button>;
}

export interface Button {
  text?: Optional<string>;

  link?: Optional<string>;

  openIn?: Optional<OpenIn>;
}

export interface ServiceTab {
  bucketCategory: BucketCategory;

  iconSelected: string;

  iconUnselected: string;

  text: string;
}

export interface GroupConfig {
  group?: Optional<GroupType>;

  name?: Optional<string>;

  description?: Optional<string>;
}

export interface UsageWidget {
  unlimitedSocialSingleText?: Optional<string>;

  unlimitedSocialMultipleText?: Optional<string>;

  bucketWidgets?: Optional<(Optional<BucketWidget>)[]>;

  bucketCreditConfigs?: Optional<(Optional<BucketCreditConfig>)[]>;

  buyOptionButton?: Optional<Button>;
}

export interface BucketWidget {
  bucketCategory: BucketCategory;

  usedColors: string[];

  remainingColors: string[];
}

export interface BucketCreditConfig {
  bucketCredit: BucketCredit;

  bucketCreditName?: Optional<string>;

  unlimitedPatternTop?: Optional<string>;

  unlimitedPatternCenter?: Optional<string>;

  unlimitedPatternBottom?: Optional<string>;

  throttledPatternTop?: Optional<string>;

  throttledPatternCenter?: Optional<string>;

  throttledPatternBottom?: Optional<string>;

  notIncludedPatternTop?: Optional<string>;

  notIncludedPatternCenter?: Optional<string>;

  notIncludedPatternBottom?: Optional<string>;
}

export interface FixnetWidget {
  subtitle?: Optional<string>;

  downloadIcon?: Optional<string>;

  downloadText?: Optional<string>;

  uploadIcon?: Optional<string>;

  uploadText?: Optional<string>;

  connectionTestTitle?: Optional<string>;

  connectionTestSubtitle?: Optional<string>;

  connectionTestButton?: Optional<Button>;
}

export interface TvWidget {
  title?: Optional<string>;

  subtitle?: Optional<string>;

  backgroundImage?: Optional<string>;

  icon?: Optional<string>;

  button?: Optional<Button>;
}

export interface OngoingCostWidget {
  icon?: Optional<string>;

  title: string;

  subtitle?: Optional<string>;

  button?: Optional<Button>;
}

export interface RemainingBalanceWidget {
  icon?: Optional<string>;

  title: string;

  subtitle?: Optional<string>;

  button?: Optional<Button>;
}

export interface RoamingWidget {
  icon?: Optional<string>;

  title: string;

  subtitle?: Optional<string>;

  button?: Optional<Button>;
}

export interface NotificationCenterConfig {
  notificationCenterTitle?: Optional<string>;

  notificationCenterSubtitle?: Optional<string>;

  newSectionTitle?: Optional<string>;

  viewedSectionTitle?: Optional<string>;
}

export interface BannerInfo {
  title?: Optional<string>;

  button?: Optional<Button>;

  bannerTags: BannerTag[];

  banners: Banner[];
}

export interface BannerTag {
  id: string;

  button?: Optional<Button>;
}

export interface Banner {
  id: string;

  content: string;

  action: ClickableAction;
}

export interface BillConfig {
  dashboardBillWidget?: Optional<DashboardBillWidget>;

  billOverviewScreen?: Optional<BillOverviewScreen>;

  paymentDeferralScreen?: Optional<PaymentDeferralScreen>;

  instantDeblockingScreen?: Optional<InstantDeblockingScreen>;

  dunningOverviewScreen?: Optional<DunningOverviewScreen>;

  changeBillingAddressScreen?: Optional<ChangeBillingAddressScreen>;

  invoiceSettingsScreen?: Optional<InvoiceSettingsScreen>;

  billDeliveryAndFormatScreen?: Optional<BillDeliveryAndFormatScreen>;

  billSummaryScreen?: Optional<BillSummaryScreen>;

  requestAccountStatementScreen?: Optional<RequestAccountStatementScreen>;

  orderBillCopyScreen?: Optional<OrderBillCopyScreen>;

  paymentMethodScreen?: Optional<PaymentMethodScreen>;

  digitalInvoiceScreen?: Optional<DigitalInvoiceScreen>;

  makePaymentScreen?: Optional<MakePaymentScreen>;

  registerCreditCardScreen?: Optional<RegisterCreditCardScreen>;

  dunningLevels?: Optional<(Optional<DunningLevelConfig>)[]>;
}

export interface DashboardBillWidget {
  title?: Optional<string>;

  icon?: Optional<string>;

  billDueText?: Optional<string>;

  button?: Optional<Button>;
}

export interface BillOverviewScreen {
  screenTitle?: Optional<string>;

  screenDescription?: Optional<string>;

  billsSection?: Optional<BillsSection>;

  outstandingAmountSection?: Optional<OutstandingAmountSection>;

  billSummarySection?: Optional<DescriptionSection>;

  invoiceSettingsSection?: Optional<DescriptionSection>;

  registerCreditCardSection?: Optional<DescriptionSection>;

  dunningConfig?: Optional<DunningConfig>;
}

export interface BillsSection {
  title?: Optional<string>;

  billTitle?: Optional<string>;

  dueOnText?: Optional<string>;
}

export interface OutstandingAmountSection {
  title?: Optional<string>;

  titleTooltip?: Optional<Tooltip>;

  needMoreTimeButtonText?: Optional<string>;

  payNowButtonText?: Optional<string>;
}

export interface Tooltip {
  text?: Optional<string>;

  title?: Optional<string>;
}

export interface DescriptionSection {
  title?: Optional<string>;

  description?: Optional<string>;

  descriptionTooltip?: Optional<Tooltip>;
}

export interface DunningConfig {
  dunningJokerButtonText?: Optional<string>;

  payNowButtonText?: Optional<string>;

  deblockButtonText?: Optional<string>;

  overdueAmountText?: Optional<string>;

  payNowDescription?: Optional<string>;

  nextStepText?: Optional<string>;

  deblockDescription?: Optional<string>;
}

export interface PaymentDeferralScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  text?: Optional<string>;

  cancelButtonText?: Optional<string>;

  paymentDeferralButton?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;
}

export interface PopupInfo {
  ok?: Optional<PopupInfoOk>;

  error?: Optional<PopupInfoError>;
}

export interface PopupInfoOk {
  title?: Optional<string>;

  text?: Optional<string>;

  buttonText?: Optional<string>;
}

export interface PopupInfoError {
  title?: Optional<string>;

  text?: Optional<string>;

  buttonText?: Optional<string>;
}

export interface InstantDeblockingScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  explanation?: Optional<string>;

  instructionsTitle?: Optional<string>;

  instructions?: Optional<string>;

  cancelButtonText?: Optional<string>;

  deblockNowButtonText?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;
}

export interface DunningOverviewScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;
}

export interface ChangeBillingAddressScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  step1?: Optional<ChangeBillingAddressStep1>;

  step2?: Optional<ChangeBillingAddressStep2>;
}

export interface ChangeBillingAddressStep1 {
  title?: Optional<string>;

  optionSame?: Optional<string>;

  optionDifferent?: Optional<string>;

  buttonCancelText?: Optional<string>;

  buttonNextText?: Optional<string>;

  differentAddressForm?: Optional<DifferentAddressForm>;
}

export interface DifferentAddressForm {
  titleField?: Optional<string>;

  firstNameField?: Optional<string>;

  lastNameField?: Optional<string>;

  streetField?: Optional<string>;

  streetNoField?: Optional<string>;

  addressLine2Field?: Optional<string>;

  zipCodeField?: Optional<string>;

  cityField?: Optional<string>;

  countryField?: Optional<string>;
}

export interface ChangeBillingAddressStep2 {
  title?: Optional<string>;

  description?: Optional<string>;

  currentBillingAddressTitle?: Optional<string>;

  newBillingAddressTitle?: Optional<string>;

  newSameBillingAddressDescription?: Optional<string>;

  buttonCancelText?: Optional<string>;

  buttonSaveText?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;
}

/** Invoice Settings Screen */
export interface InvoiceSettingsScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  deliverySection?: Optional<DeliverySection>;

  paymentMethodSection?: Optional<PaymentMethodSection>;

  billingAddressSection?: Optional<BillingAddressSection>;
}

export interface DeliverySection {
  title?: Optional<string>;

  deliveryMethodTitle?: Optional<string>;

  deliveryMethodTexts?: Optional<(Optional<DeliveryMethodText>)[]>;

  formatTitle?: Optional<string>;

  formatTexts?: Optional<(Optional<FormatText>)[]>;

  displayOfNumbersTitle?: Optional<string>;

  displayOfNumbersTexts?: Optional<(Optional<DisplayOfNumbersText>)[]>;
}

export interface DeliveryMethodText {
  name?: Optional<BillDeliveryMethod>;

  text?: Optional<string>;
}

export interface FormatText {
  name?: Optional<BillDeliveryMethod>;

  text?: Optional<string>;
}

export interface DisplayOfNumbersText {
  name?: Optional<BillAnonymizationLevel>;

  text?: Optional<string>;
}

export interface PaymentMethodSection {
  title?: Optional<string>;

  paymentMethodTexts?: Optional<(Optional<PaymentMethodText>)[]>;
}

export interface PaymentMethodText {
  name?: Optional<PaymentMethodType>;

  text?: Optional<string>;
}

export interface BillingAddressSection {
  title?: Optional<string>;

  ebillTooltip?: Optional<Tooltip>;
}

/** BillDeliveryAndFormatScreen - BillsConfig */
export interface BillDeliveryAndFormatScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  numberDisplaySection?: Optional<NumberDisplaySection>;

  deliveryMethodSection?: Optional<DeliveryMethodSection>;

  popupInfo?: Optional<PopupInfo>;
}

export interface NumberDisplaySection {
  title?: Optional<string>;

  subtitle?: Optional<string>;

  tooltip?: Optional<Tooltip>;

  displayOfNumbersTexts?: Optional<(Optional<DisplayOfNumbersText>)[]>;
}

export interface DeliveryMethodSection {
  title?: Optional<string>;

  paper?: Optional<string>;

  email?: Optional<string>;

  emailTitle?: Optional<string>;

  subtitle?: Optional<string>;

  buttonCancelText?: Optional<string>;

  buttonSaveText?: Optional<string>;

  deliveryMethods?: Optional<(Optional<DeliveryMethod>)[]>;

  notificationViaSms?: Optional<NotificationViaSms>;

  cantChangeBecauseEbillText?: Optional<string>;

  caseEmail?: Optional<DeliveryMethodSectionCaseEmail>;

  casePaper?: Optional<DeliveryMethodSectionCasePaper>;
}

export interface DeliveryMethod {
  name?: Optional<BillDeliveryMethod>;

  title?: Optional<string>;

  subtitle?: Optional<string>;

  tooltip?: Optional<Tooltip>;
}

export interface NotificationViaSms {
  title?: Optional<string>;

  noNotificationText?: Optional<string>;

  tooltip?: Optional<Tooltip>;
}

export interface DeliveryMethodSectionCaseEmail {
  noEmailText?: Optional<string>;

  noEmailButton?: Optional<Button>;

  validatedEmailText?: Optional<string>;

  validatedEmailButton?: Optional<Button>;

  notValidatedEmailText?: Optional<string>;

  notValidatedEmailButton?: Optional<Button>;
}

export interface DeliveryMethodSectionCasePaper {
  text?: Optional<string>;
}

export interface BillSummaryScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  noBillsText?: Optional<string>;

  billNumberText?: Optional<string>;

  detailsText?: Optional<string>;

  copyByPostText?: Optional<string>;

  pdfCopyText?: Optional<string>;

  requestAccountStatementButtonText?: Optional<string>;
}

export interface RequestAccountStatementScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  description?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;

  cancelButtonText?: Optional<string>;

  actionTitle?: Optional<string>;

  emailText?: Optional<string>;

  emailTooltip?: Optional<Tooltip>;

  emailAddressFieldText?: Optional<string>;

  emailAddressFieldDescription?: Optional<string>;

  changeEmailAddressUrl?: Optional<ClickableAction>;

  copyByPostText?: Optional<string>;

  copyByPostTooltip?: Optional<Tooltip>;

  orderButtonText?: Optional<string>;
}

export interface OrderBillCopyScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  invoiceNumberText?: Optional<string>;

  invoiceDateText?: Optional<string>;

  description?: Optional<string>;

  cancelButtonText?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;

  requestButtonText?: Optional<string>;
}

export interface PaymentMethodScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;

  title?: Optional<string>;

  paymentMethods?: Optional<(Optional<PaymentMethod>)[]>;

  directDebitSection?: Optional<DirectDebitSection>;

  ebillSection?: Optional<EbillSection>;

  buttonCancelText?: Optional<string>;

  buttonNextText?: Optional<string>;

  buttonOkText?: Optional<string>;
}

export interface PaymentMethod {
  name?: Optional<PaymentMethodType>;

  title?: Optional<string>;
}

export interface DirectDebitSection {
  bankDetailsDescription?: Optional<string>;

  bankDetailsTitle?: Optional<string>;

  formFields?: Optional<DirectDebitFormFields>;

  directDebitPdfScreen?: Optional<DirectDebitPdfScreen>;
}

export interface DirectDebitFormFields {
  bankName?: Optional<string>;

  zipCode?: Optional<string>;

  city?: Optional<string>;

  iban?: Optional<string>;

  ibanTooltip?: Optional<Tooltip>;

  nameHolder?: Optional<string>;

  nameHolderTooltip?: Optional<Tooltip>;
}

export interface DirectDebitPdfScreen {
  pageTitle?: Optional<string>;

  descriptionTop?: Optional<string>;

  lsvPdfIconText?: Optional<string>;

  lsvPdfUrl?: Optional<string>;

  descriptionBottom?: Optional<string>;

  closeButtonText?: Optional<string>;
}

export interface EbillSection {
  title?: Optional<string>;

  description?: Optional<string>;
}

export interface DigitalInvoiceScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;
}

export interface MakePaymentScreen {
  step2PaymentSlip?: Optional<MakePaymentScreenStep2PaymentSlip>;

  pageTitle?: Optional<string>;

  step2Cc?: Optional<MakePaymentScreenStep2Cc>;

  step2RegisteredCc?: Optional<MakePaymentScreenStep2RegisteredCc>;

  pageDescription?: Optional<string>;

  step1?: Optional<MakePaymentScreenStep1>;
}

export interface MakePaymentScreenStep2PaymentSlip {
  subtitle?: Optional<string>;

  description?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;

  title?: Optional<string>;
}

export interface MakePaymentScreenStep2Cc {
  accountNoText?: Optional<string>;

  paymentForTitle?: Optional<string>;

  amountTitle?: Optional<string>;

  referenceNoTitle?: Optional<string>;

  subtitle?: Optional<string>;

  nextButtonText?: Optional<string>;

  billingInfoTitle?: Optional<string>;

  paymentForText?: Optional<string>;

  popupInfo?: Optional<PopupInfo>;

  title?: Optional<string>;

  cancelButtonText?: Optional<string>;
}

export interface MakePaymentScreenStep2RegisteredCc {
  popupInfo?: Optional<PopupInfo>;
}

export interface MakePaymentScreenStep1 {
  paymentAmountSection?: Optional<MakePaymentAmountSection>;

  paymentMethodSection?: Optional<MakePaymentMethodSection>;

  subtitle?: Optional<string>;

  nextButtonText?: Optional<string>;

  title?: Optional<string>;

  cancelButtonText?: Optional<string>;
}

export interface MakePaymentAmountSection {
  title?: Optional<string>;

  totalText?: Optional<string>;

  overdueText?: Optional<string>;
}

export interface MakePaymentMethodSection {
  title?: Optional<string>;

  saveCcText?: Optional<string>;

  cctooltip?: Optional<Tooltip>;

  ccText?: Optional<string>;

  registeredCcText?: Optional<string>;

  registeredCctooltip?: Optional<Tooltip>;

  ebankingText?: Optional<string>;

  paypal?: Optional<string>;

  payslipViaMail?: Optional<string>;
}

export interface RegisterCreditCardScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  pageExplanation?: Optional<string>;

  ccNoCreditCardSavedText?: Optional<string>;

  addCreditCardButtonText?: Optional<string>;

  registerCcExplanation?: Optional<string>;

  ccDetailsTitle?: Optional<string>;

  replaceCcExplanation?: Optional<string>;

  ccIssuerText?: Optional<string>;

  ccText?: Optional<string>;

  validUntilText?: Optional<string>;

  savePopupInfo?: Optional<PopupInfo>;

  deletePopupInfo?: Optional<PopupInfo>;
}

export interface DunningLevelConfig {
  name?: Optional<string>;

  shortInfo?: Optional<string>;

  value?: Optional<number>;

  tooltip?: Optional<Tooltip>;
}

export interface MenuWidget {
  greeting?: Optional<string>;

  items?: Optional<(Optional<Button>)[]>;
}

export interface AppSettings {
  appSettingsScreen?: Optional<AppSettingsScreen>;
}

export interface AppSettingsScreen {
  pageTitle?: Optional<string>;

  pageDescription?: Optional<string>;

  firstRunPageTitle?: Optional<string>;

  firstRunPageDescription?: Optional<string>;

  settingsTitle?: Optional<string>;

  languageTitle?: Optional<string>;

  languageDescription?: Optional<string>;

  faceIdTitle?: Optional<string>;

  faceIdDescription?: Optional<string>;

  fingerprintTitle?: Optional<string>;

  fingerprintDescription?: Optional<string>;

  pushNotificationsTitle?: Optional<string>;

  pushNotificationsDescription?: Optional<string>;

  languageScreen?: Optional<LanguageScreen>;

  beginGuidedTourButtonText?: Optional<string>;
}

export interface LanguageScreen {
  title?: Optional<string>;

  description?: Optional<string>;
}

/** ACCOUNT */
export interface Account {
  id: string;

  owner: Subscriber;

  services: (Optional<Service>)[];

  billInfo?: Optional<BillInfo>;

  primaryAddress?: Optional<Address>;
}

export interface Subscriber {
  firstName: string;

  lastName: string;

  name: string;

  email?: Optional<string>;

  emailConfirmed?: Optional<boolean>;

  birthDate?: Optional<LocalDate>;

  phone?: Optional<string>;

  language?: Optional<Language>;

  companyName?: Optional<string>;
}

export interface Service {
  id: string;

  name?: Optional<string>;

  ratePlans: (Optional<RatePlan>)[];

  subscriber: Subscriber;
  /** Remaining balance (type == RatePlanType.PREPAID) */
  balance?: Optional<number>;
}

export interface RatePlan {
  name: string;

  type?: Optional<RatePlanType>;

  fixnetInfo?: Optional<FixnetInfo>;

  tvInfo?: Optional<TvInfo>;
  /** Cost since last bill (type == RatePlanType.MOBILE_POSTPAID) */
  ongoingCost?: Optional<number>;

  buckets?: Optional<(Optional<Bucket>)[]>;

  entitlements?: Optional<(Optional<Entitlement>)[]>;

  lifecycle: RatePlanLifecycle;

  factSheet?: Optional<FactSheet>;
}

export interface FixnetInfo {
  downloadSpeed?: Optional<number>;

  uploadSpeed?: Optional<number>;

  measureUnit?: Optional<BucketMeasureUnit>;

  downloadSpeedText?: Optional<string>;

  uploadSpeedText?: Optional<string>;
}

export interface TvInfo {
  includedServices: Entitlement[];
}

export interface Entitlement {
  group?: Optional<string>;

  groupName?: Optional<string>;

  name?: Optional<string>;

  value?: Optional<string>;

  description?: Optional<string>;

  credits?: Optional<(Optional<BucketCredit>)[]>;
}

export interface Bucket {
  name?: Optional<string>;

  type?: Optional<BucketType>;

  initial?: Optional<number>;

  remaining?: Optional<number>;

  used?: Optional<number>;

  credits?: Optional<(Optional<BucketCredit>)[]>;

  measureUnits?: Optional<(Optional<BucketMeasureUnit>)[]>;

  validFrom?: Optional<string>;

  validTo?: Optional<string>;

  showValidToCountdown?: Optional<boolean>;

  category?: Optional<BucketCategory>;

  group?: Optional<GroupType>;

  customText?: Optional<string>;
}

export interface FactSheet {
  name?: Optional<string>;

  url?: Optional<string>;
}

export interface BillInfo {
  outstandingAmount?: Optional<number>;

  totalOutstandingAmount?: Optional<number>;

  overdueAmount?: Optional<number>;

  bills?: Optional<(Optional<Bill>)[]>;

  dunningInfo?: Optional<DunningInfo>;

  billingAddress?: Optional<BillingAddress>;

  billSettings?: Optional<BillSettings>;

  registeredCards?: Optional<(Optional<RegisteredCard>)[]>;

  ppaEligibility: PpaEligibility;
}

export interface Bill {
  id?: Optional<string>;

  billingPeriodFrom?: Optional<LocalDate>;

  billingPeriodTo?: Optional<LocalDate>;

  dueOn?: Optional<LocalDate>;

  billDate?: Optional<LocalDate>;

  amount?: Optional<number>;

  openAmount?: Optional<number>;

  paid?: Optional<boolean>;

  digitalInvoiceUrl?: Optional<string>;

  documentType?: Optional<BillDocumentType>;

  status?: Optional<BillStatus>;

  ppaEligible: boolean;

  sapDocumentId?: Optional<string>;
}

export interface DunningInfo {
  dunningJokerEligibility?: Optional<boolean>;

  eligibileForDeblocking?: Optional<boolean>;

  dunningLevel?: Optional<number>;

  dunningHistory?: Optional<(Optional<DunningHistoryEntry>)[]>;
}

export interface DunningHistoryEntry {
  level?: Optional<number>;

  date?: Optional<LocalDate>;
}

export interface BillingAddress {
  sameAsCustomerAddress?: Optional<boolean>;

  differentBillingAddress?: Optional<Address>;
}

export interface Address {
  salutation?: Optional<Salutation>;

  countryIsocode?: Optional<string>;

  countryName?: Optional<string>;

  name?: Optional<string>;

  firstName?: Optional<string>;

  lastName?: Optional<string>;

  postalCode?: Optional<string>;

  streetName?: Optional<string>;

  streetNumber?: Optional<string>;

  town?: Optional<string>;
}

export interface BillSettings {
  paymentMethod?: Optional<PaymentMethodType>;

  billDeliveryMethod?: Optional<BillDeliveryMethod>;

  billDeliveryNotification?: Optional<BillDeliveryNotification>;

  billAnonymizationLevel?: Optional<BillAnonymizationLevel>;
}

export interface BillDeliveryNotification {
  emailAddress?: Optional<string>;

  contactNumbers?: Optional<(Optional<string>)[]>;
}

export interface RegisteredCard {
  /** Alias for credit card number, for PostFinance or for PayPal Reference Transactions */
  aliasCc: string;
  /** Expiry month of the card */
  expiryMonth: string;
  /** Expiry year of the card */
  expiryYear: string;
  /** Number */
  number: string;
  /** PaymentInput card */
  paymentCard: PaymentCard;
}

export interface PpaEligibility {
  eligible: boolean;

  maxAmount?: Optional<number>;

  minAmount?: Optional<number>;

  minInstallmentAmount?: Optional<number>;

  fee?: Optional<number>;

  minInstallments?: Optional<number>;

  maxInstallments?: Optional<number>;
}

/** IN APP NOTIFICATIONS */
export interface InAppNotification {
  id: string;

  icon?: Optional<string>;

  closable: boolean;

  title: string;

  description?: Optional<string>;

  timestamp?: Optional<string>;

  validFrom?: Optional<string>;

  validUntil?: Optional<string>;

  openOnBoot?: Optional<boolean>;

  externalInfo?: Optional<InAppNotificationExternalInfo>;

  embeddedInfo?: Optional<InAppNotificationEmbeddedInfo>;
}

export interface InAppNotificationExternalInfo {
  link?: Optional<string>;

  openIn?: Optional<OpenIn>;
}

export interface InAppNotificationEmbeddedInfo {
  image?: Optional<string>;

  title?: Optional<string>;

  subtitle?: Optional<string>;

  description?: Optional<string>;

  button1?: Optional<Button>;

  button2?: Optional<Button>;
}

export interface Country {
  isocode?: Optional<string>;

  name?: Optional<string>;
}

export interface PaymentState {
  paymentMethods?: Optional<(Optional<PaymentMethodOption>)[]>;

  paymentProvider?: Optional<PaymentProvider>;

  registeredCards?: Optional<(Optional<RegisteredCard>)[]>;
}

export interface PaymentProvider {
  /** Provider URL */
  providerUrl: string;
  /** Merchant Id */
  merchantId: string;
  /** Amount in Rappen */
  amount: number;
  /** CHF */
  currency: string;
  /** Reference number */
  referenceNumber: string;
  /** This parameter may be used according to the merchant’s security level settings */
  sign: string;
  /** Requests the return of the masked credit card number to the merchant in field maskedCC */
  uppReturnMaskedCc?: Optional<string>;
  /** PaymentInput cards */
  paymentCards?: Optional<PaymentCard[]>;
  /** PaymentInput services */
  paymentServices?: Optional<PaymentServiceType[]>;
}

export interface EmailValidationState {
  status: EmailValidationStatus;

  detailMessage?: Optional<EmailValidationMessage>;
}

export interface AddressValidity {
  additional?: Optional<string>;

  postalCode?: Optional<string>;

  streetName?: Optional<string>;

  streetNumber?: Optional<string>;

  town?: Optional<string>;

  confidence?: Optional<number>;

  status: AddressValidityStatus;
}

export interface PpaInstallmentOption {
  count: number;

  fee: number;

  amount: number;

  amountTotal: number;

  installments: PpaInstallment[];
}

export interface PpaInstallment {
  id: number;

  fee: number;

  amount: number;

  amountTotal: number;

  dueDate?: Optional<string>;
}

export interface Mutation {
  /** Set Billing Address */
  setBillingAddress?: Optional<SetBillingAddressPayload>;
  /** Set Bill Anonymization Level */
  setBillAnonymizationLevel?: Optional<BillAnonymizationLevelPayload>;
  /** Order Account Statement */
  orderAccountStatement?: Optional<OrderAccountStatementPayload>;
  /** Order Bill Copy */
  orderBillCopy?: Optional<OrderBillCopyPayload>;
  /** Set delivery method for account's bills */
  setBillDeliveryMethod?: Optional<SetBillDeliveryMethodPayload>;
  /** Set payment method for account's bills */
  setPaymentMethod?: Optional<PaymentMethodTypePayload>;
  /** Set additional payment slip */
  orderAdditionalPaymentSlip?: Optional<OrderAdditionalPaymentSlipPayload>;
  /** Make PaymentInput */
  makePayment?: Optional<PaymentPayload>;
  /** Delete Registered Card */
  deleteRegisteredCard?: Optional<DeleteRegisteredCardPayload>;
  /** Request more time to pay */
  requestDunningJoker?: Optional<RequestDunningJokerPayLoad>;
  /** Request unblock of account in dunning */
  requestDunningDeblockOnTrust?: Optional<RequestDunningDeblockOnTrustPayLoad>;
  /** Send Email verification mail to login user */
  sendVerificationEmail: SendVerificationEmailPayload;
  /** Update contact information */
  updateContact: UpdateContactPayload;
  /** Update current user password. */
  updatePassword: UpdatePasswordPayload;
  /** Send name change step by email to current login user. */
  sendNameChangeInfo: SendNameChangeInfoPayload;
  /** create partial payment agreement for account */
  makePpaAgreement: MakePpaAgreementPayload;
}

export interface SetBillingAddressPayload {
  payloadStatus?: Optional<PayloadStatus>;
}

export interface BillAnonymizationLevelPayload {
  payloadStatus?: Optional<PayloadStatus>;
}

export interface OrderAccountStatementPayload {
  payloadStatus?: Optional<PayloadStatus>;
}

export interface OrderBillCopyPayload {
  payloadStatus?: Optional<PayloadStatus>;
}

export interface SetBillDeliveryMethodPayload {
  payloadStatus?: Optional<PayloadStatus>;
}

export interface PaymentMethodTypePayload {
  payloadStatus?: Optional<PayloadStatus>;
}

export interface OrderAdditionalPaymentSlipPayload {
  payloadStatus: PayloadStatus;
}

export interface PaymentPayload {
  payloadStatus: PayloadStatus;
}

export interface DeleteRegisteredCardPayload {
  payloadStatus: PayloadStatus;
}

export interface RequestDunningJokerPayLoad {
  payloadStatus: PayloadStatus;
}

export interface RequestDunningDeblockOnTrustPayLoad {
  payloadStatus: PayloadStatus;
}

export interface SendVerificationEmailPayload {
  payloadStatus: PayloadStatus;
}

export interface UpdateContactPayload {
  payloadStatus: PayloadStatus;
}

export interface UpdatePasswordPayload {
  payloadStatus: PayloadStatus;
}

export interface SendNameChangeInfoPayload {
  payloadStatus: PayloadStatus;
}

export interface MakePpaAgreementPayload {
  payloadStatus: PayloadStatus;
}

// ====================================================
// Arguments
// ====================================================

export interface ConfigQueryArgs {
  language?: Optional<Language>;
}
export interface AccountQueryArgs {
  language?: Optional<Language>;
}
export interface InAppNotificationsQueryArgs {
  language?: Optional<Language>;
}
export interface CountriesQueryArgs {
  language?: Optional<Language>;
}
export interface PaymentStateQueryArgs {
  amount: number;
}
export interface EmailValidationStateQueryArgs {
  email: string;
}
export interface AddressValidityQueryArgs {
  input: AddressValidityInput;
}
export interface PpaInstallmentOptionsQueryArgs {
  input: PpaInstallmentOptionsInput;
}
export interface ServicesAccountArgs {
  serviceId?: Optional<string>;
}
export interface BucketsRatePlanArgs {
  serviceId?: Optional<string>;
}
export interface SetBillingAddressMutationArgs {
  input: SetBillingAddressInput;
}
export interface SetBillAnonymizationLevelMutationArgs {
  input: BillAnonymizationLevelInput;
}
export interface OrderAccountStatementMutationArgs {
  input: OrderAccountStatementInput;
}
export interface OrderBillCopyMutationArgs {
  input: OrderBillCopyInput;
}
export interface SetBillDeliveryMethodMutationArgs {
  input: SetBillDeliveryMethodInput;
}
export interface SetPaymentMethodMutationArgs {
  input: PaymentMethodTypeInput;
}
export interface OrderAdditionalPaymentSlipMutationArgs {
  input?: Optional<OrderAdditionalPaymentSlipInput>;
}
export interface MakePaymentMutationArgs {
  input: PaymentInput;
}
export interface DeleteRegisteredCardMutationArgs {
  input: DeleteRegisteredCardInput;
}
export interface UpdateContactMutationArgs {
  input: UpdateContactInput;
}
export interface UpdatePasswordMutationArgs {
  input: UpdatePasswordInput;
}
export interface MakePpaAgreementMutationArgs {
  input: MakePpaAgreementInput;
}
