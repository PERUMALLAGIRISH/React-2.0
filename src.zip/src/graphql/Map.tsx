export interface Map<T> {
    [key: string]: T;
}
export type ClientMap<T> = Map<T>;