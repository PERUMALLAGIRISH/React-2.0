import * as React from 'react';
import {connect} from 'react-redux';
import {PayloadStatus, UpdatePasswordInput, UpdatePasswordPayload} from '../../../model/types.d';
import {Input} from '../../../components/Form/Input/Input';
import {Button} from '../../../components/Form/Button/Button';
import {FormErrors} from '../../../components/Form/FormErrors/FormErrors';
import {resetUpdatePassword, updatePassword} from '../ProfileAction';
import {ActionCreatorsMapObject, bindActionCreators, Dispatch} from 'redux';
import {Success} from '../../../components/Success/Success';
import {Popup} from '../../../components/Popup/Popup';
import {Loader} from '../../../components/Loader/Loader';
import I18n from '../../../utils/helper/I18n';
import {
  ProfileConstants,
  ProfileEditBillingAddressConstants,
  ProfileEditPasswordConstants
} from '../ProfileConstants';
import {ProfileRoutes} from '../ProfileRoutes.enum';
import ValidationService from '../../../utils/ValidationService';
import {History} from 'history';

export interface ProfileEditPasswordProps {
  updatePasswordPayload: UpdatePasswordPayload;
  updatePasswordPayloadError: Error | null;
  imgDummyPassword?: string;
  history: History;
  updatePassword: (updatePasswordInput: UpdatePasswordInput) => void;
  resetUpdatePassword: () => void;
}

interface ProfileEditPasswordState {
  password: UpdatePasswordForm;
  formErrors: string[];
  disabled: boolean;
  formStatus: boolean;
  isTooltipPopup: boolean,
  selectedTooltipId: string,
  oldPasswordType: string,
  newPasswordType: string,
  confirmPasswordType: string,
  isLoading: boolean
}

export interface UpdatePasswordForm extends UpdatePasswordInput {
  [ key: string ]: any;
};

class ProfileEditPassword extends React.Component<ProfileEditPasswordProps, ProfileEditPasswordState> {
  constructor(props: ProfileEditPasswordProps) {
    super(props);
    this.state = {
      password: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
      },
      formErrors: [],
      disabled: true,
      isTooltipPopup: false,
      selectedTooltipId: '',
      formStatus: true,
      oldPasswordType: ProfileEditBillingAddressConstants.PASSWORD,
      newPasswordType: ProfileEditBillingAddressConstants.PASSWORD,
      confirmPasswordType: ProfileEditBillingAddressConstants.PASSWORD,
      isLoading: false
    }
  }

  componentWillUnmount(): void {
    const {resetUpdatePassword} = this.props;
    resetUpdatePassword();
  }

  handlePasswordChange = (fieldName: any, value: string): void => {
    const password: UpdatePasswordForm = {...this.state.password}
    password[fieldName] = value;
    this.setState({password});
    const fieldValidationErrors: any = {};
    this.setState({
      formErrors: fieldValidationErrors
    });
  }

  renderSave(): JSX.Element {
    const {password} = this.state;
    let disabled: boolean = true;
    if (password.newPassword &&
      password.confirmPassword &&
      password.oldPassword &&
      this.validatePasswordLength(password.newPassword) &&
      ValidationService.isValidAlphabet(password.newPassword) &&
      ValidationService.isValidNumber(password.newPassword)) {
      disabled = false;
    }
    return (
      <Button
        className= 'button extra_wide full_width_on_mobile'
        handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.handleSave(e)}
        label = {I18n.translate('ProfileEdit.ChangePassword.Button.Save')}
        disabled = {disabled}
      />);
  }

  renderLoader(): JSX.Element | null {
    const {isLoading} = this.state;
    if (isLoading) {
      return (
        <Loader />
      );
    }
    return null;
  }

  handlePasswordValidation = (): void => {
    const {password} = this.state;
    this.validatePasswordField(password.newPassword, password.confirmPassword);
  }

  validatePasswordLength = (newPassword: string): boolean => {
    if (newPassword && (newPassword.length < ProfileEditPasswordConstants.NEW_PASSWORD_MIN_LENGTH || newPassword.length > ProfileEditPasswordConstants.NEW_PASSWORD_MAX_LENGTH)) {
      return false;
    }
    return true;
  }

  validatePasswordField(newPassword: string, confirmPassword: string): boolean {
    const {formErrors} = this.state;
    let fieldValidationErrors: any = formErrors;
    if (newPassword && confirmPassword && newPassword !== confirmPassword) {
      fieldValidationErrors.confirmPassword = I18n.translate('ProfileEdit.ConfirmPassword.Label.ErrorNotMatch');
    } else {
      fieldValidationErrors = {};
    }
    this.setState({
      formErrors: fieldValidationErrors
    });
    if ((Object.keys(formErrors).length)) {
      return false;
    }
    return true;
  }

  handlePasswordShowHide = (fieldName: any, value: string): void => {
    this.setState({[fieldName]: value === 'password' ? 'text' : 'password'} as Pick<ProfileEditPasswordState, keyof ProfileEditPasswordState>)
  }

  onValidationError(): JSX.Element | null {
    const {formErrors} = this.state;
    if (Object.keys(formErrors).length) {
      return (
        <FormErrors formErrors={formErrors} />
      );
    }
    return null;
  }

  renderNewPasswordField(): JSX.Element {
    const {password, newPasswordType} = this.state;
    let errorText: string = '';
    if (password.newPassword && !this.validatePasswordLength(password.newPassword)) {
      errorText = I18n.translate('ProfileEdit.Password.Label.ErrorLength');
    } else if (password.newPassword && !ValidationService.isValidAlphabet(password.newPassword)) {
      errorText = I18n.translate('ProfileEdit.Password.Label.ErrorCharacter');
    } else if (password.newPassword && !ValidationService.isValidNumber(password.newPassword)) {
      errorText = I18n.translate('ProfileEdit.Password.Label.Error.Number');
    }
    return (
      <div className='form-item no-bottom-margin'>
        <div className='position-relative'>
          <Input
            type = {newPasswordType}
            name = {'newPassword'}
            value = {password.newPassword}
            className = {errorText ? 'form_input form_error' : 'form_input'}
            labelClassName = {errorText ? 'form__label form__text_field-label form_error' : 'form__label form__text_field-label form__label__text'}
            label = {errorText ? errorText : `${I18n.translate('ProfileEdit.Password.Label.NewPassword')}`}
            tooltipId = {'newPassword'}
            onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltipPopup(e, ProfileEditPasswordConstants.NEW_PASSWORD)}
            onChange = {this.handlePasswordChange}
            onBlur = {this.handlePasswordValidation}
          />
          <div className='vertical_spacer x16'></div>
          <Button
            className= {newPasswordType === 'password' ? 'password-bg-img' : 'password-bg-img--red' }
            onMouseDown= {(e: React.MouseEvent<HTMLButtonElement>) => this.handlePasswordShowHide('newPasswordType', newPasswordType)}
            onKeyPress= {(e: React.KeyboardEvent<HTMLElement>) => this.handlePasswordShowHide('newPasswordType', newPasswordType)}
          />
        </div>
      </div>
    );
  }

  renderoldPasswordField(): JSX.Element {
    const {password, oldPasswordType} = this.state;
    return (
      <div className='form-item no-bottom-margin'>
        <div className='position-relative'>
          <Input
            type = {oldPasswordType}
            name = {'oldPassword'}
            value = {password.oldPassword}
            className = {'form_input'}
            labelClassName = {'form__label form__text_field-label form__label__text'}
            label = {`${I18n.translate('ProfileEdit.Password.Label.CurrentPassword')}`}
            tooltipId = {'oldPassword'}
            onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltipPopup(e, ProfileEditPasswordConstants.CURRENT_PASSWORD)}
            onChange = {this.handlePasswordChange}
            onBlur = {this.handlePasswordValidation}
          />
          <div className='vertical_spacer x16'></div>
          <Button
            className= {oldPasswordType === 'password' ? 'password-bg-img' : 'password-bg-img--red' }
            onMouseDown= {(e: React.MouseEvent<HTMLButtonElement>) => this.handlePasswordShowHide('oldPasswordType', oldPasswordType)}
            onKeyPress= {(e: React.KeyboardEvent<HTMLElement>) => this.handlePasswordShowHide('oldPasswordType', oldPasswordType)}
          />
        </div>
      </div>
    );
  }

  renderConfirmPasswordField(): JSX.Element {
    const {password, confirmPasswordType} = this.state;
    return (
      <div className='form-item no-bottom-margin'>
        <div className='position-relative'>
          <Input
            type = {confirmPasswordType}
            name = {'confirmPassword'}
            value = {password.confirmPassword}
            className = {'form_input'}
            labelClassName = {'form__label form__text_field-label form__label__text'}
            label = {`${I18n.translate('ProfileEdit.Password.Label.ConfirmPassword')}`}
            tooltipId = {'confirmPassword'}
            onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltipPopup(e, ProfileEditPasswordConstants.CONFIRM_PASSWORD)}
            onChange = {this.handlePasswordChange}
            onBlur = {this.handlePasswordValidation}
          />
          <div className='vertical_spacer x16'></div>
          <Button
            className= {confirmPasswordType === 'password' ? 'password-bg-img' : 'password-bg-img--red' }
            onMouseDown= {(e: React.MouseEvent<HTMLButtonElement>) => this.handlePasswordShowHide('confirmPasswordType', confirmPasswordType)}
            onKeyPress= {(e: React.KeyboardEvent<HTMLElement>) => this.handlePasswordShowHide('confirmPasswordType', confirmPasswordType)}
          />
        </div>
      </div>
    )
  }

  getPopupData = (name: string) => {
    const data: any = {};
    switch (name) {
      case ProfileEditPasswordConstants.CURRENT_PASSWORD:
        data.title = I18n.translate('ProfileEdit.Tooltip.Label.CurrentPasswordTitle');
        data.text = I18n.translate('ProfileEdit.Tooltip.Text.CurrentPassword');
        return data;
      case ProfileEditPasswordConstants.NEW_PASSWORD:
        data.title = I18n.translate('ProfileEdit.Tooltip.Label.NewPasswordTitle');
        data.text = I18n.translate('ProfileEdit.Tooltip.Text.NewPassword');
        return data;
      case ProfileEditPasswordConstants.CONFIRM_PASSWORD:
        data.title = I18n.translate('ProfileEdit.Tooltip.Label.ConfirmPasswordTitle');
        data.text = I18n.translate('ProfileEdit.Tooltip.Text.ConfirmPassword');
        return data;
      default:
        data.title = '';
        data.text = '';
        return data;
    }
  }

  displayTooltipPopup(event: React.MouseEvent<HTMLButtonElement, MouseEvent>, id: string): void {
    event.persist();
    const {isTooltipPopup} = this.state;
    this.setState({
      isTooltipPopup: !isTooltipPopup,
      selectedTooltipId: id
    });
  }

  renderTooltipPopup = (): JSX.Element => {
    const {selectedTooltipId} = this.state;
    const data: any = this.getPopupData(selectedTooltipId);
    return (
      <Popup
        title = {data.title}
        data = {[data.text]}
        buttonLabel = {I18n.translate('ProfileEdit.Tooltip.Button.Close')}
        onClick = { (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltipPopup(e, selectedTooltipId) }
      />
    );
  }

  renderProgressBar(): JSX.Element {
    return (
      <div className='progress_tracker centered-text'>
        <div className='inline_progress_sign progress_step_number--mobile-small progress_step_sign progress_tracker__break_words'>
          <div className='progress_step_number'>
            {ProfileConstants.STEP1}
          </div>
          <div className='progress_step_title text-small bold'>
            {I18n.translate('ProfileEdit.ChangePassword.Label.Password')}
          </div>
        </div>
      </div>
    )
  }

  renderHeading(): JSX.Element {
    return (
      <React.Fragment>
        <h2 className='title-large'>
          {I18n.translate('ProfileEdit.PasswordEdit.Label.NewPassword')}
        </h2>
        <div className='text-small centered-text text-pad-lr-25perc'>
          {I18n.translate('ProfileEdit.PasswordEdit.Label.PasswordCombination')}
        </div>
      </React.Fragment>
    )
  }

  renderForm(): JSX.Element | null {
    const {formStatus} = this.state;
    if (formStatus) {
      return (
        <div className='content-box screen-pane'>
          {this.renderProgressBar()}
          {this.renderHeading()}
          <div className='form form_middle_box'>
            {this.onValidationError()}
            {this.renderoldPasswordField()}
            {this.renderNewPasswordField()}
            {this.renderConfirmPasswordField()}
            <div className='form-item'>
              <div className='form-item__button full_width_on_mobile'>
                <Button
                  className= 'button full_width_on_mobile transparent_background'
                  handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.handleCancel(e)}
                  label = {I18n.translate('ProfileEdit.ChangePassword.Button.Cancel')}
                />
                {this.renderSave()}
                {this.renderLoader()}
              </div>
            </div>
          </div>
        </div>
      );
    }
    return null;
  }

  renderPasswordSuccess(): JSX.Element | null {
    const {updatePasswordPayloadError, updatePasswordPayload, imgDummyPassword } = this.props;
    const {formStatus} = this.state;
    let label: string = I18n.translate('ProfileEdit.ChangePassword.Label.Error');
    let title: string = I18n.translate('ProfileEdit.ChangePassword.Label.ErrorTitle');
    if (updatePasswordPayloadError === null && updatePasswordPayload !== null && updatePasswordPayload.payloadStatus === PayloadStatus.OK) {
      label = I18n.translate('ProfileEdit.ChangePassword.Label.SuccessTitle');
      title = I18n.translate('ProfileEdit.ChangePassword.Label.SuccessHeading');
    }
    if (!formStatus) {
      return (
        <Success
          imageSource={imgDummyPassword || ''}
          heading = {title}
          text = {label}
          button = {I18n.translate('ProfileEdit.ChangePassword.Button.BackToProfile')}
          href = {ProfileRoutes.PROFILE_SUCCESS}
        />
      );
    }
    return null;
  }
  checkPasswordIdentical(oldPassword: string, newPassword: string): boolean {
    const {formErrors} = this.state;
    let fieldValidationErrors: any = formErrors;
    if (oldPassword && newPassword && oldPassword === newPassword) {
      fieldValidationErrors.oldPassword = I18n.translate('ProfileEdit.Password.Text.ErrorIdentical');
    } else {
      fieldValidationErrors = {};
    }
    this.setState({
      formErrors: fieldValidationErrors
    });
    if ((Object.keys(formErrors).length)) {
      return false;
    }
    return true;
  }

  handleSave(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    const {updatePassword} = this.props;
    const {password} = this.state;
    const updatePasswordInput: any = {};
    if (this.validatePasswordField(password.newPassword, password.confirmPassword) && this.checkPasswordIdentical(password.oldPassword, password.newPassword)) {
      if (password.oldPassword) {
        updatePasswordInput.oldPassword = password.oldPassword;
      }
      if (password.newPassword) {
        updatePasswordInput.newPassword = password.newPassword;
      }
      this.setState({ formStatus: false, isLoading: true});
      updatePassword(updatePasswordInput);
    }
  }

  handleCancel(event: React.MouseEvent<HTMLButtonElement>): void {
    const {history} = this.props;
    event.preventDefault();
    history.push({
      pathname: ProfileRoutes.PROFILE_HOME
    });
  }

  render(): React.ReactNode {
    const {isTooltipPopup} = this.state;
    return (
      <div className='l-center-l'>
        {isTooltipPopup && this.renderTooltipPopup()}
        <div className='l-grid'>
          <div className='l-col l-1of1'>
            {this.renderForm()}
            {this.renderPasswordSuccess()}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps: any = ({ profileReducer }: any) => {
  return {
    updatePasswordPayload:  profileReducer.updatePasswordPayload,
    updatePasswordPayloadError: profileReducer.updatePasswordPayloadError,
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({ updatePassword, resetUpdatePassword }, dispatch);
};

export default connect<ProfileEditPasswordProps>(mapStateToProps, mapDispatchToProps)(ProfileEditPassword);
