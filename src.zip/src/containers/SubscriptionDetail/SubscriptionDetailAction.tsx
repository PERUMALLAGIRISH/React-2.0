import {Action, Dispatch} from 'redux';
import {Account} from '../../model/types.d';
import SubscriptionDetailQuery from '../../graphql/SubscriptionDetailQuery';
import GraphQL from '../../graphql/GraphQL';

export enum BillsActionType {
  FETCH_SERVICES_INFO = 'FETCH_SERVICES_INFO',
  FETCH_SERVICES_INFO_ERROR = 'FETCH_SERVICES_INFO_ERROR',
  RESET_SERVICES = 'RESET_SERVICES'
};

export interface FetchServicesAction extends Action {
  type: BillsActionType.FETCH_SERVICES_INFO;
  payload: Account;
}

export interface FetchServicesErrorAction extends Action {
  type: BillsActionType.FETCH_SERVICES_INFO_ERROR;
  payload: Error;
}
export interface BillsResponse {
  account: Account;
}

export const fetchServices: any = () => {
  return (dispatch: Dispatch) => {
    GraphQL.query({
      query: SubscriptionDetailQuery,
    }, (response: BillsResponse) => {
      if (response && response.account) {
        dispatch({type: BillsActionType.FETCH_SERVICES_INFO, payload: response.account});
      }
    }, (error: Error) => {
      dispatch({type: BillsActionType.FETCH_SERVICES_INFO_ERROR, payload: error});
    });
  };
};

export const resetServices: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: BillsActionType.RESET_SERVICES, payload: null});
  }
};
