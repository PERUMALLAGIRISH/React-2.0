export enum SubscriptionDetailRoutes {
    SUBSCRIPTION_DETAIL_HOME = '/',
    SUBSCRIPTION_DETAIL_SUCCESS = '#/',
  }