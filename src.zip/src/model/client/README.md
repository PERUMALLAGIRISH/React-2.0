# Client interfaces
Please put here only the client interfaces (App related only).