import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const AccountQuery: DocumentNode = gql`
query account($language: Language) {
  account(language: $language) {
    id
    owner {
      firstName
      lastName
      name
      email
      emailConfirmed
      birthDate
      phone
      language
      companyName
    }
    primaryAddress {
      salutation
      countryIsocode
      countryName
      name
      firstName
      lastName
      postalCode
      streetName
      streetNumber
      town
    }
    billInfo {
      billingAddress {
        sameAsCustomerAddress
        differentBillingAddress {
          salutation
          countryIsocode
          countryName
          name
          firstName
          lastName
          postalCode
          streetName
          streetNumber
          town
        }
      }
      billSettings {
        paymentMethod
      }
    }
  }
}`;

export default AccountQuery;