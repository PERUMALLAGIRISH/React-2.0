import * as React from 'react';

interface IHomeComponentState {
}

const initialState: IHomeComponentState = {
}

interface IHomeComponentProps {
}

export class Home extends React.Component<IHomeComponentProps, IHomeComponentState> {
  constructor(props: IHomeComponentProps) {
    super(props);
    this.state = initialState;
  }

  render(): React.ReactNode {
    return (
      <div className='container-fluid home'>
        <div className='row'>
          <div className='home-container'>
            <h1 className='welcome'>Welcome to My Sunrise</h1>
          </div>
        </div>
      </div>
    )
  }
}
