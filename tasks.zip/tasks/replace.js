/*eslint-env node */

module.exports = function() {

'use strict';

	 return {

     lt: {
        options: {
          patterns: [
            {
              match: /&lt;R/g,
              replacement: function () {
                return '<R';
              }
            },
            {
              match: /&amp;amp;/g,
              replacement: function () {
                return '&';
              }
            },
          ],
        },
        files: [{
          expand: true,
          flatten: true,
          src: '<%= cfg.dirs.distTranslations %>/React.xml',
          dest: '<%= cfg.dirs.distTranslations %>/'
        }]
      }
    };
};
