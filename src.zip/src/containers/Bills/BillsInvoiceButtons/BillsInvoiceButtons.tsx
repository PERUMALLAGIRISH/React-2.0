import * as React from 'react';
import {Button} from '../../../components/Form/Button/Button';
import {BillsCopyByMail} from '../BillsCopyByMail/BillsCopyByMail';
import I18n from '../../../utils/helper/I18n';
import {OrderBillCopyPayload} from '../../../model/types.d';

export interface BillsInvoiceButtonsProps {
  digitalInvoiceUrl: string;
  downloadUrl: string;
  id: string;
  orderBillCopyPayload: OrderBillCopyPayload;
  orderBillCopyPayloadError: Error | null;
  setOrderBillCopy: () => void;
  resetOrderBillCopy: () => void;
}

interface BillsInvoiceButtonsState {
  isCopyByMailPopup: boolean;
}

export class BillsInvoiceButtons extends React.Component<BillsInvoiceButtonsProps, BillsInvoiceButtonsState> {
  constructor(props: BillsInvoiceButtonsProps) {
    super(props);
    this.state = {
      isCopyByMailPopup: false
    }
  }

  handleInoviceUrl = (event: React.MouseEvent<HTMLButtonElement>, url: string): void => {
    event.preventDefault();
    window.location.href = url;
  }

  showHideCopyByMailPopup = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {isCopyByMailPopup} = this.state;
    event.preventDefault();
    this.setState({
      isCopyByMailPopup: !isCopyByMailPopup
    });
  }

  renderXmlCopyByMailPopup = (): JSX.Element => {
    const {id, setOrderBillCopy, orderBillCopyPayload, orderBillCopyPayloadError, resetOrderBillCopy} = this.props;
    return (
      <BillsCopyByMail
        id = {id}
        setOrderBillCopy = {setOrderBillCopy}
        orderBillCopyPayloadError = {orderBillCopyPayloadError}
        orderBillCopyPayload = {orderBillCopyPayload}
        handleClosePopup = {this.showHideCopyByMailPopup}
        resetOrderBillCopy = {resetOrderBillCopy}
      />
    );
  }

  render(): React.ReactNode {
    const {digitalInvoiceUrl, downloadUrl} = this.props;
    const {isCopyByMailPopup} = this.state;
    return (
      <React.Fragment>
        {isCopyByMailPopup ? this.renderXmlCopyByMailPopup() : null}
        <div className='bill-card-buttons bill-card-buttons--wider'>
          <Button
            handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handleInoviceUrl(e, digitalInvoiceUrl)}
            label = {I18n.translate('BillsInvoiceButtons.BillAssistant.Button.Label')}
            className = 'button cta-button dark_grey_text no_word_break tiny_text'
          />
          <Button
            handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handleInoviceUrl(e, downloadUrl)}
            label = {I18n.translate('BillsInvoiceButtons.DownloadPDF.Button.Label')}
            className = 'button cta-button dark_grey_text no_word_break tiny_text'
          />
          <Button
            handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.showHideCopyByMailPopup(e)}
            label = {I18n.translate('BillsInvoiceButtons.CopyByPost.Button.Label')}
            className = 'button cta-button dark_grey_text no_word_break tiny_text'
          />
        </div>
        <div className='vertical_spacer x16'></div>
      </React.Fragment>
    );
  }
}
