import { OrderBillCopyPayload } from '../types.d';

export interface OrderBillCopyResponse {
    orderBillCopy: OrderBillCopyPayload;
}