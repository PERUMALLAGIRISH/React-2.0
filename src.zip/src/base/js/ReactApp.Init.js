
  var urlParams = new URLSearchParams(window.location.search);
  var data = {
    isLive : (urlParams.get('live') === 'true') ? true : false,
    segmentCode :  urlParams.get('segment-code'),
    language : urlParams.get('language')
  };

(function() {

	var root = this, // save a reference to the global object
		ReactApp;

	ReactApp = root.ReactApp = {};

	ReactApp.Env = {};

}).call(this);
