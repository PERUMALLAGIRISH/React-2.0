import { DocumentNode } from 'graphql';
import gql from 'graphql-tag';

const DeleteRegisteredCardMutation: DocumentNode = gql`
    mutation deleteRegisteredCard($input: DeleteRegisteredCardInput!) {
        deleteRegisteredCard(input: $input) {
            payloadStatus
        }
    }
`;

export default DeleteRegisteredCardMutation;