import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const sendVerificationEmailMutation: DocumentNode = gql`
mutation sendVerificationEmail {
  sendVerificationEmail {
    payloadStatus
  }
}`;

export default sendVerificationEmailMutation;
