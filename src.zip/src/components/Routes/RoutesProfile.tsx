import * as React from 'react';
import {HashRouter as Router, Route, Switch} from 'react-router-dom';
import Profile, {ProfileProps} from '../../containers/Profile/Profile';
import ProfileEdit, {ProfileEditProps} from '../../containers/Profile/ProfileEdit/ProfileEdit';
import ProfileEditBillingAddress, {ProfileEditBillingAddressProps} from '../../containers/Profile/ProfileEditBillingAddress/ProfileEditBillingAddress';
import ProfileEditPassword, {ProfileEditPasswordProps} from '../../containers/Profile/ProfileEdit/ProfileEditPassword';
import NotFound from '../NotFound/NotFound';

class RoutesProfile extends React.Component {

  render(): React.ReactNode {
    return (
      <Router>
        <Switch>
          <Route exact path='/' component={(props: ProfileProps) => <Profile {...props} {...this.props}/>} />
          <Route exact path='/EditProfile' component={(props: ProfileEditProps) => <ProfileEdit {...props} {...this.props}/>} />
          <Route path='/ChangeBillingAddress' component={(props: ProfileEditBillingAddressProps) => <ProfileEditBillingAddress {...props} {...this.props}/>} />
          <Route exact path='/ChangeLanguage' component={(props: ProfileEditProps) => <ProfileEdit {...props} {...this.props}/>} />
          <Route exact path='/CorrectLegalAddress' component={(props: ProfileEditProps) => <ProfileEdit {...props} {...this.props}/>} />
          <Route path='/ChangePassword' component={(props: ProfileEditPasswordProps) => <ProfileEditPassword {...props} {...this.props}/>} />
          <Route path='*' component={NotFound} />
        </Switch>
      </Router>
    )
  }
}

export default RoutesProfile;
