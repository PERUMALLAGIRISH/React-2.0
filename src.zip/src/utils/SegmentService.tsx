class SegmentService {
    getCode = (): string => {
      const bodyElement: HTMLElement | null = document.getElementsByTagName('body')[0];
      let code: string | null = '';
      if (bodyElement !== null && bodyElement.getAttribute('data-segment-code') !== null) {
        code = bodyElement.getAttribute('data-segment-code');
      }
      if (code === null || typeof code !== 'string' || code === '') {
        return 'RC'
      }
      return code;
    }
}

export default new SegmentService();