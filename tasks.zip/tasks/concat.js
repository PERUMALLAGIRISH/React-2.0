/*eslint-env node */

module.exports = function() {

	'use strict';

	return {

		i18n: {
			src: [
				'<%= cfg.dirs.base %>/i18n/*.properties',
				'<%= cfg.dirs.components %>/**/*.properties',
        '<%= cfg.dirs.containers %>/**/*.properties'
			],
			dest: '<%= cfg.dirs.messages %>/<%= cfg.names.messages %>.properties'
		},

		scriptsBase: {
			src: [
				'<%= cfg.dirs.base %>/js/*'
			],
			dest: '<%= cfg.dirs.dist %>/js/<%= cfg.names.base %>.js'
		}
	};
};
