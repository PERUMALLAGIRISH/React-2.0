import * as React from 'react';

export class Dashboard extends React.Component {
  render(): React.ReactNode {
    return (
      <div className='container-fluid dashboard'>
        <h1>Dashboard</h1>
      </div>
    )
  }
}
