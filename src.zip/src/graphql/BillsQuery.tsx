import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const BillsQuery: DocumentNode = gql`
query account($language: Language) {
  account(language: $language) {
    id
    owner {
      firstName
      lastName
      name
      email
      emailConfirmed
      birthDate
      phone
      language
      companyName
    }
    services {
      id
    }
    primaryAddress {
      salutation
      countryIsocode
      countryName
      name
      firstName
      lastName
      postalCode
      streetName
      streetNumber
      town
    }
    billInfo {
      outstandingAmount
      totalOutstandingAmount
      overdueAmount
      bills {
        id
        billingPeriodFrom
        billingPeriodTo
        dueOn
        billDate
        amount
        openAmount
        paid
        digitalInvoiceUrl
        documentType
        status
      }
      dunningInfo {
        dunningJokerEligibility
        eligibileForDeblocking
        dunningLevel
        dunningHistory {
          level
          date
        }
      }
      billingAddress {
        sameAsCustomerAddress
        differentBillingAddress {
          salutation
          countryIsocode
          countryName
          name
          firstName
          lastName
          postalCode
          streetName
          streetNumber
          town
        }
      }
      billSettings {
        paymentMethod
        billDeliveryMethod
        billDeliveryNotification {
          emailAddress
          contactNumbers
        }
        billAnonymizationLevel
      }
      registeredCards {
        aliasCc
        expiryMonth
        expiryYear
        number
        paymentCard
      }
    }
  }
}`;

export default BillsQuery;