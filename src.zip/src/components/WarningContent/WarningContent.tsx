import * as React from 'react';
import {Button} from '../Form/Button/Button';

export interface WarningContentProps {
  title?: string;
  data?: string;
  buttonLabel: string;
  handleClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

export class WarningContent extends React.Component<WarningContentProps> {
  constructor(props: WarningContentProps) {
    super(props);
  }

  render(): React.ReactNode {
    const {title, data, buttonLabel, handleClick} = this.props;
    return (
      <div className='l-grid'>
        <div className='l-col l-1of1'>
          <div className='content-box warning-box--missing'>
            <h2 className='email__missing__title'>{title}</h2>
            <p className='email__missing__text text-pad-lr-25perc'>{data}</p>
            <div className='form-item'>
              <Button
                label={buttonLabel}
                handleClick={(e: React.MouseEvent<HTMLButtonElement>) => handleClick(e)}
                className = 'button'
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
