import * as React from 'react';

interface LoaderProps {
}
export class Loader extends React.Component<LoaderProps> {
  render(): React.ReactNode {
    return (
      <div className='as-absolute as-light load_spinner'>Loading...</div>
    );
  }
}
