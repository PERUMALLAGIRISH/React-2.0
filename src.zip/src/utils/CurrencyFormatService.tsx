class CurrencyFormatService {
  getCurrencyFormat(value: string | number): string {
    let currentValue: number;
    if (typeof (value) === 'string') {
      currentValue = parseFloat(value);
    } else if (typeof (value) === 'number') {
      currentValue = value;
    } else {
      return '.-';
    }
    if (currentValue === Math.floor(currentValue)) {
      return `${currentValue}.-`;
    }
    return `${currentValue.toFixed(2)}`;
  }
}

export default new CurrencyFormatService();