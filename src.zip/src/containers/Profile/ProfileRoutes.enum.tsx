export enum ProfileRoutes {
  PROFILE_HOME = '/',
  CHANGE_BILLING_ADDRESS = '/ChangeBillingAddress',
  EDIT_PROFILE    =  '/EditProfile',
  CHANGE_PASSWORD = '/ChangePassword',
  PROFILE_SUCCESS = '#/'
}