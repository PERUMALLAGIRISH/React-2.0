import React from 'react';
import {DataListConfig} from './DataListConfig';
import {Button} from '../Form/Button/Button';

export interface DataListProps {
  value?: string | number;
  label: string | JSX.Element;
  data?: string[];
  isButton?: boolean;
  hasTooltip?: boolean;
  buttonLabel?: string;
  config?: DataListConfig;
  handleClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  onClick?(event: React.MouseEvent<HTMLButtonElement>): void;
}

export class DataList extends React.Component<DataListProps> {
  constructor(props: DataListProps) {
    super(props);
  }

  renderXmlValue: () => JSX.Element = () => {
    const {value, data, config} = this.props;
    const result: (string | object)[]  = [];
    if (data && data.length) {
      data.forEach((value: string) => {
        if (config && config['value'] === value) {
          result.push(<div className={config['className']}>{value}</div>);
        } else {
          result.push(<React.Fragment>{value} <br/></React.Fragment>);
        }
      });
      return (<div className='form__text'>{result}</div>);
    }
    return (<div className='form__text'>{value}</div>);
  };

  renderXmlLabel: (value?: string | number) => JSX.Element = (value?: string | number) => {
    const {label, hasTooltip, onClick} = this.props;
    if (value) {
      return (<div className='form__label'>{label}<div className='form__text'>{value}</div></div>);
    } else {
      return (<div className='form__label'>{label}{hasTooltip && onClick ? <span className='tooltip' onClick={onClick}></span> : null}</div>);
    }
  };

  renderXmlButton: () => JSX.Element = () => {
    const {buttonLabel, handleClick} = this.props;
    return (
      <div className='form-item__button'>
        <Button label={buttonLabel} handleClick={handleClick} className = 'button' />
      </div>
    );
  };

  render(): React.ReactNode {
    const {value, data, isButton, hasTooltip, onClick, buttonLabel, handleClick} = this.props;
    const xmlValue: JSX.Element[] = [];
    const xmlLabel: JSX.Element[] = [];
    const xmlButton: JSX.Element[] = [];
    let className: string = 'form-item';
    if ((hasTooltip && onClick) || !isButton) {
      xmlLabel.push(this.renderXmlLabel());
    }
    if (data && data.length > 0) {
      xmlValue.push(this.renderXmlValue());
    } else if (isButton) {
      className = 'form-item form-row-even--mobile';
      if (value) {
        xmlLabel.push(this.renderXmlLabel(value));
      }
      if (buttonLabel && handleClick !== undefined) {
        xmlButton.push(this.renderXmlButton());
      }
    } else if (value) {
      xmlValue.push(this.renderXmlValue());
    } else {
      xmlLabel.push(this.renderXmlLabel());
    }
    return (
      <div className={className}>
        {xmlLabel}
        {xmlButton}
        {xmlValue}
      </div>
    );
  }
}
