class ValidationService {
  isValidEmail(email: string): boolean {
    const regExp: RegExp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regExp.test(String(email).toLowerCase());
  }

  isValidPhone(phoneNumber: string): boolean {
    const regExp: RegExp = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4}$/im;
    return regExp.test(phoneNumber);
  }

  isValidAlphabet = (text: string): boolean => {
    const regExp: RegExp = /[a-zA-Z]/;
    return regExp.test(text);
  }

  isValidNumber = (number: string): boolean => {
    const regExp: RegExp = /[0-9]/;
    return regExp.test(number);
  }

  isValidName = (textName: string): boolean => {
    const validate: RegExp = /^([a-zA-ZÀ-ÿ]+\s?)*[a-zA-ZÀ-ÿ]*\S\s?$/,
      validateNumber: RegExp = /[^0-9]$/,
      validateSpecialCh: RegExp = /^([^*|\":<>![\]{}`\\(☺☻♥♦♣♠•◘○◙♂♀♪♫☼►◄↕‼¶§▬↨↑↓→←∟↔▲▼¢αøØ¢£¥₧ƒ¹ªº¿⌐¬½¼¡«»ΓπΣσµτΩδ∞φε∩≡±≥≤⌠⌡÷≈°√ⁿ²■)';@#~&$+_=^?,"./%-])+$/;
    if (validate.test(textName)) {
      if (validateNumber.test(textName)) {
        if (validateSpecialCh.test(textName)) {
          return true;
        }
      }
    }
    return false;
  }

  isValidIBANNumber = (input: string) => {
      const codeLengths: any = {
        AD: 24, AE: 23, AT: 20, AZ: 28, BA: 20, BE: 16, BG: 22, BH: 22, BR: 29,
        CH: 21, CR: 21, CY: 28, CZ: 24, DE: 22, DK: 18, DO: 28, EE: 20, ES: 24,
        FI: 18, FO: 18, FR: 27, GB: 22, GI: 23, GL: 18, GR: 27, GT: 28, HR: 21,
        HU: 28, IE: 22, IL: 23, IS: 26, IT: 27, JO: 30, KW: 30, KZ: 20, LB: 28,
        LI: 21, LT: 20, LU: 20, LV: 21, MC: 27, MD: 24, ME: 22, MK: 19, MR: 27,
        MT: 31, MU: 30, NL: 18, NO: 15, PK: 24, PL: 28, PS: 29, PT: 25, QA: 29,
        RO: 24, RS: 22, SA: 24, SE: 24, SI: 19, SK: 24, SM: 27, TN: 24, TR: 26
      };
      const iban: string = String(input).toUpperCase().replace(/[^A-Z0-9]/g, ''), // Keep only alphanumeric characters
        code: RegExpMatchArray | null  = iban.match(/^([A-Z]{2})(\d{2})([A-Z\d]+)$/); // Match and capture (1) the country code, (2) the check digits, and (3) the rest
      let digits: string = '';
      // Check syntax and length
      if (!code || iban.length !== codeLengths[code[1]]) {
        return false;
      }
      // Rearrange country code and check digits, and convert chars to ints
      digits = (code[3] + code[1] + code[2]).replace(/[A-Z]/g,  (letter) => {
      //   return letter.charCodeAt(0) - 55;
      return (letter.charCodeAt(0) - 55).toString();
      });
      // Final check
      return this.mod97(digits);
    }

    mod97 = (digits: string) => {
      const checksum: string = digits.slice(0, 2);
      let news: number = parseInt(checksum, 10), fragment: string;
      for (let offset: number = 2; offset < digits.length; offset += 7) {
        fragment = String(news) + digits.substring(offset, offset + 7);
        news = parseInt(fragment, 10) % 97;
      }
      return news;
    }
}

export default new ValidationService();
