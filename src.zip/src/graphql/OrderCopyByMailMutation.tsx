import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const orderBillCopyMutation: DocumentNode = gql`
mutation orderBillCopy($input: OrderBillCopyInput!) {
    orderBillCopy(input: $input) {
      payloadStatus
    }
  }
  `;

export default orderBillCopyMutation;