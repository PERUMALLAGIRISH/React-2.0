import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const SetBillingAddressMutation: DocumentNode = gql`
 mutation setBillingAddress($input: SetBillingAddressInput!) {
  setBillingAddress(input: $input) {
    payloadStatus
  }
 }
`;

export default SetBillingAddressMutation;