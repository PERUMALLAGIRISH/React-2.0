import {
  AccountActionType,
  CountriesActionType,
  FetchAccountAction,
  FetchAccountErrorAction,
  FetchAccountErrorGqlAction,
  FetchCountriesAction,
  ResetEditProfile,
  ResetEditProfileAction,
  SendNameChangeInfoAction,
  SendNameChangeInfoActionType,
  SendNameChangeInfoErrorAction,
  SetBillingAddressAction,
  SetBillingAddressActionType,
  UpdateContactAction,
  UpdateContactActionType,
  UpdateContactErrorAction,
  UpdatePasswordAction,
  UpdatePasswordActionType,
  UpdatePasswordErrorAction,
  UpdatePasswordReset,
  ValidateAddressAction,
  ValidateAddressActionType,
  ValidateEmailAction,
  ValidateEmailErrorAction
} from './ProfileAction';
import {
  Account,
  AddressValidityStatus,
  Country,
  SendNameChangeInfoPayload,
  SetBillingAddressPayload,
  UpdateContactPayload,
  UpdatePasswordPayload,
  SendVerificationEmailPayload
} from '../../model/types.d';

export interface InitialState {
  account: Account | null;
  sendVerificationEmailPayload:  SendVerificationEmailPayload | null;
  sendVerificationEmailPayloadError: Error | null;
  accountError: Error | null;
  accountFetchError: Error | null;
  updateContactPayload: UpdateContactPayload | null;
  updateContactPayloadError: Error | null;
  updatePasswordPayloadError: Error | null;
  updatePasswordPayload: UpdatePasswordPayload | null;
  sendNameChangeInfoPayload: SendNameChangeInfoPayload | null;
  sendNameChangeInfoPayloadError: Error | null;
  setBillingAddressPayload: SetBillingAddressPayload | null;
  setBillingAddressPayloadError: Error | null;
  addressValidityStatus: AddressValidityStatus | null;
  addressValidityError: Error | null;
  countries: Country[] | null;
  countriesError: Error | null;
}

const initialState: InitialState = {
  account: null,
  sendVerificationEmailPayload: null,
  sendVerificationEmailPayloadError: null,
  accountError: null,
  accountFetchError: null,
  updateContactPayload: null,
  updateContactPayloadError: null,
  updatePasswordPayload: null,
  updatePasswordPayloadError: null,
  sendNameChangeInfoPayload: null,
  sendNameChangeInfoPayloadError: null,
  setBillingAddressPayload: null,
  setBillingAddressPayloadError: null,
  addressValidityStatus: null,
  addressValidityError: null,
  countries: null,
  countriesError: null
};

type ProfileAction = FetchAccountAction |
  FetchAccountErrorAction |
  FetchAccountErrorGqlAction |
  ValidateEmailAction |
  ValidateEmailErrorAction |
  UpdateContactAction |
  UpdateContactErrorAction |
  UpdatePasswordAction |
  UpdatePasswordErrorAction |
  UpdatePasswordReset |
  SendNameChangeInfoAction |
  SendNameChangeInfoErrorAction |
  ResetEditProfileAction |
  SetBillingAddressAction |
  ValidateAddressAction |
  FetchCountriesAction;

export default (state = initialState, action: ProfileAction) => {
  switch (action.type) {
    case AccountActionType.FETCH_ACCOUNT:
      return {
        ...state,
        account: action.payload
      };
    case AccountActionType.FETCH_ACCOUNT_ERROR:
      return {
        ...state,
        accountError: action.payload
      };
    case AccountActionType.FETCH_ACCOUNT_ERROR_GQL:
      return {
        ...state,
        accountFetchError: action.payload
      };
    case AccountActionType.VALIDATE_EMAIL:
      return {
        ...state,
        sendVerificationEmailPayload: action.payload
      };
    case AccountActionType.VALIDATE_EMAIL_ERROR:
      return {
        ...state,
        sendVerificationEmailPayloadError: action.payload
      };
    case UpdateContactActionType.UPDATE_CONTACT:
      return {
        ...state,
        updateContactPayload: action.payload
      };
    case UpdateContactActionType.UPDATE_CONTACT_ERROR:
      return {
        ...state,
        updateContactPayloadError: action.payload
      };
    case UpdatePasswordActionType.UPDATE_PASSWORD:
      return {
        ...state,
        updatePasswordPayload: action.payload
      };
    case UpdatePasswordActionType.UPDATE_PASSWORD_ERROR:
      return {
        ...state,
        updatePasswordPayloadError: action.payload
      };
    case UpdatePasswordActionType.RESET_UPDATE_PASSWORD:
      return {
        ...state,
        updatePasswordPayload: null,
        updatePasswordPayloadError: null
      };
    case SendNameChangeInfoActionType.SEND_NAME_CHANGE_INFO:
      return {
        ...state,
        sendNameChangeInfoPayload: action.payload
      };
    case SendNameChangeInfoActionType.SEND_NAME_CHANGE_INFO_ERROR:
      return {
        ...state,
        sendNameChangeInfoPayloadError: action.payload
      };
    case ResetEditProfile.RESET_EDIT_PROFILE:
      return {
        ...state,
        updateContactPayload: null,
        updateContactPayloadError: null,
        sendVerificationEmailPayload: null,
        sendVerificationEmailPayloadError: null,
        sendNameChangeInfoPayload: null,
        sendNameChangeInfoPayloadError: null
      };
    case SetBillingAddressActionType.SET_BILLING_ADDRESS:
      return {
        ...state,
        setBillingAddressPayload: action.payload
      };
    case SetBillingAddressActionType.SET_BILLING_ADDRESS_ERROR:
      return {
        ...state,
        setBillingAddressPayloadError: action.payload
      };
    case SetBillingAddressActionType.RESET_BILLING_ADDRESS:
      return {
        ...state,
        setBillingAddressPayload: null,
        setBillingAddressPayloadError: null,
        account: null,
        accountError: null,
        addressValidityStatus: null,
        addressValidityError: null
      };
    case ValidateAddressActionType.VALIDATE_ADDRESS:
      return {
        ...state,
        addressValidityStatus: action.payload
      };
    case ValidateAddressActionType.VALIDATE_ADDRESS_ERROR:
      return {
        ...state,
        addressValidityError: action.payload
      };
    case CountriesActionType.FETCH_COUNTRIES:
      return {
        ...state,
        countries: action.payload
      };
    case CountriesActionType.FETCH_COUNTRIES_ERROR:
      return {
        ...state,
        countriesError: action.payload
      };
    default:
      return state;
  }
};
