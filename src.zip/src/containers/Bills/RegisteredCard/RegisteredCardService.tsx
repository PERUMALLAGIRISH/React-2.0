import {RegisteredCard} from '../../../model/types.d';

class RegisteredCardService {

  getDeleteRegisteredCardInput = (registeredCard: RegisteredCard) => {
    return {
      registeredCard: {
        aliasCc: registeredCard.aliasCc,
        expiryMonth: registeredCard.expiryMonth,
        expiryYear: registeredCard.expiryYear,
        number: registeredCard.number,
        paymentCard: registeredCard.paymentCard
      }
    };
  }

  isExpired = (month: number, year: number) => {
    const currentDate: Date = new Date();
    const currentYear: number = Number(currentDate.getFullYear().toString().substring(2));
    if (month === 0 && year === 0) {
      return false;
    }
    if (currentYear > year) {
      return true;
    } else if ((currentYear === year) && ((month - 1) < Number(currentDate.getMonth()))) {
      return true;
    } else {
      return false;
    }
  }
}
export const registeredCardService: RegisteredCardService = new RegisteredCardService();