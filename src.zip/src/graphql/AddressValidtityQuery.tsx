import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const AddressValidityQuery: DocumentNode = gql`
query addressValidity($input: AddressValidityInput!) {
    addressValidity(input: $input) {
        additional
        postalCode
        streetName
        streetNumber
        town
        confidence
        status
    }
} `;

export default AddressValidityQuery;