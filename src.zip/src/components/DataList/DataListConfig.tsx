export interface DataListConfig {
  value?: string;
  className?: string;
}