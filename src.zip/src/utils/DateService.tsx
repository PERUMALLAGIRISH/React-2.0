import moment from 'moment';

class DateService {
    formatDateTime: ((timestamp: string) => string) = (timestamp: string) => {
        return moment(timestamp).format('DD.MM.YYYY HH:mm');
    }

    formatDate: ((value: string) => string) = (value: string) => {
        return moment(value).format('DD.MM.YYYY');
    }

    currentTimeStamp = (): number => {
        return Math.round((new Date().getTime()) / 1000);
    }

    formatTimeStamp: ((date: Date) => number) = (date: Date) => {
        return Math.round(new Date(date).getTime() / 1000);
    }
}

export default new DateService();