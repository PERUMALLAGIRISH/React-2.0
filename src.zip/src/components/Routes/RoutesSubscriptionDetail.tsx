import * as React from 'react';
import NotFound from '../NotFound/NotFound';
import {HashRouter as Router, Route, Switch} from 'react-router-dom';
import SubscriptionDetail, {SubscriptionDetailProps} from '../../containers/SubscriptionDetail/SubscriptionDetail';
import SubscriptionDetailChangeOwner, {SubscriptionDetailChangeOwnerProps} from '../../containers/SubscriptionDetail/SubscriptionDetailChangeOwner/SubscriptionDetailChangeOwner';

class RoutesBills extends React.Component {

  render(): React.ReactNode {
    return (
      <Router>
        <Switch>
          <Route exact path='/:serviceSerial/:ratePlanId' component={(props: SubscriptionDetailProps) => <SubscriptionDetail {...props} {...this.props}/>} />
          <Route path='/:overlay' exact component={(props: SubscriptionDetailProps) => <SubscriptionDetail {...props} {...this.props}/>} />
          <Route exact path='/null/SubscriptionDetail' component={(props: SubscriptionDetailProps) => <SubscriptionDetail {...props} {...this.props}/>} />
          <Route exact path='/null/SubscriptionDetailChangeOwner/:serviceSerial' component={(props: SubscriptionDetailChangeOwnerProps) => <SubscriptionDetailChangeOwner {...props} {...this.props}/>} />
          <Route path='*' component={NotFound} />
        </Switch>
      </Router>
    )
  }
}
export default RoutesBills;