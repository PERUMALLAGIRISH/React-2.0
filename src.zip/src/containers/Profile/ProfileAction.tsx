import {Action, Dispatch} from 'redux';
import {
  AddressValidityInput,
  AddressValidityStatus,
  Country,
  EmailValidationStatus,
  SendNameChangeInfoPayload,
  SetBillingAddressInput,
  SetBillingAddressPayload,
  UpdateContactInput,
  UpdateContactPayload,
  UpdatePasswordInput,
  UpdatePasswordPayload
} from '../../model/types.d';
import UpdateContactMutation from '../../graphql/UpdateContactMutation';
import UpdatePasswordMutation from '../../graphql/UpdatePasswordMutation';
import GraphQL from '../../graphql/GraphQL';
import SendNameChangeInfoMutation from '../../graphql/SendNameChangeInfoMutation';
import SetBillingAddressMutation from '../../graphql/SetBillingAddressMutation';
import CountriesQuery from '../../graphql/CountriesQuery';
import AddressValidityQuery from '../../graphql/AddressValidtityQuery';
import AccountQuery from '../../graphql/AccountQuery';
import {CountriesResponse} from '../../model/client/CountriesResponse';
import {AddressValidityResponse} from '../../model/client/AddressValidityResponse';
import {AccountResponse} from '../../model/client/AccountResponse';
import {EmailValidationResponse} from '../../model/client/EmailValidationResponse';
import {SendNameChangeInfoResponse} from '../../model/client/SendNameChangeInfoResponse';
import {UpdateContactResponse} from '../../model/client/UpdateContactResponse';
import {SetBillingAddressResponse} from '../../model/client/SetBillingAddressResponse';
import {UpdatePasswordResponse} from '../../model/client/UpdatePasswordResponse';
import sendVerificationEmailMutation from '../../graphql/SendVerificationEmailMutation';

export enum AccountActionType {
  FETCH_ACCOUNT = 'FETCH_ACCOUNT',
  FETCH_ACCOUNT_ERROR = 'FETCH_ACCOUNT_ERROR',
  FETCH_ACCOUNT_ERROR_GQL = 'FETCH_ACCOUNT_ERROR_GQL',
  VALIDATE_EMAIL = 'VALIDATE_EMAIL',
  VALIDATE_EMAIL_ERROR = 'VALIDATE_EMAIL_ERROR'
};

export enum SetBillingAddressActionType {
  SET_BILLING_ADDRESS = 'SET_BILLING_ADDRESS',
  SET_BILLING_ADDRESS_ERROR = 'SET_BILLING_ADDRESS_ERROR',
  RESET_BILLING_ADDRESS = 'RESET_BILLING_ADDRESS'
}

export enum ValidateAddressActionType {
  VALIDATE_ADDRESS = 'VALIDATE_ADDRESS',
  VALIDATE_ADDRESS_ERROR = 'VALIDATE_ADDRESS_ERROR'
}

export enum CountriesActionType {
  FETCH_COUNTRIES = 'FETCH_COUNTRIES',
  FETCH_COUNTRIES_ERROR = 'FETCH_COUNTRIES_ERROR'
}

export enum ResetEditProfile {
  RESET_EDIT_PROFILE = 'RESET_EDIT_PROFILE'
}

export enum UpdateContactActionType {
  UPDATE_CONTACT = 'UPDATE_CONTACT',
  UPDATE_CONTACT_ERROR = 'UPDATE_CONTACT_ERROR'
};

export enum SendNameChangeInfoActionType {
  SEND_NAME_CHANGE_INFO = 'SEND_NAME_CHANGE_INFO',
  SEND_NAME_CHANGE_INFO_ERROR = 'SEND_NAME_CHANGE_INFO_ERROR'
};

export enum UpdatePasswordActionType {
  UPDATE_PASSWORD = 'UPDATE_PASSWORD',
  UPDATE_PASSWORD_ERROR = 'UPDATE_PASSWORD_ERROR',
  RESET_UPDATE_PASSWORD = 'RESET_UPDATE_PASSWORD'
};

export interface SetBillingAddressAction extends Action {
  type: SetBillingAddressActionType;
  payload: SetBillingAddressPayload;
}

export interface ValidateAddressAction extends Action {
  type: ValidateAddressActionType;
  payload: AddressValidityStatus;
}

export interface FetchCountriesAction extends Action {
  type: CountriesActionType;
  payload: Country[];
}

export interface ResetEditProfileAction extends Action {
  type: ResetEditProfile;
  payload: null;
}

export interface FetchAccountAction extends Action {
  type: AccountActionType.FETCH_ACCOUNT;
  payload: Account;
}

export interface FetchAccountErrorAction extends Action {
  type: AccountActionType.FETCH_ACCOUNT_ERROR;
  payload: Error;
}

export interface FetchAccountErrorGqlAction extends Action {
  type: AccountActionType.FETCH_ACCOUNT_ERROR_GQL;
  payload: Error
}

export interface ValidateEmailAction extends Action {
  type: AccountActionType.VALIDATE_EMAIL;
  payload: EmailValidationStatus;
}

export interface ValidateEmailErrorAction extends Action {
  type: AccountActionType.VALIDATE_EMAIL_ERROR;
  payload: Error;
}

export interface UpdateContactAction extends Action {
  type: UpdateContactActionType.UPDATE_CONTACT;
  payload: UpdateContactPayload;
}

export interface UpdateContactErrorAction extends Action {
  type: UpdateContactActionType.UPDATE_CONTACT_ERROR;
  payload: Error;
}

export interface UpdatePasswordAction extends Action {
  type: UpdatePasswordActionType.UPDATE_PASSWORD;
  payload: UpdatePasswordPayload;
}

export interface UpdatePasswordErrorAction extends Action {
  type: UpdatePasswordActionType.UPDATE_PASSWORD_ERROR;
  payload: Error;
}
export interface UpdatePasswordReset extends Action {
  type: UpdatePasswordActionType.RESET_UPDATE_PASSWORD;
  payload: UpdatePasswordPayload;
}

export interface SendNameChangeInfoAction extends Action {
  type: SendNameChangeInfoActionType.SEND_NAME_CHANGE_INFO;
  payload: SendNameChangeInfoPayload;
}

export interface SendNameChangeInfoErrorAction extends Action {
  type: SendNameChangeInfoActionType.SEND_NAME_CHANGE_INFO_ERROR;
  payload: Error;
}

export const fetchAccount: () => void = () => {
  return (dispatch: Dispatch) => {
    GraphQL.query({
      query: AccountQuery,
    }, (response: AccountResponse) => {
      if (response && response.account) {
        dispatch({ type: AccountActionType.FETCH_ACCOUNT, payload: response.account });
      } else {
        dispatch({ type: AccountActionType.FETCH_ACCOUNT_ERROR_GQL, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: AccountActionType.FETCH_ACCOUNT_ERROR, payload: error });
    });
  };
};

export const validateEmail: () => void = () => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: sendVerificationEmailMutation,
    }, (response: EmailValidationResponse) => {
      if (response && response.sendVerificationEmail) {
        dispatch({ type: AccountActionType.VALIDATE_EMAIL, payload: response.sendVerificationEmail });
      } else {
        dispatch({ type: AccountActionType.VALIDATE_EMAIL_ERROR, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: AccountActionType.VALIDATE_EMAIL_ERROR, payload: error });
    });
  };
};

export const sendNameInfo: () => void = () => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: SendNameChangeInfoMutation,
    }, (response: SendNameChangeInfoResponse) => {
      if (response && response.sendNameChangeInfo) {
        dispatch({ type: SendNameChangeInfoActionType.SEND_NAME_CHANGE_INFO, payload: response.sendNameChangeInfo });
      } else {
        dispatch({ type: SendNameChangeInfoActionType.SEND_NAME_CHANGE_INFO_ERROR, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: SendNameChangeInfoActionType.SEND_NAME_CHANGE_INFO_ERROR, payload: error });
    });
  };
};

export const updateContact: any = (updateContactInput: UpdateContactInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: UpdateContactMutation,
      variables: { input: updateContactInput}
    }, (response: UpdateContactResponse) => {
      if (response && response.updateContact) {
        dispatch({ type: UpdateContactActionType.UPDATE_CONTACT, payload: response.updateContact });
      } else {
        dispatch({ type: UpdateContactActionType.UPDATE_CONTACT_ERROR, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: UpdateContactActionType.UPDATE_CONTACT_ERROR, payload: error });
    });
  };
};

export const resetEditProfile: () => void = () => {
  return (dispatch: Dispatch) => {
    dispatch({ type: ResetEditProfile.RESET_EDIT_PROFILE, payload: null });
  };
}

export const setBillingAddress: any = (setBillingAddressInput: SetBillingAddressInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: SetBillingAddressMutation,
      variables: { input: setBillingAddressInput}
    }, (response: SetBillingAddressResponse) => {
      if (response && response.setBillingAddress) {
        dispatch({ type: SetBillingAddressActionType.SET_BILLING_ADDRESS, payload: response.setBillingAddress });
      } else {
        dispatch({ type: SetBillingAddressActionType.SET_BILLING_ADDRESS_ERROR, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: SetBillingAddressActionType.SET_BILLING_ADDRESS_ERROR, payload: error });
    });
  };
};

export const resetBillingAddress: () => void = () => {
  return (dispatch: Dispatch) => {
    dispatch({ type: SetBillingAddressActionType.RESET_BILLING_ADDRESS, payload: null });
  };
};

export const fetchCountries: () => void = () => {
  return (dispatch: Dispatch) => {
    GraphQL.query({
      query: CountriesQuery
    }, (response: CountriesResponse) => {
      if (response && response.countries) {
        dispatch({ type: CountriesActionType.FETCH_COUNTRIES, payload: response.countries});
      } else {
        dispatch({ type: CountriesActionType.FETCH_COUNTRIES_ERROR, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: CountriesActionType.FETCH_COUNTRIES_ERROR, payload: error });
    });
  };
};

export const validateAddress: any = (addressValidityInput: AddressValidityInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.query({
      query: AddressValidityQuery,
      variables: { input: addressValidityInput}
    }, (response: AddressValidityResponse) => {
      if (response && response.addressValidity) {
        dispatch({ type: ValidateAddressActionType.VALIDATE_ADDRESS, payload: response.addressValidity });
      } else {
        dispatch({ type: ValidateAddressActionType.VALIDATE_ADDRESS_ERROR, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: ValidateAddressActionType.VALIDATE_ADDRESS_ERROR, payload: error });
    });
  };
};

export const updatePassword: any = (updatePasswordInput: UpdatePasswordInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: UpdatePasswordMutation,
      variables: { input: updatePasswordInput}
    }, (response: UpdatePasswordResponse) => {
      if (response && response.updatePassword) {
        dispatch({ type: UpdatePasswordActionType.UPDATE_PASSWORD, payload: response.updatePassword });
      } else {
        dispatch({ type: UpdatePasswordActionType.UPDATE_PASSWORD_ERROR, payload: response });
      }
    }, (error: Error) => {
      dispatch({ type: UpdatePasswordActionType.UPDATE_PASSWORD_ERROR, payload: error });
    });
  };
};

export const resetUpdatePassword: () => void = () => {
  return (dispatch: Dispatch) => {
    dispatch({ type: UpdatePasswordActionType.RESET_UPDATE_PASSWORD, payload: null });
  };
};
