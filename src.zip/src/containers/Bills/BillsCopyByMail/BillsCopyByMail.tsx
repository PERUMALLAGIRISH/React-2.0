import * as React from 'react';
import {OrderBillCopyInput, OrderBillCopyPayload, PayloadStatus} from '../../../model/types.d';
import {Loader} from '../../../components/Loader/Loader';
import {Success} from '../../../components/Success/Success';
import {Button} from '../../../components/Form/Button/Button';
import I18n from '../../../utils/helper/I18n';

interface BillsCopyByMailState {
  isLoading: boolean;
  isChecked: boolean;
  formStatus: boolean;
}
interface BillsCopyByMailProps {
  handleClosePopup: any;
  orderBillCopyPayload: OrderBillCopyPayload;
  orderBillCopyPayloadError: Error | null;
  id: string;
  setOrderBillCopy: (orderBillCopyInput: OrderBillCopyInput) => void;
  resetOrderBillCopy: any;
}

export class BillsCopyByMail extends React.Component<BillsCopyByMailProps, BillsCopyByMailState> {
  constructor(props: BillsCopyByMailProps) {
    super(props);
    this.state = {
      isLoading: false,
      isChecked: false,
      formStatus: true
    }
  }

  static getDerivedStateFromProps(nextProps: BillsCopyByMailProps, prevState: BillsCopyByMailState): any | null {
    if ((nextProps.orderBillCopyPayload || nextProps.orderBillCopyPayloadError) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  componentWillUnmount(): void {
    const {resetOrderBillCopy} = this.props;
    resetOrderBillCopy();
  }

  handleOrderBillCopy(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    const {id, setOrderBillCopy} = this.props;
    const orderBillCopyInput: OrderBillCopyInput = {};
    orderBillCopyInput.billId = id;
    setOrderBillCopy(orderBillCopyInput);
    this.setState({formStatus: false, isLoading: true});
  }

  handleChange = (): void => {
    const {isChecked} = this.state;
    this.setState({
      isChecked: !isChecked
    })
  }

  renderCopyByMailSuccess(): JSX.Element {
    const {orderBillCopyPayload, orderBillCopyPayloadError, handleClosePopup} = this.props;
    let label: string = '';
    let title: string = '';
    if (orderBillCopyPayloadError || (orderBillCopyPayload && orderBillCopyPayload.payloadStatus === PayloadStatus.NOK)) {
      label = `${I18n.translate('BillsCopyByMail.Error.Label')}`;
      title = `${I18n.translate('BillsCopyByMail.Error.Title')}`;
    } else if (orderBillCopyPayload && orderBillCopyPayload.payloadStatus === PayloadStatus.OK) {
      label = `${I18n.translate('BillsCopyByMail.Success.Text')}`;
      title = `${I18n.translate('BillsCopyByMail.Success.Title')}`;
    }
    return (
      <Success
        imageSource={'/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/overall_success_mail.png'}
        heading = {title}
        text = {label}
        button = {I18n.translate('BillsCopyByMail.Close.Button.Text')}
        handleClick = {handleClosePopup}
      />
    );
  }

  renderCopyByPostPopup(): JSX.Element {
    const {isChecked} = this.state;
    const {id, handleClosePopup} = this.props;
    return(
      <div className='popup-message-box popup-message-box--free-buttons popup-message-box-680'>
        <h2 className='title-large'>{I18n.translate('BillsCopyByMail.Order.Label')} {id}?</h2>
        <div className='text-small text-pad-lr-10perc'>
          {I18n.translate('BillsCopyByMail.Order.Text')}
        </div>
        <div className='text-small'>
          {I18n.translate('BillsCopyByMail.Order.Title')}
        </div>
        <div className='vertical_spacer x8'></div>
        <div className='product_item'>
          <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
            <div>
              <input
                id='bills_bill_copy_order'
                type='checkbox'
                onChange = {(e: React.ChangeEvent<HTMLInputElement>) => this.handleChange()}
              />
              <label className='form_radio_label' htmlFor={'bills_bill_copy_order'}>
                <span className='text-small bold inline mobile-top-7'>
                  {I18n.translate('BillsCopyByMail.Mail.Text')}
                </span>
              </label>
            </div>
          </div>
          <div className='product_item__price_2'>
            <div className='product_item__price_string'>{I18n.translate('BillsCopyByMail.Order.Cost.Text')}</div>
          </div>
        </div>
        <div className='vertical_spacer x8'></div>
        <div className='form-item'>
          <div className='form-item__button full_width_on_mobile'>
            <Button
              className = {'button extra_wide full_width_on_mobile transparent_background'}
              handleClick = {handleClosePopup}
              label = {I18n.translate('BillsCopyByMail.Order.Cancel.Label')}
            />
            <Button
              className = {'button extra_wide full_width_on_mobile'}
              handleClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.handleOrderBillCopy(e)}
              label = {I18n.translate('BillsCopyByMail.Order.Button.Text')}
              disabled = {!isChecked}
            />
          </div>
        </div>
      </div>
    )
  }

  render(): React.ReactNode {
    const {formStatus, isLoading} = this.state;
    return (
      <React.Fragment>
        <div className='overlay'></div>
        <div className='popup__container'>
          <div className='popup'>
            {isLoading ? <Loader /> : null}
            {formStatus ? this.renderCopyByPostPopup() : null}
            {!formStatus ? this.renderCopyByMailSuccess() : null}
          </div>
        </div>
      </React.Fragment>
    );
  }
}