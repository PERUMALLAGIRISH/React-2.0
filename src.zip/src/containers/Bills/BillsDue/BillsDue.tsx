import * as React from 'react';
import {BillsInvoiceButtons} from '../BillsInvoiceButtons/BillsInvoiceButtons';
import {Button} from '../../../components/Form/Button/Button';
import CurrencyFormatService  from '../../../utils/CurrencyFormatService';
import I18n from '../../../utils/helper/I18n';
import {BillsDueConstants} from '../BillsConstants';
import {OrderBillCopyPayload} from '../../../model/types.d';

export interface BillsDueProps {
  id: string;
  billDate: string;
  dueOn: string;
  openAmount: number;
  digitalInvoiceUrl: string;
  isPayButton?: boolean;
  downloadUrl: string;
  isOverdue: boolean;
  status: string;
  documentType: string;
  orderBillCopyPayload: OrderBillCopyPayload;
  orderBillCopyPayloadError: Error | null;
  imgOverdue: string | undefined;
  handleClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
  setOrderBillCopy: () => void;
  resetOrderBillCopy: () => void;
}

export class BillsDue extends React.Component<BillsDueProps> {
  constructor(props: BillsDueProps) {
    super(props);
  }

  render(): React.ReactNode {
    const {id, openAmount, isOverdue, billDate, dueOn, status, digitalInvoiceUrl, downloadUrl, setOrderBillCopy, isPayButton, handleClick, documentType, orderBillCopyPayload, orderBillCopyPayloadError, resetOrderBillCopy, imgOverdue} = this.props;
    return (
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
        <div className='bills-outstanding-card-container no-bottom-margin'>
          <div className='bills__outstanding-bill content-box medium_vertical_padding no-bottom-margin'>
            <div className='billing-date__box'>
              <div className='text-small pale-grey t-strong-slight inline no-bottom-margin'>
                {I18n.translate('BillsDue.BillingDate.Label')} <div className='text-small grey-brown t-strong-slight inline'>
                   {billDate}
                </div>
              </div>
            </div>
            <div className='outstanding_bill__top_row--pull_up'>
              <div className='outstanding_bill__top_row--due-date p-flexbox'>
                <div className='inline'>
                  <img src={imgOverdue}/>
                  <div className={isOverdue ? 'text-small t-strong inline ok-color no-bottom-margin' : 'text-small t-strong inline gelb no-bottom-margin'}>
                    {isOverdue ? I18n.translate('BillsDue.OverDue.Label') : I18n.translate('BillsDue.DueTo.Label') } {dueOn}
                  </div>
                </div>
                <div className='text-right is-hidden-tablet'>
                  <div className='text-small pale-grey t-strong-slight inline no-bottom-margin'>
                   {status === BillsDueConstants.DUNNED && documentType === BillsDueConstants.CH ? I18n.translate('BillsDue.DunningCharge.Label') : I18n.translate('BillsDue.BillNo.Label') }
                  </div> {id ?
                  <div className='text-small grey-brown t-strong-slight inline'>
                    {id}
                  </div> : null }
                </div>
              </div>
            </div>
            <div className='bills-price bills-price--large has-margin'>
            {CurrencyFormatService.getCurrencyFormat(openAmount)}
            </div>
            <div className='is-hidden-desktop'>
              <div className='text-small pale-grey t-strong-slight inline'>
                {status === BillsDueConstants.DUNNED && documentType === BillsDueConstants.CH ? I18n.translate('BillsDue.DunningCharge.Label') : I18n.translate('BillsDue.BillNo.Label') }
              </div> {id ?
                <div className='text-small grey-brown t-strong-slight inline'>
                  {id}
                </div> : null}
            </div>
            <BillsInvoiceButtons
              digitalInvoiceUrl= {digitalInvoiceUrl}
              downloadUrl = {downloadUrl}
              id = {id}
              setOrderBillCopy = {setOrderBillCopy}
              orderBillCopyPayloadError = {orderBillCopyPayloadError}
              orderBillCopyPayload = {orderBillCopyPayload}
              resetOrderBillCopy = {resetOrderBillCopy}
            />
            {isPayButton ?
              <Button
                handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => handleClick(e)}
                label = {I18n.translate('BillsDue.Outstanding.Text')}
                className = 'button button--flex button--large full_width_on_mobile half_width ok_color pay--no-half-width'
              /> : null}
          </div>
        </div>
      </div>
    );
  }
}
