import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const BillsDunningJokerMutation: DocumentNode = gql`
  mutation requestDunningJoker  {
    requestDunningJoker {
      payloadStatus
    }
  }
`;

export default BillsDunningJokerMutation;