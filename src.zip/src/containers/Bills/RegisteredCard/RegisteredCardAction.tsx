import {Action, Dispatch} from 'redux';
import GraphQL from '../../../graphql/GraphQL';
import {DeleteRegisteredCardPayload, DeleteRegisteredCardInput} from '../../../model/types.d';
import DeleteRegisteredCardMutation from '../../../graphql/DeleteRegisteredCardMutation';
import {DeleteRegisteredCardResponse} from '../../../model/client/DeleteRegisteredCardResponse';

export enum DeleteRegisteredCardActionType {
  DELETE_REGISTERED_CARD_SUCCESS = 'DELETE_REGISTERED_CARD_SUCCESS',
  DELETE_REGISTERED_CARD_ERROR = 'DELETE_REGISTERED_CARD_ERROR',
  DELETE_REGISTERED_CARD_RESET = 'DELETE_REGISTERED_CARD_RESET'
}

export interface DeleteRegisteredCardAction extends Action {
  type: DeleteRegisteredCardActionType;
  payload: DeleteRegisteredCardPayload;
}

export const deleteRegisteredCardRequest: any = (input: DeleteRegisteredCardInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: DeleteRegisteredCardMutation,
      variables: {input: input}
    }, (response: DeleteRegisteredCardResponse) => {
      if (response && response.deleteRegisteredCard) {
        dispatch({type: DeleteRegisteredCardActionType.DELETE_REGISTERED_CARD_SUCCESS, payload: response.deleteRegisteredCard});
      } else {
        dispatch({type: DeleteRegisteredCardActionType.DELETE_REGISTERED_CARD_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: DeleteRegisteredCardActionType.DELETE_REGISTERED_CARD_ERROR, payload: error});
    });
  };
};

export const deleteRegisteredCardReset: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: DeleteRegisteredCardActionType.DELETE_REGISTERED_CARD_RESET, payload: undefined});
  };
};