import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const UpdateContactMutation: DocumentNode = gql`
  mutation updateContact($input: UpdateContactInput!) {
    updateContact(input: $input) {
      payloadStatus
    }
  }
`;

export default UpdateContactMutation;