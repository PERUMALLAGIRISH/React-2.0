import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const UpdatePasswordMutation: DocumentNode = gql`
  mutation updatePassword ($input: UpdatePasswordInput!) {
    updatePassword(input: $input) {
      payloadStatus
    }
  }
`;

export default UpdatePasswordMutation;