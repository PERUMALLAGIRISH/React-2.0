import * as React from 'react';

interface FormErrorsProps {
  formErrors: string[];
}

export class FormErrors extends React.Component<FormErrorsProps> {
  constructor(props: FormErrorsProps) {
    super(props);
  }
  render(): React.ReactNode {
    const {formErrors} = this.props;
    return (
      <div className='l-col l-1of1'>
        <div className='content-box'>
          <h3 className='page-title_medium--red lighter left-text'>Error</h3>
          {Object.keys(formErrors).map((fieldName: any, i: number) => {
            if (formErrors[fieldName]) {
              return (
                <div className='text-small' key={i}>
                  {formErrors[fieldName]}
                </div>
              );
            }
          })}
        </div>
      </div>
    );
  }
};