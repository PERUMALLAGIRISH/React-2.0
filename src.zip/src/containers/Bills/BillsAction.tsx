import {Action, Dispatch} from 'redux';
import {Account, OrderBillCopyPayload, OrderBillCopyInput, OrderAccountStatementInput, OrderAccountStatementPayload, RequestDunningDeblockOnTrustPayLoad, RequestDunningJokerPayLoad, PaymentMethodTypeInput, PaymentState, OrderAdditionalPaymentSlipInput, OrderAdditionalPaymentSlipPayload, BillAnonymizationLevelPayload, BillAnonymizationLevelInput, SetBillDeliveryMethodInput, SetBillDeliveryMethodPayload} from '../../model/types.d';
import BillsQuery from '../../graphql/BillsQuery';
import BillsDunningJokerMutation from '../../graphql/BillsDunningJokerMutation';
import BillsDunningDeblockOnTrustMutation from './../../graphql/BillsDunningDeblockOnTrustMutation';
import orderBillCopyMutation from '../../graphql/OrderCopyByMailMutation';
import setBillAnonymizationLevelMutation from '../../graphql/setBillAnonymizationLevelMutation';
import setBillDeliveryMethodMutation from './../../graphql/setBillDeliveryMethodMutation';
import {BillAnonymizationLevelResponse} from '../../model/client/BillAnonymizationLevelResponse';
import {SetBillDeliveryMethodResponse} from '../../model/client/SetBillDeliveryMethodResponse';
import GraphQL from '../../graphql/GraphQL';
import {OrderBillCopyResponse} from '../../model/client/OrderBillCopyResponse';
import orderAccountStatementMutation from '../../graphql/OrderAccountStatementMutation';
import SetPaymentMethodMutation from '../../graphql/SetPaymentMethodMutation';
import {SetPaymentMethodResponse} from '../../model/client/SetPaymentMethodResponse';
// import paymentStateQuery from '../../graphql/PaymentStateQuery';
// import { PaymentStateResponse } from '../../model/client/PaymentStateResponse';
import OrderAdditionalPaymentSlipMutation from '../../graphql/OrderAdditionalPaymentSlipMutation';
import {OrderAccountStatementResponse} from '../../model/client/OrderAccountStatementResponse';

export enum BillsActionType {
  FETCH_BILLS_INFO = 'FETCH_BILLS_INFO',
  FETCH_BILLS_INFO_ERROR = 'FETCH_BILLS_INFO_ERROR',
  RESET_BILLS_SCREEN = 'RESET_BILLS_SCREEN'
};

export enum OrderBillCopyActionType {
  ORDER_BILL_COPY = 'ORDER_BILL_COPY',
  ORDER_BILL_COPY_ERROR = 'ORDER_BILL_COPY_ERROR',
  RESET_ORDER_BILL_COPY = 'RESET_ORDER_BILL_COPY'
};
export enum RequestAccountStatementActionType {
  ORDER_ACCOUNT_STATEMENT = 'ORDER_ACCOUNT_STATEMENT',
  ORDER_ACCOUNT_STATEMENT_ERROR = 'ORDER_ACCOUNT_STATEMENT_ERROR',
  RESET_ORDER_ACCOUNT_STATEMENT = 'RESET_ORDER_ACCOUNT_STATEMENT'
}

export interface OrderAccountStatementAction extends Action {
  type: RequestAccountStatementActionType.ORDER_ACCOUNT_STATEMENT;
  payload: OrderAccountStatementPayload;
}

export enum RequestDunningJokerActionType {
  REQUEST_DUNNING_JOKER = 'REQUEST_DUNNING_JOKER',
  REQUEST_DUNNING_JOKER_ERROR = 'REQUEST_DUNNING_JOKER_ERROR',
  RESET_REQUEST_DUNNING_JOKER = 'RESET_REQUEST_DUNNING_JOKER',
};

export enum RequestDunningDeblockOnTrustActionType {
  REQUEST_DUNNING_DEBLOCK_ON_TRUST = 'REQUEST_DUNNING_DEBLOCK_ON_TRUST',
  REQUEST_DUNNING_DEBLOCK_ON_TRUST_ERROR = 'REQUEST_DUNNING_DEBLOCK_ON_TRUST_ERROR',
  RESET_REQUEST_DUNNING_DEBLOCK_ON_TRUST = 'RESET_REQUEST_DUNNING_DEBLOCK_ON_TRUST',
}

export enum PaymentStateActionType {
  FETCH_PAYMENT_STATE = 'FETCH_PAYMENT_STATE',
  FETCH_PAYMENT_STATE_ERROR = 'FETCH_PAYMENT_STATE_ERROR'
}

export enum BillAnonymizationLevelActionType {
  BILL_ANONYMIZATION_LEVEL = 'BILL_ANONYMIZATION_LEVEL',
  BILL_ANONYMIZATION_LEVEL_ERROR = 'BILL_ANONYMIZATION_LEVEL_ERROR',
  RESET_BILL_ANONYMIZATION_LEVEL = 'RESET_BILL_ANONYMIZATION_LEVEL',
};

export enum BillDeliveryMethodActionType {
  BILL_DELIVERY_METHOD = 'BILL_DELIVERY_METHOD',
  BILL_DELIVERY_METHOD_ERROR = 'BILL_DELIVERY_METHOD_ERROR',
  RESET_BILL_DELIVERY_METHOD = 'RESET_BILL_DELIVERY_METHOD',
};

export interface OrderAccountStatementErrorAction extends Action {
  type: RequestAccountStatementActionType.ORDER_ACCOUNT_STATEMENT_ERROR;
  payload: Error;
}

export interface ResetOrderAccountStatement extends Action {
  type: RequestAccountStatementActionType.RESET_ORDER_ACCOUNT_STATEMENT;
  payload: null;
}

export interface FetchBillsInfoAction extends Action {
  type: BillsActionType.FETCH_BILLS_INFO;
  payload: Account;
}

export interface FetchBillsInfoErrorAction extends Action {
  type: BillsActionType.FETCH_BILLS_INFO_ERROR;
  payload: Error;
}

export interface ResetBillsScreenAction extends Action {
  type: BillsActionType.RESET_BILLS_SCREEN;
  payload: null;
}

export interface OrderBillCopyAction extends Action {
  type: OrderBillCopyActionType.ORDER_BILL_COPY;
  payload: OrderBillCopyPayload;
}

export interface OrderBillCopyErrorAction extends Action {
  type: OrderBillCopyActionType.ORDER_BILL_COPY_ERROR;
  payload: Error;
}

export interface ResetOrderBillCopyAction extends Action {
  type: OrderBillCopyActionType.RESET_ORDER_BILL_COPY;
  payload: null;
}
export interface RequestDunningJokerAction extends Action {
  type: RequestDunningJokerActionType.REQUEST_DUNNING_JOKER;
  payload: RequestDunningDeblockOnTrustPayLoad;
}

export interface RequestDunningJokerErrorAction extends Action {
  type: RequestDunningJokerActionType.REQUEST_DUNNING_JOKER_ERROR;
  payload: Error;
}

export interface ResetRequestDunningJokerAction extends Action {
  type: RequestDunningJokerActionType.RESET_REQUEST_DUNNING_JOKER;
  payload: null;
}

export interface RequestDunningDeblockOnTrustAction extends Action {
  type: RequestDunningDeblockOnTrustActionType.REQUEST_DUNNING_DEBLOCK_ON_TRUST;
  payload: RequestDunningDeblockOnTrustPayLoad;
}

export interface RequestDunningDeblockOnTrustErrorAction extends Action {
  type: RequestDunningDeblockOnTrustActionType.REQUEST_DUNNING_DEBLOCK_ON_TRUST_ERROR;
  payload: Error;
}

export interface ResetRequestDunningDeblockOnTrustAction extends Action {
  type: RequestDunningDeblockOnTrustActionType.RESET_REQUEST_DUNNING_DEBLOCK_ON_TRUST;
  payload: null;
}
export interface SetPaymentMethodAction extends Action {
  type: SetPaymentMethodActionType.SET_PAYMENT_METHOD;
  payload: null;
}

export interface SetPaymentMethodErrorAction extends Action {
  type: SetPaymentMethodActionType.SET_PAYMENT_METHOD_ERROR;
  payload: null;
}

export enum SetPaymentMethodActionType {
  SET_PAYMENT_METHOD = 'SET_PAYMENT_METHOD',
  SET_PAYMENT_METHOD_ERROR = 'SET_PAYMENT_METHOD_ERROR'
};

export interface PaymentStateAction extends Action {
  type: PaymentStateActionType;
  payload: PaymentState;
}
export interface BillAnonymizationLevelAction extends Action {
  type: BillAnonymizationLevelActionType.BILL_ANONYMIZATION_LEVEL;
  payload: BillAnonymizationLevelPayload;
}

export interface BillAnonymizationLevelErrorAction extends Action {
  type: BillAnonymizationLevelActionType.BILL_ANONYMIZATION_LEVEL_ERROR;
  payload: Error;
}

export interface ResetBillAnonymizationLevel extends Action {
  type: BillAnonymizationLevelActionType.RESET_BILL_ANONYMIZATION_LEVEL;
  payload: null;
}

export interface BillDeliveryMethodAction extends Action {
  type: BillDeliveryMethodActionType.BILL_DELIVERY_METHOD;
  payload: SetBillDeliveryMethodPayload;
}

export interface BillDeliveryMethodErrorAction extends Action {
  type: BillDeliveryMethodActionType.BILL_DELIVERY_METHOD_ERROR;
  payload: Error;
}

export interface ResetBillDeliveryMethod extends Action {
  type: BillDeliveryMethodActionType.RESET_BILL_DELIVERY_METHOD;
  payload: null;
}

export interface BillsResponse {
  account: Account;
}

export interface RequestOrderAccountStatementResponse {
  orderAccountStatement: OrderAccountStatementPayload;
}
export interface RequestDunningJokerResponse {
  requestDunningJoker: RequestDunningJokerPayLoad;
}

export interface RequestDunningDeblockOnTrustResponse {
  requestDunningDeblockOnTrust: RequestDunningDeblockOnTrustPayLoad;
}
export interface OrderBillCopyResponse {
  orderBillCopy: OrderBillCopyPayload;
}

export enum OrderAdditionalPaymentSlipActionType {
  ORDER_ADDITIONAL_PAYSLIP = 'ORDER_ADDITIONAL_PAYSLIP',
  ORDER_ADDITIONAL_PAYSLIP_ERROR = 'ORDER_ADDITIONAL_PAYSLIP_ERROR',
  ORDER_ADDITIONAL_PAYSLIP_RESET = 'ORDER_ADDITIONAL_PAYSLIP_RESET'
}

export interface OrderAdditionalPaymentSlipAction extends Action {
  type: OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP;
  payload: OrderAdditionalPaymentSlipPayload;
}

export interface OrderAdditionalPaymentSlipErrorAction extends Action {
  type: OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP_ERROR;
  payload: Error;
}

export interface ResetOrderAdditionalPaymentSlipAction extends Action {
  type: OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP_RESET;
  payload: null;
}

export interface OrderAdditionalPaymentSlipResponse {
  orderAdditionalPaymentSlip: OrderAdditionalPaymentSlipPayload;
}

export interface BillAnonymizationLevelResponse {
  setBillAnonymizationLevel: BillAnonymizationLevelPayload;
}

export interface BillDeliveryMethodResponse {
  setBillDeliveryMethod: SetBillDeliveryMethodPayload;
}

export const fetchBillsInfo: any = () => {
  return (dispatch: Dispatch) => {
    GraphQL.query({
      query: BillsQuery,
    }, (response: BillsResponse) => {
      if (response && response.account) {
        dispatch({type: BillsActionType.FETCH_BILLS_INFO, payload: response.account});
      }
    }, (error: Error) => {
      dispatch({type: BillsActionType.FETCH_BILLS_INFO_ERROR, payload: error});
    });
  };
};

export const resetBills: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: BillsActionType.RESET_BILLS_SCREEN, payload: null});
  }
};

export const setOrderAdditionalPaymentSlip: any = (orderAdditionalPaymentSlipInput: OrderAdditionalPaymentSlipInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: OrderAdditionalPaymentSlipMutation,
      variables: {input: orderAdditionalPaymentSlipInput}
    }, (response: OrderAdditionalPaymentSlipResponse) => {
      if (response && response.orderAdditionalPaymentSlip) {
        dispatch({type: OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP, payload: response.orderAdditionalPaymentSlip});
      } else {
        dispatch({type: OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP_ERROR, payload: response});
      }
    }, (error: Error) => {
       dispatch({type: OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP_ERROR, payload: error});
    });
  };
};

export const setOrderBillCopy: any = (orderBillCopyInput: OrderBillCopyInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: orderBillCopyMutation,
      variables: {input: orderBillCopyInput}
    }, (response: OrderBillCopyResponse) => {
      if (response && response.orderBillCopy) {
        dispatch({type: OrderBillCopyActionType.ORDER_BILL_COPY, payload: response.orderBillCopy});
      } else {
        dispatch({type: OrderBillCopyActionType.ORDER_BILL_COPY_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: OrderBillCopyActionType.ORDER_BILL_COPY_ERROR, payload: error});
    });
  };
};
export const sendBillsPayLater: () => any = () => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: BillsDunningJokerMutation,
    }, (response: RequestDunningJokerResponse) => {
      if (response && response.requestDunningJoker) {
        dispatch({type: RequestDunningJokerActionType.REQUEST_DUNNING_JOKER, payload: response.requestDunningJoker});
      } else {
        dispatch({type: RequestDunningJokerActionType.REQUEST_DUNNING_JOKER_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: RequestDunningJokerActionType.REQUEST_DUNNING_JOKER_ERROR, payload: error});
    });
  };
};

export const resetOrderBillCopy: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: OrderBillCopyActionType.RESET_ORDER_BILL_COPY, payload: null});
  };
}
export const orderAccountStatementRequest: any = (orderAccountStatementInput: OrderAccountStatementInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: orderAccountStatementMutation,
      variables: {input: orderAccountStatementInput}
    }, (response: OrderAccountStatementResponse) => {
      if (response && response.orderAccountStatement) {
        dispatch({type: RequestAccountStatementActionType.ORDER_ACCOUNT_STATEMENT, payload: response.orderAccountStatement});
      } else {
        dispatch({type: RequestAccountStatementActionType.ORDER_ACCOUNT_STATEMENT_ERROR, payload: response});
      }
    }, (error: Error) => {
       dispatch({type: RequestAccountStatementActionType.ORDER_ACCOUNT_STATEMENT_ERROR, payload: error});
    });
  };
};
export const resetBillsPayLater: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: RequestDunningJokerActionType.RESET_REQUEST_DUNNING_JOKER, payload: null});
  };
}

export const sendBillsDeblockActivate: () => any = () => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: BillsDunningDeblockOnTrustMutation,
    }, (response: RequestDunningDeblockOnTrustResponse) => {
      if (response && response.requestDunningDeblockOnTrust) {
        dispatch({type: RequestDunningDeblockOnTrustActionType.REQUEST_DUNNING_DEBLOCK_ON_TRUST, payload: response.requestDunningDeblockOnTrust});
      } else {
        dispatch({type: RequestDunningDeblockOnTrustActionType.REQUEST_DUNNING_DEBLOCK_ON_TRUST_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: RequestDunningDeblockOnTrustActionType.REQUEST_DUNNING_DEBLOCK_ON_TRUST_ERROR, payload: error});
    });
  };
};

export const resetBillsDeblockActivate: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: RequestDunningDeblockOnTrustActionType.RESET_REQUEST_DUNNING_DEBLOCK_ON_TRUST, payload: null});
  };
}
export const setPaymentMethodRequest: any = (updatePaymentMethodInput: PaymentMethodTypeInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: SetPaymentMethodMutation,
      variables: {input: updatePaymentMethodInput}
    }, (response: SetPaymentMethodResponse) => {
      if (response && response.setPaymentMethod) {
        dispatch({type: SetPaymentMethodActionType.SET_PAYMENT_METHOD, payload: response.setPaymentMethod});
      } else {
        dispatch({type: SetPaymentMethodActionType.SET_PAYMENT_METHOD_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: SetPaymentMethodActionType.SET_PAYMENT_METHOD_ERROR, payload: error});
    });
  };
};

export const setbillAnonymizationLevel: any = (billAnonymizationLevelInput: BillAnonymizationLevelInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: setBillAnonymizationLevelMutation,
      variables: {input: billAnonymizationLevelInput}
    }, (response: BillAnonymizationLevelResponse) => {
      if (response && response.setBillAnonymizationLevel) {
        dispatch({type: BillAnonymizationLevelActionType.BILL_ANONYMIZATION_LEVEL, payload: response.setBillAnonymizationLevel});
      } else {
        dispatch({type: BillAnonymizationLevelActionType.BILL_ANONYMIZATION_LEVEL_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: BillAnonymizationLevelActionType.BILL_ANONYMIZATION_LEVEL_ERROR, payload: error});
    });
  };
};

export const resetbillAnonymizationLevel: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: BillAnonymizationLevelActionType.RESET_BILL_ANONYMIZATION_LEVEL, payload: null});
  };
}

export const setbillDeliveryMethod: any = (setBillDeliveryMethodInput: SetBillDeliveryMethodInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: setBillDeliveryMethodMutation,
      variables: {input: setBillDeliveryMethodInput}
    }, (response: SetBillDeliveryMethodResponse) => {
      if (response && response.setBillDeliveryMethod) {
        dispatch({type: BillDeliveryMethodActionType.BILL_DELIVERY_METHOD, payload: response.setBillDeliveryMethod});
      } else {
        dispatch({type: BillDeliveryMethodActionType.BILL_DELIVERY_METHOD_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: BillDeliveryMethodActionType.BILL_DELIVERY_METHOD_ERROR, payload: error});
    });
  };
};

export const resetbillDeliveryMethod: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: BillDeliveryMethodActionType.RESET_BILL_DELIVERY_METHOD, payload: null});
  };
}

export const resetOrderAccountStatement: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: RequestAccountStatementActionType.RESET_ORDER_ACCOUNT_STATEMENT, payload: null});
  };
}
