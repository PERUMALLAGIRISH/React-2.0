import { PaymentPayload } from '../types.d';

export interface PaymentResponse {
  makePayment: PaymentPayload;
}