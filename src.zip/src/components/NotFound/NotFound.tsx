import * as React from 'react';

class NotFound extends React.Component {
  render(): React.ReactNode {
    return (
      <div className='container-fluid'>
        <h1>Page not found</h1>
      </div>
    )
  }
}

export default NotFound;