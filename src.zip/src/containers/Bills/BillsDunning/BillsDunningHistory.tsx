import * as React from 'react';
import {Optional, DunningHistoryEntry} from '../../../model/types.d';
import {Button} from '../../../components/Form/Button/Button';
import I18n from '../../../utils/helper/I18n';

interface BillsDunningHistoryProps {
  dunningHistoryEntries: Optional<(Optional<DunningHistoryEntry>)[]>;
  handleClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
}
interface BillsDunningHistoryState {
  isPopup: boolean;
  level: string;
}

export class BillsDunningHistory extends React.Component<BillsDunningHistoryProps, BillsDunningHistoryState> {
  constructor(props: BillsDunningHistoryProps) {
    super(props);
    this.state = {isPopup: false, level: ''}
  }

  showHideTooltipPopup = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void => {
    const element: HTMLButtonElement = event.currentTarget as HTMLButtonElement;
    const {isPopup} = this.state;
    event.persist();
    this.setState({
      isPopup: !isPopup,
      level: element.id
    });
  }

  renderDunningCloseButton(): JSX.Element {
    const {handleClick} = this.props;
    return (
      <Button
        className='button extra_wide full_width_on_mobile transparent_background'
        label={I18n.translate('BillsDunning.OverlayDunningHistory.Button.Close')}
        handleClick={handleClick}
      />
    );
  };

  renderTooltip(): JSX.Element {
    const {level} = this.state;
    return (
      <React.Fragment>
        <div className='overlay'></div>
        <div className='popup__container'>
          <div className='popup'>
            <div className='popup-message-box popup-message-box--free-buttons'>
              <h1 className='title-large'>
              {I18n.translate(`BillsDunning.DunningLevel.${level}.DunningLevelTooltip.Title`)}
              </h1>
              <div className='vertical_spacer x16'></div>
              <div className='content-box screen-pane'>
                {I18n.translate(`BillsDunning.DunningLevel.${level}.DunningLevelTooltip.Text`)}
              </div>
              <div className='form-item'>
                <div className='form-item__button full_width_on_mobile'>
                  <Button
                    className='button extra_wide full_width_on_mobile transparent_background'
                    label={I18n.translate('BillsDunning.OverlayDunningHistory.Button.Close')}
                    handleClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.showHideTooltipPopup(e)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  renderDunningHistoryDetails(dunningHistoryEntry: Optional<DunningHistoryEntry>): JSX.Element | null {
    if (!dunningHistoryEntry || !dunningHistoryEntry.level) {
      return null;
    }
    return (
      <React.Fragment>
        <tr key={dunningHistoryEntry.level}>
          <td className='bills_dunning_history__column_2'>
            <div className='text-small slightly-bold grey-brown'>
              {dunningHistoryEntry.date}
            </div>
          </td>
          <td>
            <div className='text-small t-strong item-tooltip'>
              <div className='inline'>{I18n.translate(`BillsDunning.DunningLevel.${dunningHistoryEntry.level}.DunningLevelName`)}</div>
              <span className='tooltip' onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.showHideTooltipPopup(e)} id={`${dunningHistoryEntry.level}`}></span>
            </div>
            <div className='text-small slightly-bold grey-brown'>
              {I18n.translate(`BillsDunning.DunningLevel.${dunningHistoryEntry.level}.DunningLevelShortInfo`)}
            </div>
          </td>
        </tr>
      </React.Fragment>
    );
  }

  renderDunningHistory = (): JSX.Element => {
    const {dunningHistoryEntries} = this.props;
    const dunningHistory: Array<JSX.Element | null> = [];
    if (dunningHistoryEntries && dunningHistoryEntries.length > 0) {
      dunningHistoryEntries.sort((dunningDetail1: Optional<DunningHistoryEntry>, dunningDetail2: Optional<DunningHistoryEntry>) => {
        const dunningDetail1Date: any = new Date(dunningDetail1 && dunningDetail1.date);
        const dunningDetail2Date: any = new Date(dunningDetail2 && dunningDetail2.date);
        return dunningDetail2Date - dunningDetail1Date;
      });
      dunningHistoryEntries.forEach((dunningHistoryEntry: Optional<DunningHistoryEntry>) => {
        dunningHistory.push(this.renderDunningHistoryDetails(dunningHistoryEntry));
      });
    }
    return (
      <table className='bills_dunning_history'>
        <tbody>
          <tr>
            <td className='bills_dunning_history__column_1'>
              <div className='form__label form__label--highlighted no-bottom-margin'>
                {I18n.translate('BillsDunning.OverlayDunningHistory.Label.Date')}
              </div>
            </td>
            <td>
              <div className='form__label form__label--highlighted no-bottom-margin'>
                {I18n.translate('BillsDunning.OverlayDunningHistory.Label.Details')}
              </div>
            </td>
          </tr>
          {dunningHistory}
        </tbody>
      </table>
    );
  }

  render(): React.ReactNode {
    const {isPopup} = this.state;
    return (
      <React.Fragment>
        <div className='overlay'></div>
        <div className='popup__container'>
          {isPopup ? this.renderTooltip() : null}
          <div className='popup'>
            <div className='popup-message-box popup-message-box--free-buttons'>
              <h1 className='title-large'>
                {I18n.translate('BillsDunning.OverlayDunningHistory.Label.HeadingTitle')}
              </h1>
              <div className='vertical_spacer x8'></div>
              <div className='l-col l-1of1 l-1of1-mobile'>
                <div className='content-box screen-pane'>
                  {this.renderDunningHistory()}
                </div>
              </div>
              <div className='vertical_spacer x8'></div>
              <div className='form-item'>
                <div className='form-item__button full_width_on_mobile'>
                  {this.renderDunningCloseButton()}
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}