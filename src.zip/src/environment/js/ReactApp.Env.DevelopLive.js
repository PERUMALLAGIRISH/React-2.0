
(function() {

	/**
	 *
	 * ENVIRONMENT Local Live
	 *
	 */

  ReactApp.Env.urlShop = 'https://www-t04.sunrise.ch';
	ReactApp.Env.urlShopApi = ReactApp.Env.urlShop + '/sunrisecommercewebservices/v2/web';
	ReactApp.Env.urlGql = 'https://t3-digi-as-01:10443/graphql';
	ReactApp.Env.urlProfile = ReactApp.Env.urlShop + 'mysunrise/en/residential/profile.html#/';
	ReactApp.Env.urlHybris = 'https://t1-wwwhyb-as-01.swi.srse.net/sunrisecommercewebservices/v2/web/';


}());
