import * as React from 'react';
import {Button} from '../../../../components/Form/Button/Button';
import {Loader} from '../../../../components/Loader/Loader';
import I18n from '../../../../utils/helper/I18n';

interface PaymentStatusProps {
  text: string;
  onClick(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void;
}

interface PaymentStatusState {
}

class PaymentStatus extends React.Component<PaymentStatusProps, PaymentStatusState> {
  constructor(props: PaymentStatusProps) {
    super(props);
  }

  renderLoading(): JSX.Element {
    return (
      <React.Fragment>
        <div className='overlay overlay--darker'></div>
        <div className='popup__container'>
          <div className='popup'>
            <Loader />
          </div>
        </div>
      </React.Fragment>
    );
  }

  renderPaymentSection(text: string): JSX.Element {
    const {onClick} = this.props;
    return (
      <React.Fragment>
        <div className='overlay overlay--darker'></div>
        <div className='popup__container'>
          <div className='popup'>
            <div className='popup-message-box'>
              <div>
                <img src='../../img/new/overall_success_mail.png' />
                <div className='title-middle--grey font-s-24px t-bold--mobile text-width-20rem'>
                  {text}
                 </div>
                <div className='vertical_spacer x16'></div>
                <div className='centered-text'>
                  <Button
                    className = {'button extra_wide'}
                    handleClick = {onClick}
                    label = {I18n.translate('Payment.Ok.Button.Label')}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  render(): React.ReactNode {
    const {text} = this.props;

    if (!text) {
      return this.renderLoading();
    }
    return (
      <React.Fragment>
        {this.renderPaymentSection(text)}
      </React.Fragment>
    )
  }
}

export default PaymentStatus;