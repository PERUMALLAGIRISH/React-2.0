import React, { Component } from 'react';
import axios from 'axios';

class Home extends Component {
        state = {
             Lists : []
        }
    
    componentDidMount(){
        axios.get(`http://localhost:5000/products`)
        .then( res =>  
            //console.log(res)
            this.setState({Lists : res.data})
        )
    }

    render() {
        return (
            <div>
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                </tr>
                </thead>
                <tbody>
                {this.state.Lists.map(List => (
                <tr key={List.id}>
                    <td>{List.id}</td>
                    <td>{List.name}</td>
                    <td>{List.description}</td>
                    <td>{List.price}</td>
                </tr>
                ))}
                </tbody>
            </table>
                    
                
                    
                

                <button className="btn btn-primary">Click Me</button>
            </div>
        )
    }
}

export default Home
