import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const setBillAnonymizationLevelMutation: DocumentNode = gql`
  mutation setBillAnonymizationLevel($input: BillAnonymizationLevelInput!) {
    setBillAnonymizationLevel(input: $input) {
      payloadStatus
    }
  }
`;

export default setBillAnonymizationLevelMutation;