export interface RegisteredCard {
  aliasCc: string;
  expiryMonth: string;
  expiryYear: string;
  number: string;
  paymentCard: PaymentCard;
}

export enum PaymentCard {
  ECA = 'ECA',
  VIS = 'VIS',
  AMX = 'AMX',
  PEF = 'PEF',
  PFC = 'PFC'
}
