/**
 * GraphQL contains GraphQL related methods
 */

import {Map} from './Map';
import ApolloClient from 'apollo-boost';
declare let window: any;

const client: ApolloClient<{}> = new ApolloClient({
  uri: window.ReactApp.Env.urlGql
});
client.defaultOptions = {
  watchQuery: {
    fetchPolicy: 'no-cache',
    errorPolicy: 'all'
  },
  query: {
    fetchPolicy: 'no-cache',
    errorPolicy: 'all'
  }
};

const GraphQL: Map<any> = {
  getNetworkClient: client,
  query: (queryObj: any, successCallback: ((response: {}) => void), errorCallback: ((error: Error) => void)) => {
    client.query(queryObj).then((response: any) => {
      if (response.data) {
        successCallback(response.data);
      } else {
        errorCallback(response.error);
      }
    }).catch((error: any) => {
      try {
        if (error && error.networkError && error.networkError.statusCode === 403 || error.networkError.statusCode === 401 ) {
          errorCallback(error);
        } else {
          errorCallback(error);
        }
      } catch {
        errorCallback(error);
      }
    });
  },
  mutation: (mutationObj: any, successCallback: ((response: {}) => void), errorCallback: ((error: Error) => void)) => {
    client.mutate(mutationObj)
    .then((response: any) => {
      if (response.data) {
        successCallback(response.data);
      } else {
        errorCallback(response.error);
      }
    }).catch((error: any) => {
      try {
        if (error && error.networkError && error.networkError.statusCode === 403 || error.networkError.statusCode === 401) {
          errorCallback(error);
        }
      } catch {
        errorCallback(error);
      }
    });
  }
};
export default GraphQL;
