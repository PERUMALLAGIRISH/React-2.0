import * as React from 'react';

export interface Props {
  id: string;
  name: string;
  label?: string;
  htmlFor?: string;
  className?: string;
  value?: string;
  disabled?: boolean;
  checked?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const Radio: React.StatelessComponent<Props> = (props) => {
  return (
    <React.Fragment>
      <input id={props.id}
        name={props.name}
        value={props.value}
        disabled= {props.disabled}
        onChange= {props.onChange}
        checked= {props.checked}
        type='radio'
      />
      { props.label !== undefined ?
        <label className='form_radio_label' htmlFor={props.htmlFor}>
        <span id={props.id} className={props.className} onClick={props.onClick}>{props.label}</span>
        </label> : ''
      }
    </React.Fragment>
  );
};
