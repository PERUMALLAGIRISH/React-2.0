import * as React from 'react';
import {BillsDue} from './BillsDue/BillsDue';
import {BillsPaid} from './BillsPaid/BillsPaid';
import {fetchBillsInfo, setOrderBillCopy, orderAccountStatementRequest, resetBills, resetOrderAccountStatement, resetOrderBillCopy, sendBillsDeblockActivate, sendBillsPayLater} from './BillsAction';
import {Account, RegisteredCard, PaymentMethodOption, DunningInfo, BillInfo, DunningHistoryEntry, Bill, Address, Subscriber, Optional, BillSettings, BillDeliveryNotification, BillDeliveryMethod, BillAnonymizationLevel, PaymentMethodType, PayloadStatus, OrderAccountStatementPayload, DeleteRegisteredCardInput, DeleteRegisteredCardPayload, PaymentInput, PaymentPayload, OrderBillCopyPayload, RequestDunningDeblockOnTrustPayLoad, RequestDunningJokerPayLoad} from '../../model/types.d';
import {BillsOrderAccountStatement} from './BillsOrderAccountStatement/BillsOrderAccountStatement';
import {BillsDunning} from './BillsDunning/BillsDunning';
import {BillsDunningHistory} from './BillsDunning/BillsDunningHistory';
import {Dispatch, ActionCreatorsMapObject, bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {DataList} from '../../components/DataList/DataList';
import {BillsPayLater}  from '../Bills/BillsPayLater/BillsPayLater';
import {BillsDeblock} from '../Bills/BillsDeblock/BillsDeblock';
import {Button} from '../../components/Form/Button/Button';
import {EnvDevelop} from '../../environment/EnvDevelop';
import DateService from '../../utils/DateService';
import {deleteRegisteredCardReset, deleteRegisteredCardRequest} from './RegisteredCard/RegisteredCardAction';
import ReplaceOrDeleteRegisteredCard from './RegisteredCard/ReplaceOrDeleteRegisteredCard';
import {fetchPaymentState, makePaymentRequest, makePaymentReset} from '../Bills/Payment/PaymentAction';
import {registeredCardService} from './RegisteredCard/RegisteredCardService';
import {PaymentState} from '../../model/client/PaymentState';
import {paymentService} from './Payment/PaymentService';
import PaymentGateway from './Payment/PaymentGateway';
import PaymentStatus from './Payment/PaymentStatus/PaymentStatus';
import caseChange from 'change-case';
import {Link} from 'react-router-dom';
import CurrencyFormatService  from '../../utils/CurrencyFormatService';
import I18n from '../../utils/helper/I18n';
import {BillsConstants} from './BillsConstants';
import {BillsRoutes} from './BillsRoutes.enum';
import {History, Location} from 'history';
import {Loader} from '../../components/Loader/Loader';
declare let window: any;

export interface BillsProps {
  account: Account;
  accountError: Error;
  orderAccountStatementPayload: OrderAccountStatementPayload;
  orderAccountStatementPayloadError: Error;
  fetchBillsInfo: () => void;
  setOrderBillCopy: () => void;
  location: Location;
  history: History;
  imgOverallSuccessMail?: string;
  imgPaid?: string;
  imgOverdue?: string;
  orderAccountStatementRequest: () => void;
  resetBills: () => void;
  sendBillsPayLater: () => void;
  sendBillsDeblockActivate: () => void;
  deleteRegisteredCardRequest: (input: DeleteRegisteredCardInput) => void;
  deleteRegisteredCard: DeleteRegisteredCardPayload | null;
  deleteRegisteredCardError: Error | null;
  deleteRegisteredCardReset: () => void;
  fetchPaymentState: (amount: number) => void;
  paymentState: PaymentState;
  makePaymentRequest: (paymentInput: PaymentInput) => void;
  makePaymentReset: () => void;
  makePayment: PaymentPayload | null;
  makePaymentError: Error | null;
  match: any;
  resetOrderAccountStatement: () => void;
  orderBillCopyPayload: OrderBillCopyPayload;
  orderBillCopyPayloadError: Error | null;
  resetOrderBillCopy: () => void;
  requestDunningDeblockOnTrustPayLoad?: RequestDunningDeblockOnTrustPayLoad;
  requestDunningDeblockOnTrustPayLoadError?: Error | null;
  requestDunningJokerPayLoad?: RequestDunningJokerPayLoad;
  requestDunningJokerPayLoadError?: null;
}

interface BillsState {
  isLoading: boolean;
  showLastPaid: boolean;
  isPopup: boolean;
  isAccountStatementPopup: boolean;
  accountStatementValue: string;
  isButtonDisabled: boolean;
  isChecked: string;
  isDunningPopup: boolean;
  isPayLaterPopup: boolean;
  isDeblockPopup: boolean;
  invokePayment: boolean;
  overlay: string;
  registerCardStep: number;
}

class Bills extends React.Component<BillsProps, BillsState> {
  constructor(props: BillsProps) {
    super(props);
    this.state = {
      isLoading: true,
      showLastPaid: false,
      isPopup: false,
      isAccountStatementPopup: false,
      accountStatementValue: '',
      isButtonDisabled: true,
      isChecked: '',
      isDunningPopup: false,
      isPayLaterPopup: false,
      isDeblockPopup: false,
      overlay: '',
      registerCardStep: 0,
      invokePayment: false
    }
    this.windowEventHandler = this.windowEventHandler.bind(this);
  }

  static getDerivedStateFromProps(nextProps: BillsProps, prevState: BillsState): any | null {

    if (nextProps.deleteRegisteredCard && nextProps.deleteRegisteredCard.payloadStatus === PayloadStatus.OK && prevState.registerCardStep === 2) {
      nextProps.fetchBillsInfo();
      return {
        registerCardStep: 3
      };
    }

    if ((nextProps.account || nextProps.accountError) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  componentDidMount(): void {
    const {fetchBillsInfo, fetchPaymentState, makePaymentRequest, paymentState} = this.props;
    window.addEventListener('keyup', (event: KeyboardEvent) => this.windowEventHandler(event));
    fetchBillsInfo();

    if (!paymentState) {
      fetchPaymentState(BillsConstants.REGISTER_CARD_AMOUNT);
    }

    const paymentParams: any = paymentService.getPaymentParams(window.location.hash.substring(3));

    if (Object.keys(paymentParams).length > 0 && paymentParams.status === BillsConstants.SUCCESS) {
      this.overlayListener(BillsConstants.PAYMENTSTATUS);
      makePaymentRequest(paymentService.getPaymentInput(paymentParams, PaymentMethodOption.CREDIT_CARD));
    } else if (Object.keys(paymentParams).length > 0 && (paymentParams.status === BillsConstants.ERROR)) {
      this.overlayListener(BillsConstants.PAYMENTERROR);
    } else {
      this.overlayListener();
    }

  }

  componentWillUnmount(): void {
    window.removeEventListener('keyup', (event: KeyboardEvent) => this.windowEventHandler(event));
  }

  overlayListener = (overlayId?: string): void => {
    const {match, history} = this.props;
    if (match && match.params && Object.keys(match.params).length > 0 && match.params.overlay && match.params.overlay !== '') {
      this.setState({
        overlay: overlayId ? overlayId : match.params.overlay
      });
    } else if (overlayId && overlayId !== '' && history) {
      history.push(`/${overlayId}`);
      this.setState({
        overlay: overlayId
      });
    }
  }

  closeOverlay = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void => {
    const {history} = this.props;
    if (history) {
      history.push(BillsRoutes.BILLS_HOME);
    }
    this.setState({
      overlay: '',
      registerCardStep: 0
    });
  }

  renderPaymentSuccessOrError = (): string => {
    const {makePayment, makePaymentError} = this.props;
    if (makePayment && makePayment.payloadStatus && makePayment.payloadStatus === PayloadStatus.OK) {
      return I18n.translate('Bills.Payment.Success.Text');
    } else if ((makePayment && makePayment.payloadStatus && makePayment.payloadStatus === PayloadStatus.NOK) ||
    (makePaymentError && makePaymentError !== null)) {
      return I18n.translate('Bills.Payment.Error.Text');
    }
    return '';
  }

  renderOverlay = (): JSX.Element | null => {
    const {overlay, registerCardStep} = this.state;
    const {deleteRegisteredCard, deleteRegisteredCardError} = this.props;

    switch (overlay) {
      case BillsConstants.PAYMENTSTATUS:
        return (
          <PaymentStatus
            text = {this.renderPaymentSuccessOrError()}
            onClick = {this.closeOverlay}
          />
        );
      case BillsConstants.PAYMENTERROR:
        return (
          <PaymentStatus
            text = {I18n.translate('Bills.Payment.Error.Message')}
            onClick = {this.closeOverlay}
          />
        );
      case BillsConstants.PAYMENT_GATEWAY_ERROR:
        return (
          <PaymentStatus
            text = {I18n.translate('Bills.Payment.GateWayError.Message')}
            onClick = {this.closeOverlay}
          />
        );
      case BillsConstants.MANAGE_CREDITCARD:
        return (
          <ReplaceOrDeleteRegisteredCard
            registeredCard = {this.getRegisteredCard()}
            step = {registerCardStep}
            onClickCancel = {this.closeOverlay}
            handleConfirmDeleteRegisteredCardClick = {this.handleConfirmDeleteRegisteredCardClick}
            handleReplaceRegisteredCardClick = {this.handleReplaceRegisteredCardClick}
            handleDeleteRegisteredCardClick = {this.handleDeleteRegisteredCardClick}
            deleteRegisteredCard = {deleteRegisteredCard}
            deleteRegisteredCardError = {deleteRegisteredCardError}
            deleteRegisteredCardReset = {deleteRegisteredCardReset}
          />
        );
      default:
        return null;
    }
  }

  getRegisteredCard = (): Optional<RegisteredCard> => {
    const {account} = this.props;
    if (account &&
      account.billInfo &&
      account.billInfo.registeredCards &&
      account.billInfo.registeredCards.length > 0) {
      return account.billInfo.registeredCards[0]!;
    }
  }

  handleReplaceRegisteredCardClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    this.setState({
      invokePayment : true,
      overlay: '',
      registerCardStep: 0
    });
  }

  handleDeleteRegisteredCardClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    this.setState({
      registerCardStep: 1
    });
  }

  handleConfirmDeleteRegisteredCardClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {deleteRegisteredCardRequest} = this.props;
    this.setState({
      registerCardStep: 2
    });
    const registeredCard: Optional<RegisteredCard> = this.getRegisteredCard();
    if (registeredCard) {
      deleteRegisteredCardRequest(registeredCardService.getDeleteRegisteredCardInput(registeredCard));
    }
  }

  handleReplaceOrDeleteRegisteredCardOverlay = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    return this.overlayListener(BillsConstants.MANAGE_CREDITCARD);
  }

  handleOpenRegisterCardOverlay = (event: React.MouseEvent<HTMLButtonElement>) => {
    this.setState({
      invokePayment : true
    });
  }

  handleScriptError = () => {
    return this.overlayListener(BillsConstants.PAYMENT_GATEWAY_ERROR);
  }

  renderExpiredRegisteredCardText(): JSX.Element {
    return (
      <div className='content-box content_box--padding-x24-y24'>
        <div className='p-flexbox is-justified--start'>
          <img className='icon-image' src='/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/error.svg' />
          <div className='text-s-14px red-error t-bold padding-l-12'>
            {I18n.translate('Bills.ExpiredRegisteredCard.Expired.Note')}
          </div>
        </div>
        <div className='vertical_spacer x16'></div>
          <div className='text-s-12px t-w-500 grey-brown'>
            {I18n.translate('Bills.ExpiredRegisteredCard.Expired.Message')}
          </div>
          <div className='vertical_spacer x8'></div>
      </div>
    );
  }

  renderRegisterCardSection = (): JSX.Element => {
    const registeredCard: Optional<RegisteredCard> = this.getRegisteredCard();
    let isCardRegistered: boolean = false;
    let paymentCard: string = '';
    let cardNumber: string = '';
    let expiryMonth: number = 0;
    let expiryYear: number = 0;

    if (registeredCard) {
      isCardRegistered = true;
      paymentCard = registeredCard.paymentCard ? I18n.translate(`Global.${registeredCard.paymentCard.toUpperCase()}`) : '';
      cardNumber = registeredCard.number ? registeredCard.number : '';
      expiryMonth = Number(registeredCard.expiryMonth);
      expiryYear = Number(registeredCard.expiryYear);
    }
    return (
      <div className='content-box bigger_vertical_padding'>
      {registeredCardService.isExpired(expiryMonth, expiryYear) ? this.renderExpiredRegisteredCardText() : null}
      <div className='form'>
        <div className='form-item--flexbox'>
          <div>
            <div className='form__label'>{I18n.translate('Bills.RegisterCard.Card.Title')}</div>
            <div className='form__text'>{(isCardRegistered && paymentCard !== '' && cardNumber !== '') ? `${paymentCard} ${cardNumber}` : I18n.translate('Bills.RegisterCard.AddCard.Text')}</div>
          </div>
            <div className='form-item__button'>
              <Button
                className = {'button'}
                handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => isCardRegistered ? this.handleReplaceOrDeleteRegisteredCardOverlay(e) : this.handleOpenRegisterCardOverlay(e)}
                label = {isCardRegistered ? I18n.translate('Bills.RegisterCard.Edit.Label') : I18n.translate('Bills.RegisterCard.AddCard.Label')}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  getBillDeliveryMethodText(billDeliveryMethod: Optional<BillDeliveryMethod>): string {
    switch (billDeliveryMethod) {
      case BillDeliveryMethod.EMAIL_WITH_LINK: return I18n.translate('Bills.DeliveryMethod.EmailLink.Title');
      case BillDeliveryMethod.EMAIL_WITH_BILL_IN_PDF_FORMAT: return I18n.translate('Bills.DeliveryMethod.EmailPdf.Title');
      case BillDeliveryMethod.PAPER_BILL_WITHOUT_CALL_DETAILS: return I18n.translate('Bills.DeliveryMethod.PaperBill.Text');
      case BillDeliveryMethod.PAPER_BILL_WITH_CALL_DETAILS: return I18n.translate('Bills.DeliveryMethod.PaperBillWith.Text');
      default: return '';
    }
  }

  getBillAnonymizationLevel(billAnonymizationLevel: Optional<BillAnonymizationLevel>): string {
    switch (billAnonymizationLevel) {
      case BillAnonymizationLevel.NONE: return I18n.translate('Bills.AnonymizationLevel.DisplayNumberNone.Title');
      case BillAnonymizationLevel.LAST_2_DIGITS: return I18n.translate('Bills.AnonymizationLevel.DisplayNumberOption2.Text');
      case BillAnonymizationLevel.LAST_4_DIGITS: I18n.translate('Bills.AnonymizationLevel.DisplayNumberOption4.Text');
      default: return '';
    }
  }

  renderDeliveryFormatChange = (): JSX.Element | null => {
    const {account} = this.props;
    if (account) {
      const billInfo: Optional<BillInfo> = account.billInfo;
      const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
      const billAnonymizationLevel: Optional<BillAnonymizationLevel> = billSettings && billSettings.billAnonymizationLevel;
      const billDeliveryMethod: Optional<BillDeliveryMethod> = billSettings && billSettings.billDeliveryMethod;
      const billDeliveryNotification: Optional<BillDeliveryNotification> = billSettings && billSettings.billDeliveryNotification;
      const billDeliveryNotificationContactNumbers: Optional<(Optional<string>)[]> = billDeliveryNotification && billDeliveryNotification.contactNumbers;
      return (
        <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
          <div className='content-box bigger_vertical_padding'>
            <div className='form__flexbox--column'>
              <div className='form-item'>
                <div className='form__label'>
                  {I18n.translate('Bills.DeliveryFormat.ShippingMethod.Label')}
                </div>
                <div className='form__text'>
                {this.getBillDeliveryMethodText(billDeliveryMethod)}
              </div>
            </div>
              <div className='form-item'>
                <div className='form__label'>
                  {I18n.translate('Bills.DeliveryFormat.SMSNotification.Text')}
                </div>
                <div className='form__text'>
                  {billDeliveryNotificationContactNumbers && billDeliveryNotificationContactNumbers.length ? I18n.translate('Bills.DeliveryFormat.Active.Text') : I18n.translate('Bills.DeliveryFormat.InActive.Text')}
                </div>
              </div>
              <div className='form-item'>
                <div className='form__label'>
                  {I18n.translate('Bills.DeliveryFormat.DeliveryMethod.Format')}
                </div>
                <div className='form__text'>
                  {billDeliveryMethod === BillDeliveryMethod.PAPER_BILL_WITHOUT_CALL_DETAILS ? I18n.translate('Bills.DeliveryFormat.WithoutCall.Details.Text') : I18n.translate('Bills.DeliveryFormat.Call.Details.Text')}
                </div>
              </div>
              <div className='form-item--flexbox'>
                <div>
                  <div className='form__label'>
                    {I18n.translate('Bills.DeliveryFormat.DisplayNumber.Title')}
                  </div>
                  <div className='form__text'>
                    {this.getBillAnonymizationLevel(billAnonymizationLevel)}
                  </div>
                </div>
                <div className='form-item__button button__glue_to_content_box_b_40'>
                  <Link to= {{
                    pathname: BillsRoutes.BILLS_DELIVERY,
                    state: account
                  }}><button className='button'>{I18n.translate('Bills.DeliveryFormat.Edit.Button.Label')}</button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
      </div>);
    }
    return null;
  }

  windowEventHandler = (event: KeyboardEvent) => {
    const {overlay} = this.state;
    const {history} = this.props;
    if ((event.code === 'Escape' || event.key === 'Escape' || event.keyCode === 27) && overlay !== '') {
      history.push(BillsRoutes.BILLS_HOME);
      this.setState({
        overlay: ''
      });
    }
  }

  handleBacktoProfile(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    window.location.href = window.ReactApp.Env.urlProfile;
  }

  onCancelled = () => {
    this.setState({
      invokePayment: false
    });
  }

  getRedirectUrls(): object {
    return {
      successUrl: window.location.href,
      errorUrl: window.location.href,
      cancelUrl: window.location.href
    };
  }

  getPaymentObject(paymentState: PaymentState): any {
    return paymentService.getPaymentObject(PaymentMethodOption.CREDIT_CARD, paymentState, this.getRedirectUrls(), true, BillsConstants.REGISTER_CARD_AMOUNT * 100);
  }

  /* Handle open and close popup for Paylater option */
  displayPayLater = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {isPayLaterPopup} = this.state;
    event.preventDefault();
    this.setState({
      isPayLaterPopup: !isPayLaterPopup
    });
  }
  /* Handle open and close popup for Deblock enable option */
  displayDeblockEnable = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {isDeblockPopup} = this.state;
    event.preventDefault();
    this.setState({
        isDeblockPopup: !isDeblockPopup
    });
  }
  /* rendering Paylater button based on billsInfo respone dunningJokerEligibility = true */
  renderPayLaterOption(): JSX.Element {
    return (
      <div className='l-flexbox-row'>
        <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
          <div className='content-box'>
            <h2 className='title-large text-left text-pad-r-40perc'>
              {I18n.translate('Bills.PayLaterOption.PayLater.Title')}
            </h2>
            <div className='text-small grey-brown'>
              {I18n.translate('Bills.PayLaterOption.PayLater.Text')}
            </div>
            <div className='float'>
              <Button
                className= 'button cta-button dark_grey_text extra_wide float_right--mobile'
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.displayPayLater(e)}
                label = {I18n.translate('Bills.PayLaterOption.PayLater.Button.Label')}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
  /* rendering Deblock button based on billsInfo respone eligibileForDeblocking = true */
  renderDeblockEnableOption(): JSX.Element {
    return (
      <div className='l-col l-1of1 l-1of1-mobile'>
        <div className='content-box small-content_box--small-spacing small_content_box'>
          <div className='form form__form-info-variant-2'>
            <div className='form__label form__label--large form__label--highlighted text-left--soft'>{I18n.translate('Bills.Deblock.DeBlockEnable.Title')}</div>
            <div className='form-item content-box--flexbox flex-align-items-flex-end'>
              <div className='form__text text-small text-left--soft'>{I18n.translate('Bills.Deblock.DeBlockEnable.Text')}</div>
              <Button
                className= 'button button__no-responsive-arrow'
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.displayDeblockEnable(e)}
                label = {I18n.translate('Bills.Deblock.DeBlockEnable.Button.Label')}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
  /* rendering BillsPayLater component while isPayLaterPopup = true */
  renderPayLaterPopup(): JSX.Element {
    const {sendBillsPayLater, requestDunningJokerPayLoad, requestDunningJokerPayLoadError} = this.props;
    return (
      <BillsPayLater
        sendBillsPayLater = {sendBillsPayLater}
        handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.displayPayLater(e)}
        requestDunningJokerPayLoad = {requestDunningJokerPayLoad}
        requestDunningJokerPayLoadError = {requestDunningJokerPayLoadError} />
      );
  }
  /* rendering BillsDeblock component while isDeblockPopup = true */
  renderDeblockPopup(): JSX.Element {
    const {sendBillsDeblockActivate, requestDunningDeblockOnTrustPayLoad, requestDunningDeblockOnTrustPayLoadError} = this.props;
    return (
      <BillsDeblock
        sendBillsDeblockActivate = {sendBillsDeblockActivate}
        handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.displayDeblockEnable(e)}
        requestDunningDeblockOnTrustPayLoad = {requestDunningDeblockOnTrustPayLoad}
        requestDunningDeblockOnTrustPayLoadError = {requestDunningDeblockOnTrustPayLoadError} />
    );
  }
  showMoreLess(event: React.MouseEvent<HTMLButtonElement>): void {
    const {showLastPaid} = this.state;
    event.preventDefault();
    this.setState({
      showLastPaid: !showLastPaid
    });
  }

  renderLastPaidSection(): JSX.Element {
    const {showLastPaid} = this.state;
    return (
      <div className='l-col l-1of2 l-1of1-mobile'>
        <div className='content-box content-box--icon__last-paid-bills no-bottom-margin'>
          <div className='vertical_spacer x16'></div>
          <div className='title-extra-large t-strong'>
           {I18n.translate('Bills.LastPaid.PaidBills.Text')}
          </div>
          <div className='vertical_spacer x16'></div>
          <Button
            className= 'button cta-button dark_grey_text'
            handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.showMoreLess(e)}
            label = {showLastPaid ? I18n.translate('Bills.LastPaid.ShowLess.Text') : I18n.translate('Bills.LastPaid.ShowMore.Text') }
          />
        </div>
      </div>
    );
  }

  renderBillsPaid(paidBill: Optional<Bill>): JSX.Element | null {
    if (!paidBill) {
      return null;
    }
    const {setOrderBillCopy, orderBillCopyPayload, orderBillCopyPayloadError, resetOrderBillCopy, imgPaid} = this.props;
    const downloadUrl: string = `${EnvDevelop.urlShopApi}sunrisecommercewebservices/v2/web/users/current/site/billingprofile/lsv`;
    const billDate: string = DateService.formatDate(paidBill.billDate);
    return (
      <BillsPaid
        id= {paidBill.id ? paidBill.id : ''}
        billDate= {billDate}
        amount= {paidBill.amount ? paidBill.amount : 0}
        downloadUrl= {downloadUrl}
        digitalInvoiceUrl= {paidBill.digitalInvoiceUrl ? paidBill.digitalInvoiceUrl.replace('{host}/', EnvDevelop.urlShopApi) : ''}
        setOrderBillCopy = {setOrderBillCopy}
        orderBillCopyPayload = {orderBillCopyPayload}
        orderBillCopyPayloadError = {orderBillCopyPayloadError}
        resetOrderBillCopy = {resetOrderBillCopy}
        imgPaid = {imgPaid}
      />
    );
  }

  renderLastPaidBills(paidBills: Optional<(Optional<Bill>)[]>): JSX.Element[] | null {
    if (!paidBills) {
      return null;
    }
    const dueBillsSection: JSX.Element[] = [];
    for (let i: number = 0; i < paidBills.length; i = i + 2) {
      dueBillsSection.push(
        <div key={i}>
          {this.renderBillsPaid(paidBills[i])}
          {paidBills[i + 1] ? this.renderBillsPaid(paidBills[i + 1]) : null}
        </div>);
    }
    return dueBillsSection;
  }

  renderBillDue(dueBill: Optional<Bill>, billOrder: number): JSX.Element | null {
    if (!dueBill) {
      return null;
    }
    const {imgOverdue, setOrderBillCopy, orderBillCopyPayload, orderBillCopyPayloadError, resetOrderBillCopy} = this.props;
    const downloadUrl: string = `${EnvDevelop.urlShopApi}sunrisecommercewebservices/v2/web/users/current/site/billingprofile/lsv`;
    const billDate: string = DateService.formatDate(dueBill.billDate);
    const dueOn: string = DateService.formatDate(dueBill.dueOn);
    return (
      <BillsDue
        id= {dueBill.id ? dueBill.id : ''}
        billDate= {billDate}
        dueOn= {dueOn}
        openAmount= {dueBill.openAmount ? dueBill.openAmount : 0}
        status= {dueBill.status ? dueBill.status : ''}
        imgOverdue= {imgOverdue}
        digitalInvoiceUrl= {dueBill.digitalInvoiceUrl ? dueBill.digitalInvoiceUrl.replace('{host}/', EnvDevelop.urlShopApi) : ''}
        downloadUrl= {downloadUrl}
        isPayButton = {billOrder === 1 ? true : false}
        setOrderBillCopy = {setOrderBillCopy}
        orderBillCopyPayload = {orderBillCopyPayload}
        orderBillCopyPayloadError = {orderBillCopyPayloadError}
        documentType = {dueBill.documentType ? dueBill.documentType : ''}
        resetOrderBillCopy = {resetOrderBillCopy}
        isOverdue = {dueBill.status === BillsConstants.OVERDUE || dueBill.status === BillsConstants.DUNNED}
        handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.handlebillsDueClick(e)}
      />);
  }

  renderDueBillsHeading(dueBills: Optional<(Optional<Bill>)[]>): JSX.Element | null {
    if (dueBills && dueBills.length > 0) {
      return (
        <div className='l-col l-1of1 l-1of1-mobile'>
          <h2 className='title-large centered-text'>
            {dueBills.length === 1 ? I18n.translate('Bills.DueBills.OverDueBill.Text') : I18n.translate('Bills.DueBills.OpenBill.Text') }
          </h2>
          <div className='text-larger grey-brown centered-text'>
          {dueBills.length === 1 ? I18n.translate('Bills.DueBills.PayBill.Text') : I18n.translate('Bills.DueBills.MissedBill.Text') }
          </div>
        </div>
      )
    }
    return null;
  }

  renderDueBills(dueBills: Optional<(Optional<Bill>)[]>): JSX.Element[] | null {
    if (!dueBills) {
      return null;
    }
    const dueBillsSection: JSX.Element[] = [];
    const className: string = dueBills.length > 1 ? 'l-flexbox-row double_vertical_gutter' : 'l-flexbox-row no-bottom-margin';
    for (let i: number = 0; i < dueBills.length; i = i + 2) {
      dueBillsSection.push(
        <div className={className} key={i}>
          {this.renderBillDue(dueBills[i], dueBills.length)}
          {dueBills[i + 1] ? this.renderBillDue(dueBills[i + 1], dueBills.length) : null}
          {dueBills.length === 1 ? this.renderBillAssistant() : null}
        </div>);
    }
    return dueBillsSection;
  }

  renderBillsDunningTable = (overdueAmount: Optional<number>, outstandingAmount: Optional<number>): JSX.Element => {
    return(
      <div className='bills_dunning_table'>
        <table>
          <tbody>
            <tr>
              <td className='bills_1st_table_column'>
                <div className='text-small t-strong very-light-pink'>
                  {I18n.translate('Bills.Dunning.DunningAmount.Title')}
                </div>
              </td>
              <td>
                <div className='title-middle very-light-pink'>
                  {overdueAmount ? CurrencyFormatService.getCurrencyFormat(overdueAmount) : ''}
                </div>
              </td>
            </tr>
            <tr>
              <td className='bills_1st_table_column'>
                <div className='text-small t-strong very-light-pink'>
                  {I18n.translate('Bills.Dunning.OutstandingAmount.Title')}
                </div>
              </td>
              <td>
                <div className='title-middle very-light-pink'>
                  {outstandingAmount ? CurrencyFormatService.getCurrencyFormat(outstandingAmount) : ''}
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }

  renderOutstandingSection = (totalOutstandingAmount: Optional<number>, length: number, overdueAmount: Optional<number>, outstandingAmount: Optional<number>): JSX.Element => {
    return (
      <React.Fragment>
        {length > 1 ? <div className='l-col l-1of1 l-1of1-mobile'>
          <div className='content-box grey-top-border no-bottom-margin'>
            <div className='centered-text vert-centered-text'>
              {(overdueAmount && outstandingAmount) ? this.renderBillsDunningTable(overdueAmount, outstandingAmount) : null}
              <br className='is-hidden-940px' />
              <div className='text-small t-strong inline no-bottom-margin bills_text_next_to_table bills_text_next_to_table_desc'>
                {I18n.translate('Bills.OutStanding.TotalAmount.Text')}:
              </div>
              <div className='outstanding_bill__large_number inline bills_text_next_to_table bills_text_next_to_table_number'>
                {totalOutstandingAmount ? CurrencyFormatService.getCurrencyFormat(totalOutstandingAmount) : '' }
              </div>
              <div className='vertical_spacer x8 is-hidden-desktop'></div>
              {length !== 1 ? <div className='centered-text is-hidden-desktop'>
                <Button
                  handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handlebillsDueClick(e)}
                  label = {I18n.translate('Bills.OutStanding.PayNow.Label')}
                  className = 'button button--flex button--large full_width_on_mobile half_width ok_color'
                />
              </div> : null}
            </div>
          </div>
        </div> : null}
        <div className='l-col l-1of1 l-1of1-mobile'>
          <div className='text-extra-small text-right t-strong-slight pinkish-grey'>
            {I18n.translate('Bills.OutStanding.Vat.Text')}
          </div>
          {length > 1 ? <div className='centered-text is-hidden-mobile'>
            <Button
              handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handlebillsDueClick(e)}
              label = {I18n.translate('Bills.OutStanding.PayNow.Label')}
              className = 'bills_pull_sales_button_up button button--large full_width_on_mobile half_width ok_color'
            />
          </div> : null}
        </div>
      </React.Fragment>
      );
  }

  renderNoDueBills(): JSX.Element {
    const {imgOverallSuccessMail} = this.props;
    return (
      <div className='content-box content-box--flexbox bigger_horizontal_padding'>
        <img src={imgOverallSuccessMail || ''}/>
        <div className='align-self-center'>
          <h2 className='title-large no-top-margin text-left'>
            {I18n.translate('Bills.NoDueBills.PaidBills.Label')}
          </h2>
          <div className='text-larger grey-brown'>
            {I18n.translate('Bills.NoDueBills.NoBills.Text')}
          </div>
        </div>
        <div className='title-large red full-top-margin'>
        </div>
      </div>
    )
  }

  renderNoPaidBills(): JSX.Element {
    const {imgOverallSuccessMail} = this.props;
    return (
      <div className='content-box screen-pane bigger_vertical_padding'>
        <div className='centered-text'>
        <img src={imgOverallSuccessMail || ''}/>
        </div>
          <div className='title-large'>
            {I18n.translate('Bills.NoPaidBills.FutureBills.Title')}
          </div>
          <div className='text-small centered-text'>
            {I18n.translate('Bills.NoPaidBills.FutureBills.Text')}
          </div>
        <div className='vertical_spacer x16'></div>
      <div className='centered-text'>
        <Button
          label={I18n.translate('Bills.NoPaidBills.BackToProfile.Label')}
          handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.handleBacktoProfile(e)}
          className = 'button extra_wide full_width_on_mobile'
        />
      </div>
      </div>
    )
  }

  renderBillAssistant(): JSX.Element {
    return (
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
        <div className='content-box content-box--icon__robot no-bottom-margin'>
          <h2 className='title-large text-left red'>
          {I18n.translate('Bills.BillAssistant.Question.Label')}
          </h2>
          <div className='text-small grey-brown'>{I18n.translate('Bills.BillAssistant.Assistant.Text')}</div>
          <button className='button'>{I18n.translate('Bills.BillAssistant.StartBill.Label')}</button>
        </div>
      </div>
    )
  }

  showHideAccountStatementPopup = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {isAccountStatementPopup} = this.state;
    event.preventDefault();
    this.setState({
      isAccountStatementPopup: !isAccountStatementPopup
    });
  }

  renderAccountStatementPopup = (): JSX.Element => {
    const {account, orderAccountStatementRequest, orderAccountStatementPayload, orderAccountStatementPayloadError, resetOrderAccountStatement} = this.props;
    const owner: Subscriber = account && account.owner;
    const email: Optional<string> = owner && owner.email;
    const billingAddress: string[] = [];
    const primaryAddress: Optional<Address> = account && account.primaryAddress;
    const billingName: string = ` ${(primaryAddress && primaryAddress.salutation) ? caseChange.pascalCase(primaryAddress.salutation) : null } ${owner.firstName} ${owner.lastName}`;
    if (primaryAddress) {
      const streetDetails: string = ` ${primaryAddress.streetName || null} ${primaryAddress.streetNumber || null}, `;
      const cityDetails: string = `${primaryAddress.postalCode || null} ${primaryAddress.town || null}`;
      billingAddress.push(billingName, streetDetails, cityDetails);
    }
    return (
      <BillsOrderAccountStatement
        showHideAccountStatementPopup = {this.showHideAccountStatementPopup}
        orderAccountStatementRequest = {orderAccountStatementRequest}
        orderAccountStatementPayload = {orderAccountStatementPayload}
        orderAccountStatementPayloadError = {orderAccountStatementPayloadError}
        billingAddress = {billingAddress}
        resetOrderAccountStatement = {resetOrderAccountStatement}
        email = {email} />
    );
  }

  showHideDunningPopup = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {isDunningPopup} = this.state;
    event.preventDefault();
    this.setState({
      isDunningPopup: !isDunningPopup
    });
  }

  renderDunning(): JSX.Element | null {
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account && account.billInfo;
    const dunningInfo: Optional<DunningInfo> = billInfo && billInfo.dunningInfo;
    const dunningLevel: Optional<number> = dunningInfo && dunningInfo.dunningLevel;
    const dunningHistory: Optional<(Optional<DunningHistoryEntry>)[]> = dunningInfo && dunningInfo.dunningHistory;
    if (dunningLevel) {
      return (
        <BillsDunning
          dunningLevel = {dunningLevel}
          dunningHistory = {dunningHistory}
          handleClick = {this.showHideDunningPopup}
        />
      );
    }
    return null;
  }

  renderDunningPopup(): JSX.Element {
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account && account.billInfo;
    const dunningInfo: Optional<DunningInfo> = billInfo && billInfo.dunningInfo;
    const dunningHistoryEntries: Optional<(Optional<DunningHistoryEntry>)[]> = dunningInfo && dunningInfo.dunningHistory;
    return (
      <BillsDunningHistory
        dunningHistoryEntries={dunningHistoryEntries}
        handleClick={this.showHideDunningPopup}
      />
    );
  }

  handlePaymentMethod = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {history} = this.props;
    event.preventDefault();
    history.push(BillsRoutes.BILLS_PAYMENT_METHOD);
  }

  handlebillsDueClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {history} = this.props;
    event.preventDefault();
    history.push(BillsRoutes.BILLS_PAY_OUTSTANDING);
  }

  handleBillingAddressChange = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    window.location.href = BillsConstants.EDIT_PROFILE
  }

  renderChangeBillingAddress(): JSX.Element | null {
    const {account} = this.props;
    if (!account) {
      return null;
    }
    const owner: Subscriber = account && account.owner;
    const billingAddress: string[] = [];
    const primaryAddress: Optional<Address> = account && account.primaryAddress;
    const billingName: string = ` ${(primaryAddress && primaryAddress.salutation) ? caseChange.pascalCase(primaryAddress.salutation) : null } ${owner.firstName} ${owner.lastName}`;
    if (primaryAddress) {
      const streetDetails: string = `${primaryAddress.streetName || null} ${primaryAddress.streetNumber || null} `;
      const cityDetails: string = `${primaryAddress.postalCode || null} ${primaryAddress.town || null}`;
      billingAddress.push(billingName, streetDetails, cityDetails);
    }
    return(
      <div className='content-box bigger_vertical_padding'>
        <div className='form'>
          <div className='form-item--flexbox'>
            <div>
              <div className='form__label'>
                {I18n.translate('Bills.ChangeBillingAddress.BillingAddress.Title')}
              </div>
              <div className='form__text'>
                <DataList
                  data = {billingAddress}
                  label = ''
                />
              </div>
            </div>
            <div className='form-item__button'>
              <Button
                handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handleBillingAddressChange(e)}
                label = {I18n.translate('Bills.ChangeBillingAddress.Edit.Button.Label')}
                className = 'button'
              />
            </div>
          </div>
        </div>
      </div>
    )
  }

  renderSaveMoney = (): JSX.Element => {
    return(
      <div className='content-box no-bottom-margin small_content_box'>
        <div className='form form__form-info-variant-2'>
          <div className='form__label form__label--large form__label--highlighted text-left--soft'>{I18n.translate('Bills.SaveMoney.Confirm.Text')}</div>
          <div className='form-item content-box--flexbox flex-align-items-flex-end'>
            <div className='form__text text-small text-left--soft'>{I18n.translate('Bills.SaveMoney.DirectDebit.Text')}</div>
            <Button
              label={I18n.translate('Bills.SaveMoney.ChangePayment.Label')}
              handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.handlePaymentMethod(e)}
              className = 'button button__no-responsive-arrow'
            />
          </div>
        </div>
      </div>
    );
  }

  renderOrderAccountTitle(): JSX.Element {
    const {showLastPaid} = this.state;
    const accountLastPaidLabel: string = showLastPaid ? I18n.translate('Bills.OrderAccount.LastPaid.Text') : I18n.translate('Bills.OrderAccount.LastPaid.Label');
    return (
      <div className='l-col l-1of1 l-1of1-mobile'>
        <div className='centered-text title-large'>
          {I18n.translate('Bills.OrderAccount.LastBills.Title')}
        </div>
        <div className='centered-text text-larger grey-brown text-pad-lr-10perc'>
          {accountLastPaidLabel}
        </div>
      </div>
    );
  }

  renderShowOrHideAccountStatement = (): JSX.Element => {
    return (
      <div className='l-col l-1of2 l-1of1-mobile'>
        <div className='content-box content-box--icon__account-statement'>
          <div className='vertical_spacer x16'></div>
          <div className='title-extra-large t-strong red'>
          {I18n.translate('Bills.Account.Statement.Label')}
          </div>
          <div className='vertical_spacer x16'></div>
          <Button
            label={I18n.translate('Bills.Account.Statement.Title')}
            handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.showHideAccountStatementPopup(e)}
            className = 'button cta-button dark_grey_text'
          />
        </div>
      </div>
    );
  }

  renderPaymentMethod(paymentMethod: Optional<PaymentMethodType>): JSX.Element {
    return (
      <div className='content-box bigger_vertical_padding'>
        <div className='form'>
          <div className='form-item--flexbox'>
            <div>
              <div className='form__label'>
              {I18n.translate('Bills.PaymentMethod.Method.Label')}
              </div>
              <div className='form__text'>
                {paymentMethod === PaymentMethodType.EBILL ? I18n.translate('Bills.PaymentMethod.Ebill.Label')  : paymentMethod === PaymentMethodType.DIRECT_DEBIT ? I18n.translate('Bills.PaymentMethod.DirectDebit.Label') : I18n.translate('Bills.PaymentMethod.PayInSlip.Label')}
              </div>
            </div>
            <div className='form-item__button'>
            <Button
              label={I18n.translate('Bills.PaymentMethod.Edit.Button.Label')}
              handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.handlePaymentMethod(e)}
              className = 'button'
            />
            </div>
          </div>
        </div>
      </div>
    );
  }

  renderPaymentGateway = (): JSX.Element | null => {
    const {paymentState} = this.props;
    const {invokePayment} = this.state;

    if (invokePayment) {
      return (
        <PaymentGateway
          invokePayment = {invokePayment}
          paymentScriptUrl = {paymentService.getPaymentScriptUrl(paymentState)}
          formId = {'paymentForm'}
          paymentObject = {this.getPaymentObject(paymentState)}
          handleScriptError = {this.handleScriptError}
          onCancelled = {this.onCancelled}
        />
      );
    }
    return null;
  }

  render(): React.ReactNode {
    const {account, accountError} = this.props;
    const {isLoading, showLastPaid, isDunningPopup, isPayLaterPopup, isDeblockPopup, isAccountStatementPopup} = this.state;
    if (!account && !accountError) {
      return <Loader />;
    }
    const billInfo: Optional<BillInfo> = account && account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const paymentMethod: Optional<PaymentMethodType> = billSettings && billSettings.paymentMethod;
    const dunningInfo: Optional<DunningInfo> = billInfo && billInfo.dunningInfo;
    const bills: Optional<(Optional<Bill>)[]> = billInfo && billInfo.bills;
    const totalOutstandingAmount: Optional<number> = billInfo && billInfo.totalOutstandingAmount;
    const overdueAmount: Optional<number> = billInfo && billInfo.overdueAmount;
    const outstandingAmount: Optional<number> = billInfo && billInfo.outstandingAmount;
    const paidBills: Optional<(Optional<Bill>)[]> = (bills && bills.length > 0) ? bills.filter((bill) => {return bill!['paid']}) : null;
    const dueBills: Optional<(Optional<Bill>)[]> = (bills && bills.length > 0) ? bills.filter((bill) => {return bill!['dueOn'] !== '' && bill!['openAmount']}) : null;

    if (isLoading) {
      return (<Loader />);
    }

    return (
      <div className='container-fluid'>
        <div className='l-center-l'>
          {this.renderOverlay()}
          {isDunningPopup ? this.renderDunningPopup() : null}
          {isAccountStatementPopup ? this.renderAccountStatementPopup() : null}
          {isPayLaterPopup ? this.renderPayLaterPopup() : null}
          {isDeblockPopup ? this.renderDeblockPopup() : null}
          <div className='l-grid'>
            {bills && bills.length > 0 ?
              <React.Fragment>
                {this.renderDueBillsHeading(dueBills)}
                {this.renderDunning()}
                {paidBills && paidBills.length && !dueBills ? this.renderNoDueBills() : null}
                <div className='vertical_spacer x16'></div>
                {this.renderDueBills(dueBills)}
                {this.renderOutstandingSection(totalOutstandingAmount, dueBills ? dueBills.length : 0, overdueAmount, outstandingAmount)}
                {(dunningInfo && dunningInfo.dunningJokerEligibility)  ? this.renderPayLaterOption() : null}
                {(dunningInfo && dunningInfo.eligibileForDeblocking)  ? this.renderDeblockEnableOption() : null}
                {this.renderOrderAccountTitle()}
                <div className='vertical_spacer x16'></div>
                <div>
                  {this.renderShowOrHideAccountStatement()}
                  {paidBills && paidBills.length > 1 ? this.renderLastPaidSection() : null}
                  {showLastPaid ? this.renderLastPaidBills(paidBills)  : null}
                </div>
                <div className='vertical_spacer x16'></div>
              </React.Fragment> : this.renderNoPaidBills() }
            <div className='l-col l-1of1 l-1of1-mobile'>
              <div className='centered-text title-large'>
                {I18n.translate('Bills.Payment.Delivery.Label')}
                <div className='vertical_spacer x8'></div>
              </div>
              {paymentMethod === PaymentMethodType.PAY_SLIP ? this.renderSaveMoney() : null }
            </div>
            <div className='l-flexbox-row'>
              <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
                {this.renderPaymentMethod(paymentMethod)}
                {this.renderRegisterCardSection()}
                {this.renderChangeBillingAddress()}
              </div>
              {this.renderDeliveryFormatChange()}
            </div>
          </div>
          {this.renderPaymentGateway()}
        </div>
      </div>
    )
  }
}

const mapStateToProps: any = ({ billsReducer, registeredCardReducer, paymentReducer }: any) => {
  return {
    account: billsReducer.account,
    accountError: billsReducer.accountError,
    orderAccountStatementPayload: billsReducer.orderAccountStatementPayload,
    orderAccountStatementPayloadError: billsReducer.orderAccountStatementPayloadError,
    deleteRegisteredCard: registeredCardReducer.deleteRegisteredCard,
    deleteRegisteredCardError: registeredCardReducer.deleteRegisteredCardError,
    paymentState: paymentReducer.paymentState,
    makePayment: paymentReducer.makePayment,
    makePaymentError: paymentReducer.makePaymentError,
    orderBillCopyPayload: billsReducer.orderBillCopyPayload,
    orderBillCopyPayloadError: billsReducer.orderBillCopyPayloadError,
    requestDunningDeblockOnTrustPayLoad: billsReducer.requestDunningDeblockOnTrustPayLoad,
    requestDunningDeblockOnTrustPayLoadError: billsReducer.requestDunningDeblockOnTrustPayLoadError,
    requestDunningJokerPayLoad: billsReducer.requestDunningJokerPayLoad,
    requestDunningJokerPayLoadError: billsReducer.requestDunningJokerPayLoadError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({fetchBillsInfo, setOrderBillCopy, resetOrderBillCopy, orderAccountStatementRequest, resetOrderAccountStatement, resetBills, deleteRegisteredCardRequest, deleteRegisteredCardReset, fetchPaymentState, makePaymentRequest, makePaymentReset, sendBillsDeblockActivate, sendBillsPayLater}, dispatch);
};

export default connect<BillsProps>(mapStateToProps, mapDispatchToProps)(Bills);