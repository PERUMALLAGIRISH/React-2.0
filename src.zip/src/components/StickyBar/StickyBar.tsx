import * as React from 'react';
import {Link} from 'react-router-dom';
import {Button} from '../Form/Button/Button';

interface StickyBarProps {
  url: string,
  data?: object,
  label?: string;
  className?: string;
  backToLabel?: string;
  handleClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

export class StickyBar extends React.Component<StickyBarProps> {
  constructor(props: StickyBarProps) {
    super(props);
  }
  render(): React.ReactNode {
    const {url, data, label, backToLabel, className, handleClick} = this.props;
    return (
      <div className='sticky_bar'>
        <Link to= {{
          pathname: url,
          state: data
          }} className={className}>
          {backToLabel}
        </Link>
        {(handleClick) ? <React.Fragment><div className='inline_spacer x3'></div><Button className= 'button extra_wide' handleClick={handleClick} label={(label) ? label : ''}/></React.Fragment> : null}
      </div>
    )
  }
}