
export interface Map<T> {
    [key: string]: T;
}
export const SubscriptionDetailStringConstants: Map<string> = {
    SUCCESS               : 'success',
    ERROR                 : 'error'
}
