import * as React from 'react';
import ScriptLoader from 'react-load-script';

const theme: object = {
  brandButton: '#aa1937',
    brandColor: '#d9d2d0',
    initialView: 'list',
    logoBorderColor: '#d9d2d0',
    logoSrc: 'logo-sunrise.svg',
    logoType: 'circle',
    payButtonTextColor: 'white',
    textColor: 'white'
};

interface PaymentGatewayProps {
  invokePayment: boolean;
  paymentScriptUrl: string;
  formId: string;
  paymentObject: any;
  handleScriptError: () => void;
  onCancelled: () => void;
}

interface PaymentGatewayState {
}

class PaymentGateway extends React.Component<PaymentGatewayProps, PaymentGatewayState> {
  constructor(props: PaymentGatewayProps) {
    super(props);
  }

  loadPaymentScript(): JSX.Element {
    const {paymentScriptUrl, handleScriptError} = this.props;
    return (
      <ScriptLoader
        url={paymentScriptUrl}
        onError={() => handleScriptError()}
        onLoad={() => this.handleScriptLoad()}
      />
    )
  }

  handleScriptLoad = () => {
    const {formId, onCancelled} = this.props;
    if (Datatrans === undefined) {
      return;
    }
    Datatrans.startPayment({
      'form': `#${formId}`,
      'closed': () => onCancelled()
    });
  }

  render(): React.ReactNode {
    /*
      Note: For local replication change merchant id to 1100004624
    */
    const {invokePayment, formId, paymentObject} = this.props;
    if (formId === '' || paymentObject === undefined) {
      return null;
    }
    return (
      <React.Fragment>
        {invokePayment && this.loadPaymentScript()}
        { paymentObject && Object.keys(paymentObject).length > 0 ? <form id={formId}
          data-merchant-id={paymentObject.merchantId}
          data-amount={paymentObject.amount}
          data-currency='CHF'
          data-refno={paymentObject.refno}
          data-sign={paymentObject.sign}
          data-paymentmethod={paymentObject.paymentmethod}
          data-theme-configuration={JSON.stringify(theme)}
          data-success-url={paymentObject.successUrl}
          data-error-url={paymentObject.errorUrl}
          data-cancel-url={paymentObject.cancelUrl}
          data-upp-web-response-method={'GET'}
          data-upp-return-masked-cc={paymentObject.uppReturnMaskedCc}
          data-alias-c-c={paymentObject.aliasCC || ''}
          data-expm={paymentObject.expm || ''}
          data-expy={paymentObject.expy || ''}
          data-masked-c-c={paymentObject.number || ''}
          data-use-alias={paymentObject.useAlias}></form> : ''}
      </React.Fragment>
    )
  }
}

export default PaymentGateway;