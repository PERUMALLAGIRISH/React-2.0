import { UpdateContactPayload } from '../../model/types.d';
export interface UpdateContactResponse {
    updateContact: UpdateContactPayload;
}