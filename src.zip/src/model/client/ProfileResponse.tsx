export interface ProfileResponse {
  account: Account;
}