/*eslint-env node */

module.exports = function() {

	'use strict';

	return {

		i18n: {
			options: {
				keyPrefix: 'React.',
        keysAsAttributes: false,
			},
			files: {
				'<%= cfg.dirs.messages %>/ReactApp.I18n.xml': ['<%= concat.i18n.dest %>']
			}
		}

	};
};
