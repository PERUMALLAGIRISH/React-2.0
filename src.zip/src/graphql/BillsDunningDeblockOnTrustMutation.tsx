import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const BillsDunningDeblockOnTrustMutation: DocumentNode = gql`
  mutation requestDunningDeblockOnTrust   {
    requestDunningDeblockOnTrust  {
      payloadStatus
    }
  }
`;

export default BillsDunningDeblockOnTrustMutation;