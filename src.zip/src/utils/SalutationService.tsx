import caseChange from 'change-case';

export enum Salutation {
  MR = 'MR',
  MRS = 'MRS',
  MS = 'MS',
  HERR = 'HERR',
  FRAU = 'FRAU',
  SIGNOR = 'SIGNOR',
  SIGNORA = 'SIGNORA',
  MONSIEUR = 'MONSIEUR',
  MADAME = 'MADAME'
}

class SalutationService {
  getSalutationsForLanguage = (language: string) => {
    switch (language.toLowerCase()) {
      case 'en':
        return [{name: caseChange.pascalCase(Salutation.MR), value: Salutation.MR}, {name: caseChange.pascalCase(Salutation.MRS), value: Salutation.MRS}];
      case 'fr':
        return [{name: caseChange.pascalCase(Salutation.MONSIEUR), value: Salutation.MONSIEUR}, {name: caseChange.pascalCase(Salutation.MADAME), value: Salutation.MADAME}];
      case 'it':
        return [{name: caseChange.pascalCase(Salutation.SIGNOR), value: Salutation.SIGNOR}, {name: caseChange.pascalCase(Salutation.SIGNORA), value: Salutation.SIGNORA}];
      case 'de':
        return [{name: caseChange.pascalCase(Salutation.HERR), value: Salutation.HERR}, {name: caseChange.pascalCase(Salutation.FRAU), value: Salutation.FRAU}];
      default:
        return [];
    }
  }
}

export default new SalutationService();