import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const SetPaymentMethodMutation: DocumentNode = gql`
  mutation setPaymentMethod ($input: PaymentMethodTypeInput!) {
    setPaymentMethod(input: $input) {
      payloadStatus
    }
  }
`;

export default SetPaymentMethodMutation;