import * as React  from 'react';
import I18n from '../../utils/helper/I18n';
import {PayloadStatus} from '../../model/types.d';

interface LoginProps {
}

interface LoginState {
    username: string;
    password: string;
    isError: boolean,
    isLoading: boolean
}

class Login extends React.Component<LoginProps, LoginState> {
    constructor(props: LoginProps) {
        super(props);
        this.state = {
            username: '',
            password: '',
            isError: false,
            isLoading: false
        };
    }
    setUsername = (e: React.FormEvent<HTMLInputElement>) => {
        this.setState({ username: e.currentTarget.value.replace(/\s/g, '') });
    }
    setPassword = (e: React.FormEvent<HTMLInputElement>) => {
        this.setState({ password: e.currentTarget.value.replace(/\s/g, '') });
    }
    setLoading = (isLoading: boolean) => {
        this.setState({isLoading : isLoading});
    }
    setError = (isError: boolean) => {
        this.setState({isError : isError});
    }

  handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const {username, password} = this.state;
    this.setLoading(true);
    this.setError(false);
    return fetch(`/login?username=${username}&password=${password}`, {
      method: 'GET',
      credentials: 'include',
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(response.statusText);
        }
        return response.json()
    })
    .then((data) => {
        this.handleLoginSuccess(data);
    })
    .catch((error) => {
        this.handleLoginError(error);
    });
  }
  handleLoginSuccess = (data: any) => {
    if (data && data.status && data.status === PayloadStatus.NOK) {
      this.setError(true);
      this.setLoading(false);
      return;
    }
    window.location.reload();
  }
  handleLoginError = (error: Error) => {
    this.setLoading(false);
    this.setError(true);
  }

  render(): React.ReactNode {
    const { username, password, isError, isLoading } = this.state;
    const isButtonDisabled: boolean = username === '' || password === '' ? true : false;
    const errorClass: string = isError ? 'form_error' : '';

    return (
      <div className='l-center-l'>
        <div className='l-grid'>
          <div className='l-col l-1of1'>
            <div className='content-box small_content_box'>
              <div className='vertical_spacer x32'></div>
              <h2 className='page-title--red centered-text'>
                  <I18n code='Login.LoginWithPassword.Label'/>
              </h2>
              <div className='text-small centered-text'>
                  {I18n.translate('Login.EnterSunrise.PhoneNumber.Label')}
              </div>
              <div className='vertical_spacer x32'></div>
              {isLoading ? <div className='as-absolute as-light load_spinner'> {I18n.translate('Global.Loading')} </div> : null}
              <form onSubmit={(e) => this.handleSubmit(e)} action='/login' method ='post'>
                <div className='form form_middle_box'>
                  <div className='form-item item-tooltip'>
                    <label className={`form__label form__text_field-label ${errorClass}`}>
                        {I18n.translate('Login.MobileLandline.CustomerNumber.Label')}*
                    </label>
                    <input name='username' value={username} onChange={e => this.setUsername(e)} className={`form_input ${errorClass}`} placeholder={I18n.translate('Login.MobileNumber.Label')}/>
                  </div>
                  <div className='form-item item-tooltip'>
                    <label className={`form__label form__text_field-label ${errorClass}`}>
                        {I18n.translate('Login.PasswordAsterisk.Label')}*
                    </label>
                    <input name='password' value={password} onChange={e => this.setPassword(e)} className={`form_input ${errorClass}`} type='password' placeholder={I18n.translate('Login.Password.Label')}/>
                  </div>
                  <div className='form-item'>
                    <div className='form-item__button full_width_on_mobile'>
                      <button type='submit' className='button extra_wide' disabled={isButtonDisabled}>{I18n.translate('Global.Submit')}</button>
                    </div>
                  </div>
                  <span className='tip'>
                    {I18n.translate('Login.Tip.Label')}
                  </span>
                  <div className='text-extra-small'>
                    {I18n.translate('Login.PasswordTip.Text')}
                  </div>
                  <div className='vertical_spacer x32'></div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Login;
