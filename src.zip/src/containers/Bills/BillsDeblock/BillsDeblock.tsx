import * as React from 'react';
import {RequestDunningDeblockOnTrustPayLoad, PayloadStatus} from '../../../model/types.d';
import {Success} from '../../../components/Success/Success';
import {Loader} from '../../../components/Loader/Loader';
import I18n from '../../../utils/helper/I18n';
import { Button } from '../../../components/Form/Button/Button';

interface BillsDeblockProps {
  requestDunningDeblockOnTrustPayLoad?: RequestDunningDeblockOnTrustPayLoad;
  requestDunningDeblockOnTrustPayLoadError?: Error | null;
  sendBillsDeblockActivate: () => void;
  handleClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

interface BillsDeblockState {
  isLoading: boolean;
  renderStatus: boolean;
}

export class BillsDeblock extends React.Component<BillsDeblockProps, BillsDeblockState> {
  constructor(props: BillsDeblockProps) {
    super(props);
    this.state = {isLoading: false, renderStatus: true}
  }

  static getDerivedStateFromProps(nextProps: BillsDeblockProps, prevState: BillsDeblockState): any | null {
    if ((nextProps.requestDunningDeblockOnTrustPayLoad || nextProps.requestDunningDeblockOnTrustPayLoadError) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  saveDeblock = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {sendBillsDeblockActivate} = this.props;
    this.setState({
      isLoading: true,
      renderStatus: false
    });
    sendBillsDeblockActivate();
  }

  renderDeblockEnable(): JSX.Element | null {
    const {renderStatus} = this.state;
    const {handleClick} = this.props;
    if (renderStatus) {
      return (
        <div className='popup-message-box popup-message-box--free-buttons popup-message-box--smaller-horz-padding'>
          <h2 className='title-large'>
            {I18n.translate('BillsDeblock.Payment.Unblocked.Title')}
          </h2>
          <div className='text-small'>
            {I18n.translate('BillsDeblock.Payment.Unblocked.Text')}
          </div>
          <div className='hr-line pale-grey'></div>
          <div className='vertical_spacer x8'></div>
          <div className='form__label'>
            {I18n.translate('BillsDeblock.Payment.ImportantNote.Title')}
          </div>
          <div className='centered-text text-extra-small bold'>
            {I18n.translate('BillsDeblock.Payment.ImportantNote.Label')}
          </div>
          <div className='centered-text text-extra-small bold'>
            {I18n.translate('BillsDeblock.Payment.ImportantNotify.Label')}
          </div>
          <div className='vertical_spacer x8'></div>
          <div className='form-item'>
            <div className='form-item__button full_width_on_mobile'>
              <Button
                className= 'button extra_wide full_width_on_mobile transparent_background'
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => handleClick(e)}
                label = {I18n.translate('BillsDeblock.Cancel.Button.Label')}
              />
              <Button
                className= 'button extra_wide full_width_on_mobile'
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.saveDeblock(e)}
                label = {I18n.translate('BillsDeblock.Payment.Unblock.Button.Label')}
              />
            </div>
          </div>
        </div>
      );
    }
    return null;
  }

  renderDeblockSuccess(): JSX.Element | null {
    const {requestDunningDeblockOnTrustPayLoad, requestDunningDeblockOnTrustPayLoadError, handleClick} = this.props;
    const {renderStatus} = this.state;
    let label: string = '';
    let title: string = '';
    if (requestDunningDeblockOnTrustPayLoadError || (requestDunningDeblockOnTrustPayLoad && requestDunningDeblockOnTrustPayLoad.payloadStatus === PayloadStatus.NOK) || !requestDunningDeblockOnTrustPayLoad) {
      label = I18n.translate('BillsDeblock.Error.Label');
      title = I18n.translate('BillsDeblock.Error.Title');
    } else if (requestDunningDeblockOnTrustPayLoad  && (requestDunningDeblockOnTrustPayLoad && requestDunningDeblockOnTrustPayLoad.payloadStatus === PayloadStatus.OK)) {
      label = I18n.translate('BillsDeblock.Payment.Success.Label');
      title = I18n.translate('BillsDeblock.Payment.Success.Title');
    }
    if (!renderStatus) {
      return (
        <Success
          imageSource={'/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/overall_success_mail.png'}
          heading = {title}
          text = {label}
          button = {I18n.translate('BillsDeblock.Close.Button.Label')}
          href = {''}
          handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => handleClick(e)}
        />
      );
    }
    return null;
  }

  render(): React.ReactNode {
    const {isLoading} = this.state;
    return(
      <React.Fragment>
        <div className='overlay'></div>
        <div className='popup__container'>
          <div className='popup'>
            {isLoading ? <Loader /> : null}
            {this.renderDeblockEnable()}
            {this.renderDeblockSuccess()}
          </div>
        </div>
      </React.Fragment>
    );
  }
}