import {Action, Dispatch} from 'redux';
import {PaymentState , PaymentInput, PaymentPayload} from '../../../model/types.d';
import GraphQL from '../../../graphql/GraphQL';
import paymentStateQuery from '../../../graphql/PaymentStateQuery';
import {PaymentStateResponse} from '../../../model/client/PaymentStateResponse';
import makePaymentMutation from '../../../graphql/MakePaymentMutation';
import {PaymentResponse} from '../../../model/client/PaymentResponse';

export enum PaymentActionType {
  FETCH_PAYMENT_CONFIG = 'FETCH_PAYMENT_CONFIG',
  FETCH_PAYMENT_CONFIG_ERROR = 'FETCH_PAYMENT_CONFIG_ERROR',
  PAYMENT_SUCCESS = 'PAYMENT_SUCCESS',
  PAYMENT_ERROR = 'PAYMENT_ERROR',
  PAYMENT_RESET = 'PAYMENT_RESET'
}

export enum PaymentStateActionType {
  FETCH_PAYMENT_STATE = 'FETCH_PAYMENT_STATE',
  FETCH_PAYMENT_STATE_ERROR = 'FETCH_PAYMENT_STATE_ERROR'
}

export interface PaymentStateAction extends Action {
  type: PaymentStateActionType;
  payload: PaymentState;
}

export interface PaymentAction extends Action {
  type: PaymentActionType;
  payload: PaymentPayload;
}

export const fetchPaymentState: any = (amount: number) => {
  return (dispatch: Dispatch) => {
    GraphQL.query({
      query: paymentStateQuery,
      variables: {amount: amount}
    }, (response: PaymentStateResponse) => {
      if (response.paymentState) {
        dispatch({type: PaymentStateActionType.FETCH_PAYMENT_STATE, payload: response.paymentState});
      } else {
        dispatch({type: PaymentStateActionType.FETCH_PAYMENT_STATE_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: PaymentStateActionType.FETCH_PAYMENT_STATE_ERROR, payload: error});
    });
  };
};

export const makePaymentRequest: any = (paymentInput: PaymentInput) => {
  return (dispatch: Dispatch) => {
    GraphQL.mutation({
      mutation: makePaymentMutation,
      variables: {input: paymentInput}
    }, (response: PaymentResponse) => {
      if (response && response.makePayment) {
        dispatch({type: PaymentActionType.PAYMENT_SUCCESS, payload: response.makePayment});
      } else {
        dispatch({type: PaymentActionType.PAYMENT_ERROR, payload: response});
      }
    }, (error: Error) => {
      dispatch({type: PaymentActionType.PAYMENT_ERROR, payload: error});
    });
  };
};

export const makePaymentReset: any = () => {
  return (dispatch: Dispatch) => {
    dispatch({type: PaymentActionType.PAYMENT_RESET, payload: undefined});
  };
};