import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const paymentStateQuery: DocumentNode = gql`
    query paymentState ($amount: Float!) {
        paymentState (amount: $amount) {
            paymentMethods
            paymentProvider {
                merchantId
                providerUrl
                sign
                amount
                referenceNumber
                currency
                uppReturnMaskedCc
                paymentCards
                paymentServices
            }
            registeredCards {
                aliasCc
                paymentCard
                expiryYear
                expiryMonth
                number
            }
        }
    }`;

export default paymentStateQuery;