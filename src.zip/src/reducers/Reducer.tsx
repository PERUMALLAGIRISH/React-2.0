import { combineReducers, Action } from 'redux';
import ProfileReducer  from '../containers/Profile/ProfileReducer';
import BillsReducer from '../containers/Bills/BillsReducer';
import RegisteredCardReducer from '../containers/Bills/RegisteredCard/RegisteredCardReducer';
import PaymentReducer from '../containers/Bills/Payment/PaymentReducer';
import SubscriptionDetailReducer from '../containers/SubscriptionDetail/SubscriptionDetailReducer';
import SubscriptionDetailChangeOwnerReducer from '../containers/SubscriptionDetail/SubscriptionDetailChangeOwner/SubscriptionDetailChangeOwnerReducer';

const allReducers: any = combineReducers<any, any>({
  profileReducer: ProfileReducer,
  billsReducer: BillsReducer,
  registeredCardReducer: RegisteredCardReducer,
  paymentReducer: PaymentReducer,
  subscriptionDetailReducer: SubscriptionDetailReducer,
  subscriptionDetailChangeOwnerReducer: SubscriptionDetailChangeOwnerReducer
});

const appReducer: any = (state: any, action: Action) => {
  // if (action.type === LoginActionType.RESET_APP || action.type === LoginActionType.LOGOUT_SUCCESS) {
  //   const { quickLinkReducer } = state;
  //   state = { quickLinkReducer };
  // }
  return allReducers(state, action);
};

export default appReducer;