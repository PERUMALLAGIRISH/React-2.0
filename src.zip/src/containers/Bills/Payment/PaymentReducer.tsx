import {
  PaymentAction,
  PaymentActionType,
  PaymentStateAction,
  PaymentStateActionType
} from './PaymentAction';
import {PaymentState, PaymentPayload} from '../../../model/types.d';

export interface InitialState {
  paymentState: PaymentState | null;
  paymentStateError: Error | null;
  makePayment: PaymentPayload | null;
  makePaymentError: Error | null;
}

const initialState: InitialState = {
  paymentState: null,
  paymentStateError: null,
  makePayment: null,
  makePaymentError: null
};

export default (state = initialState, action: PaymentAction | PaymentStateAction) => {
  switch (action.type) {
    case PaymentStateActionType.FETCH_PAYMENT_STATE:
      return {
        ...state,
        paymentState: action.payload
      };
    case PaymentStateActionType.FETCH_PAYMENT_STATE_ERROR:
      return {
        ...state,
        paymentStateError: action.payload
      };
    case PaymentActionType.PAYMENT_SUCCESS:
      return {
        ...state,
        makePayment: action.payload
      };
    case PaymentActionType.PAYMENT_ERROR:
      return {
        ...state,
        makePaymentError: action.payload
      };
    case PaymentActionType.PAYMENT_RESET:
      return initialState;
    default:
      return state;
  }
};