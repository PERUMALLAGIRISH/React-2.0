import { SetBillingAddressPayload } from '../../model/types.d';
export interface SetBillingAddressResponse {
  setBillingAddress: SetBillingAddressPayload;
}