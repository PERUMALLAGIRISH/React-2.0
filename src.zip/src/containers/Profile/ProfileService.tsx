import {Subscriber, UpdateContactInput} from '../../model/types.d';
import {ProfileEditForm} from './ProfileEdit/ProfileEdit';

class ProfileService {
  getUpdateContactInput = (profile: ProfileEditForm, owner: Subscriber) => {
    const updateContactInput: UpdateContactInput = {};
    if (profile) {
      if (profile.email && profile.email !== owner.email) {
        updateContactInput.email = profile.email;
      }
      if (profile.phone && profile.phone !== owner.phone) {
        updateContactInput.phone = profile.phone;
      }
      if (profile.languageCode && profile.languageCode !== owner.language) {
        updateContactInput.languageCode = profile.languageCode;
      }
    }
    return updateContactInput;
  }
}
export const profileService: ProfileService = new ProfileService();
