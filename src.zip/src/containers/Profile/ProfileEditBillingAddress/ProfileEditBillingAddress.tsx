import * as React from 'react';
import {
  Account,
  Address,
  AddressInput,
  AddressValidity,
  AddressValidityInput,
  AddressValidityStatus,
  BillInfo,
  BillingAddress,
  Country,
  Optional,
  PayloadStatus,
  SetBillingAddressInput,
  SetBillingAddressPayload
} from '../../../model/types.d';
import {connect} from 'react-redux';
import {ActionCreatorsMapObject, bindActionCreators, Dispatch} from 'redux';
import {
  fetchAccount,
  fetchCountries,
  resetBillingAddress,
  setBillingAddress,
  validateAddress
} from '../ProfileAction';
import {Select} from '../../../components/Form/Select/Select';
import {Input} from '../../../components/Form/Input/Input';
import {Loader} from '../../../components/Loader/Loader';
import {Link} from 'react-router-dom';
import SalutationService from '../../../utils/SalutationService';
import DataLanguageService from '../../../utils/DataLanguageService';
import ScrollActionService from '../../../utils/ScrollActionService';
import caseChange from 'change-case';
import {Popup} from '../../../components/Popup/Popup';
import {ProfileConstants, ProfileEditBillingAddressConstants} from '../ProfileConstants';
import I18n from '../../../utils/helper/I18n';
import {ProfileRoutes} from '../ProfileRoutes.enum';
import ValidationService from '../../../utils/ValidationService';
import {History, Location} from 'history';

export interface ProfileEditBillingAddressProps {
  account: Account;
  accountError: Error;
  addressValidity: AddressValidity;
  addressValidityError: Error | null;
  setBillingAddressPayload: SetBillingAddressPayload | null;
  setBillingAddressPayloadError: Error | null;
  countries: Country[] | null;
  countriesError: Error | null;
  history: History
  location: Location;
  imgPayingBills?: string;
  setBillingAddress: (setBillingAddressInput: SetBillingAddressInput) => void;
  validateAddress: (addressValidityInput: AddressValidityInput) => void;
  resetBillingAddress: () => void;
  fetchAccount: () => void;
  fetchCountries: () => void;
}

interface ProfileEditBillingAddressState {
  addressForm: AddressForm;
  salutationName: string,
  countryName: string,
  step: number,
  sameAsCustomerAddress: boolean,
  isTooltipPopup: boolean,
  selectedTooltipId: string,
  isAddressValidated: boolean
}

export interface AddressForm extends AddressInput {
  [ key: string ]: any
};

class ProfileEditBillingAddress extends React.Component<ProfileEditBillingAddressProps, ProfileEditBillingAddressState> {
  constructor(props: ProfileEditBillingAddressProps) {
    super(props);
    this.state = {
      addressForm: {
        salutation: ProfileEditBillingAddressConstants.DEFAULT_SALUTATION,
        countryIsocode: ProfileEditBillingAddressConstants.DEFAULT_COUNTRY_CODE,
        firstName: '',
        lastName: '',
        postalCode: '',
        streetName: '',
        streetNumber: '',
        town: '',
      },
      salutationName: I18n.translate('ProfileEditBillingAddress.Label.SalutationText'),
      countryName: ProfileEditBillingAddressConstants.DEFAULT_COUNTRY_NAME,
      step: 1,
      sameAsCustomerAddress: false,
      isTooltipPopup: false,
      selectedTooltipId: '',
      isAddressValidated: false
    }
  }

  componentDidMount(): void {
    const {location, fetchAccount, fetchCountries}  = this.props;
    const account: object = location.state;
    if (!account) {
      fetchAccount();
    }
    fetchCountries();
  }

  componentWillUnmount(): void {
    const {resetBillingAddress}  = this.props;
    resetBillingAddress();
  }

  static getDerivedStateFromProps(nextProps: ProfileEditBillingAddressProps, prevState: ProfileEditBillingAddressState): any | null {
    if (nextProps.account && prevState.step === 1 && (prevState.addressForm.salutation === ProfileEditBillingAddressConstants.DEFAULT_SALUTATION && prevState.addressForm.firstName === '' && prevState.addressForm.lastName === '' &&
      prevState.addressForm.postalCode === '' && prevState.addressForm.streetName === '' && prevState.addressForm.streetNumber === '' && prevState.addressForm.town === '' && prevState.addressForm.countryIsocode === ProfileEditBillingAddressConstants.DEFAULT_COUNTRY_CODE)) {
      const primaryAddress: Optional<Address> = nextProps.account.primaryAddress;
      const billInfo: Optional<BillInfo> = nextProps.account.billInfo;
      const billingAddress: Optional<BillingAddress> = billInfo && billInfo.billingAddress;
      const differentBillingAddress: Optional<Address> = billingAddress && billingAddress.differentBillingAddress;
      if (primaryAddress && billingAddress && billingAddress.sameAsCustomerAddress) {
        return {
          addressForm: {
            salutation: primaryAddress.salutation,
            firstName: primaryAddress.firstName,
            lastName: primaryAddress.lastName,
            postalCode: primaryAddress.postalCode,
            town: primaryAddress.town,
            streetName: primaryAddress.streetName,
            streetNumber: primaryAddress.streetNumber,
            countryIsocode: primaryAddress.countryIsocode
          }
        };
      } else if (differentBillingAddress && Object.keys(differentBillingAddress).length) {
        return {
          addressForm: {
            salutation: differentBillingAddress.salutation,
            firstName: differentBillingAddress.firstName,
            lastName: differentBillingAddress.lastName,
            postalCode: differentBillingAddress.postalCode,
            town: differentBillingAddress.town,
            streetName: differentBillingAddress.streetName,
            streetNumber: differentBillingAddress.streetNumber,
            countryIsocode: differentBillingAddress.countryIsocode
          }
        };
      }
    }

    if (nextProps.addressValidity &&
      (nextProps.addressValidity.status === AddressValidityStatus.VALID || nextProps.addressValidity.status === AddressValidityStatus.SUGGESTION) &&
      prevState.isAddressValidated &&
      !nextProps.setBillingAddressPayload) {
      return {
        step : ProfileConstants.STEP2,
        town : nextProps.addressValidity.town,
        postalCode: nextProps.addressValidity.postalCode,
        streetName: nextProps.addressValidity.streetName,
        streetNumber: nextProps.addressValidity.streetNumber,
      };
    }

    if (nextProps.setBillingAddressPayload && nextProps.setBillingAddressPayload.payloadStatus === PayloadStatus.OK) {
      return {
        step: ProfileConstants.STEP3
      };
    }

    if ((nextProps.setBillingAddressPayload && nextProps.setBillingAddressPayload.payloadStatus === PayloadStatus.NOK) || nextProps.setBillingAddressPayloadError) {
      return {
        step: ProfileConstants.STEP4
      };
    }
    return null;
  }

  renderUpdateBillingAddress(): JSX.Element {
    return (
      <div className='l-col l-1of1'>
        <div className='content-box small_content_box-spacing'>
          <div className='form form__form-info-variant-4'>
            <div className='l-flexbox-row'>
              <div className='l-col-flexbox l-col-flexbox-2_3 responsive_content_box'>
                <div className='form__label form__label--large form__label--highlighted no-bottom-margin'>{I18n.translate('ProfileEditBillingAddress.Label.ContentAddress')}</div>
              </div>
              <div className='l-col-flexbox l-col-flexbox-1_3 responsive_content_box'>
                <div className='form-item content-box--flexbox flex-justify-content-center--mobile'>
                  <button
                    className='button button__no-responsive-arrow'
                    onClick={(e: React.MouseEvent<HTMLButtonElement>) => this.handleUpdateMyBillingAddress(e)}
                  >{I18n.translate('ProfileEditBillingAddress.Button.Update')}</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  onValidateAddressError(): JSX.Element | null {
    const {addressValidityError, addressValidity } = this.props;
    const {step, isAddressValidated} = this.state;
    const scrollOptions: object = {behavior: ProfileEditBillingAddressConstants.SMOOTH,  block: ProfileEditBillingAddressConstants.START};

    if (addressValidityError || (addressValidity && addressValidity.status === AddressValidityStatus.INVALID)) {
      if (step !== ProfileConstants.STEP1 && !isAddressValidated) {
        return null;
      }
      return (
        <React.Fragment>
          <div className='l-col l-1of1'>
            <div className='content-box small_content_box bigger_vertical_padding'>
              <h3 className='page-title_medium--red lighter left-text'>{addressValidityError ? I18n.translate('ProfileEditBillingAddress.ValidateAddress.Label.GeneralError') : I18n.translate('ProfileEditBillingAddress.ValidateAddress.InvalidError')}</h3>
              <div className='text-small'>
                {addressValidityError ? I18n.translate('ProfileEditBillingAddress.ValidateAddress.ErrorDescription') : I18n.translate('ProfileEditBillingAddress.ValidateAddress.ErrorTitle')}
              </div>
            </div>
            {ScrollActionService.scrollAction('.content-box.small_content_box-spacing', scrollOptions)}
          </div>
        </React.Fragment>
      );
    }
    return null;
  }

  handleUpdateMyBillingAddress = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    this.setState({
      sameAsCustomerAddress: true,
      isAddressValidated: false,
      step: 2
    });
  }

  renderProgressBar(): JSX.Element {
    const {step} = this.state;
    return (
      <div className='progress_tracker centered-text'>
        <div className={`inline_progress_sign progress_step_number--${step === ProfileConstants.STEP1 ? 'mobile-' : ''}small progress_step_sign    progress_tracker__break_words`}>
          <div className='progress_step_number'>{ProfileConstants.STEP1}</div>
          <div className='progress_step_title text-small bold'>{I18n.translate('ProfileEditBillingAddress.Label.Address')}</div>
        </div>
        <div className='progress_tracker__dash'></div>
        <div className={`inline_progress_sign progress_step_number--${step === ProfileConstants.STEP2 ? 'mobile-' : ''}small progress_step_sign progress_tracker__break_words`}>
          <div className='progress_step_number'>{ProfileConstants.STEP2}</div>
          <div className='progress_step_title text-small bold'>{I18n.translate('ProfileEditBillingAddress.Label.Summary')}</div>
        </div>
      </div>
    );
  }

  renderLargeTitle(largeTitleLabel: string): JSX.Element {
    return (
      <div className='title-large'>{largeTitleLabel}</div>
    );
  }

  renderSmallTitle(smallTitleLabel?: string): JSX.Element {
    const {step} = this.state;
    if (step === ProfileConstants.STEP2) {
      return (
        <div className='text-small centered-text text-pad-lr-30perc'>
          {I18n.translate('ProfileEditBillingAddress.Label.AddressTitle')}
        </div>
      );
    }
    return (
      <div className='text-small centered-text'>{smallTitleLabel}</div>
    );
  }

  renderBillingAddress(): JSX.Element {
    const {addressForm, step, sameAsCustomerAddress} = this.state;
    const cancelButton: string = step === ProfileConstants.STEP1 ?  I18n.translate('ProfileEditBillingAddress.Button.Cancel') : I18n.translate('ProfileEditBillingAddress.Button.Back');
    const nextButton: string = step === ProfileConstants.STEP1 ? I18n.translate('ProfileEditBillingAddress.Button.Next') : I18n.translate('ProfileEditBillingAddress.Button.Confirm');
    let disabled: boolean = false;

    if ((addressForm.firstName && !ValidationService.isValidName(addressForm.firstName)) || (addressForm.lastName && !ValidationService.isValidName(addressForm.lastName)) || addressForm.salutation === ProfileEditBillingAddressConstants.DEFAULT_SALUTATION || addressForm.firstName === '' ||  addressForm.lastName === '' || addressForm.postalCode === '' || addressForm.streetName === '' || addressForm.streetNumber === '' || addressForm.town === '' || addressForm.countryIsocode === '') {
      disabled = true;
    }

    if (sameAsCustomerAddress && step === ProfileConstants.STEP2) {
      disabled = false;
    }

    return (
      <div className='form-item'>
        <div className='form-item__button full_width_on_mobile'>
          <button
            className='button extra_wide full_width_on_mobile transparent_background'
            onClick={step === ProfileConstants.STEP1 ? ((e: React.MouseEvent<HTMLButtonElement>) => this.handleClickCancel(e)) : ((e: React.MouseEvent<HTMLButtonElement>) => this.handleBackClick(e))}>
            {cancelButton}
          </button>
          <button
            className='button extra_wide full_width_on_mobile'
            disabled={disabled}
            onClick={step === ProfileConstants.STEP1 ? ((e: React.MouseEvent<HTMLButtonElement>) => this.handleNextClick(e)) : ((e: React.MouseEvent<HTMLButtonElement>) => this.handleBillingAddressConfirm(e))}>
            {nextButton}
          </button>
        </div>
      </div>
    );
  }

  handleBillingAddressConfirm = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {setBillingAddress} = this.props;
    const {sameAsCustomerAddress, addressForm} = this.state;
    const setBillingAddressInput: SetBillingAddressInput = {sameAsCustomerAddress: sameAsCustomerAddress, differentBillingAddress: !sameAsCustomerAddress ? addressForm : null };
    setBillingAddress(setBillingAddressInput);
  }

  handleBackClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    this.setState({
      step: 1,
      sameAsCustomerAddress: false,
      isAddressValidated: false
    });
  }

  handleNextClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {validateAddress} = this.props;
    const {addressForm} = this.state;
    const addressValidityInput: AddressValidityInput = { postalCode: addressForm.postalCode || '', streetName: addressForm.streetName || '', streetNumber: addressForm.streetNumber || '', town: addressForm.town || '', minConfidence: 1 };
    validateAddress(addressValidityInput);
    this.setState({
      sameAsCustomerAddress: false,
      isAddressValidated: true
    });
  }

  handleClickCancel = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {history} = this.props;
    history.push({
      pathname: ProfileRoutes.PROFILE_HOME
    });
  }

  getSalutationOptions(): string[] {
    const SalutationOptions: Array<any> = [];
    const {account} = this.props;
    let defaultSalutation: string = '';
    if (account && account.billInfo &&
      account.billInfo.billingAddress && account.primaryAddress &&
      account.primaryAddress.salutation) {
      if (account.billInfo.billingAddress.sameAsCustomerAddress) {
        defaultSalutation = account.primaryAddress.salutation;
      } else if ( account.billInfo.billingAddress.differentBillingAddress &&  account.billInfo.billingAddress.differentBillingAddress.salutation) {
        defaultSalutation = account.billInfo.billingAddress.differentBillingAddress.salutation;
      }
    }
    SalutationOptions.push({name: I18n.translate('ProfileEditBillingAddress.Label.SalutationText'), value: ProfileEditBillingAddressConstants.DEFAULT_SALUTATION});
    if (defaultSalutation !== '') {
      SalutationOptions.push({name: caseChange.pascalCase(defaultSalutation), value: defaultSalutation});
    }
    const language: string = DataLanguageService.getLanguageCode(),
      salutation: Array<object> = SalutationService.getSalutationsForLanguage(language);
    salutation.forEach((option: any) => {
      if (option.value !== defaultSalutation) {
        SalutationOptions.push(option)
      }
    });

    return SalutationOptions;
  }

  renderSalutation(): JSX.Element {
    const salutationOptions: string[] = this.getSalutationOptions();
    const {salutationName, addressForm} = this.state;
    return (
      <div className='form-row'>
        <div className='form-item l-formcol-2of6 form-item--first'>
          <Select
            options={salutationOptions}
            name={salutationName}
            value={addressForm.salutation || ''}
            className={'form_input'}
            labelClassName = {'form__label form__text_field-label form__label__text text-left form__space_select_widget'}
            label = {`${I18n.translate('ProfileEditBillingAddress.Label.SalutationTitle')}*`}
            onChange = {this.handleSalutationChange}
          />
        </div>
      </div>
    );
  }

  getFieldLabel(field: string): string {
    switch (field) {
      case ProfileConstants.FIRST_NAME: return `${I18n.translate('ProfileEditBillingAddress.Label.FirstName')}*`;
      case ProfileConstants.LAST_NAME: return `${I18n.translate('ProfileEditBillingAddress.Label.LastName')}*`;
      case ProfileConstants.POSTAL_CODE: return `${I18n.translate('ProfileEditBillingAddress.Label.ZipCode')}*`;
      case ProfileConstants.TOWN: return `${I18n.translate('ProfileEditBillingAddress.Label.City')}*`;
      case ProfileConstants.STREET_NAME: return `${I18n.translate('ProfileEditBillingAddress.Label.Street')}*`;
      case ProfileConstants.STREET_NUMBER: return `${I18n.translate('ProfileEditBillingAddress.Label.StreetNumber')}*`;
      case ProfileConstants.COUNTRY_NAME: return `${I18n.translate('ProfileEditBillingAddress.Label.Country')}*`;
      default: return ''
    }
  }

  getTooltipData = (id: string): string[] => {
    const tooltipData: any = {};
    switch (id) {
      case ProfileConstants.FIRST_NAME:
        tooltipData.title = I18n.translate('ProfileEditBillingAddress.Tooltip.FirstNameTitle');
        tooltipData.text = I18n.translate('ProfileEditBillingAddress.Tooltip.FirstNameDescription');
        return tooltipData;
      case ProfileConstants.LAST_NAME:
        tooltipData.title = I18n.translate('ProfileEditBillingAddress.Tooltip.LastNameTitle');
        tooltipData.text = I18n.translate('ProfileEditBillingAddress.Tooltip.LastNameDescription');
        return tooltipData;
      case ProfileConstants.COUNTRY_NAME:
        tooltipData.title = I18n.translate('ProfileEditBillingAddress.Tooltip.CountryTitle');
        tooltipData.text = I18n.translate('ProfileEditBillingAddress.Tooltip.CountryDescription');
        return tooltipData;
      case ProfileConstants.POSTAL_CODE:
        tooltipData.title = I18n.translate('ProfileEditBillingAddress.Tooltip.PostalCodeTitle');
        tooltipData.text = I18n.translate('ProfileEditBillingAddress.Tooltip.PostalCodeDescription');
        return tooltipData;
      case ProfileConstants.TOWN:
        tooltipData.title = I18n.translate('ProfileEditBillingAddress.Tooltip.TownTitle');
        tooltipData.text = I18n.translate('ProfileEditBillingAddress.Tooltip.TownDescription');
        return tooltipData;
      case ProfileConstants.STREET_NAME:
        tooltipData.title = I18n.translate('ProfileEditBillingAddress.Tooltip.StreetNameTitle');
        tooltipData.text = I18n.translate('ProfileEditBillingAddress.Tooltip.StreetNameDescription');
        return tooltipData;
      case ProfileConstants.STREET_NUMBER:
        tooltipData.title = I18n.translate('ProfileEditBillingAddress.Tooltip.StreetNumberTitle');
        tooltipData.text = I18n.translate('ProfileEditBillingAddress.Tooltip.StreetNumberDescription');
        return tooltipData;
      default:
        tooltipData.title = '';
        tooltipData.text = '';
        return tooltipData;
    }
  }

  displayPopup(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
    const {isTooltipPopup} = this.state;
    event.persist();
    this.setState({
      isTooltipPopup: !isTooltipPopup,
      selectedTooltipId: event.currentTarget.id
    });
  }

  renderTooltipPopup = (): JSX.Element => {
    const {selectedTooltipId} = this.state;
    const tooltipData: any = this.getTooltipData(selectedTooltipId);
    return (
      <Popup
        title = {tooltipData.title}
        data = {[tooltipData.text]}
        buttonLabel = {I18n.translate('ProfileEditBillingAddress.Button.Ok')}
        onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}
      />
    );
  }

  inputFormLabeled(name: string, value: string, className: string, formcol: string, handleChange: (fieldName: string, value: string) => void): JSX.Element {
    let type: string = ProfileConstants.TEXT;
    let errorText: string = '';
    if ((name === ProfileConstants.FIRST_NAME || name === ProfileConstants.LAST_NAME) && !ValidationService.isValidName(value)) {
      errorText = I18n.translate('ProfileEditBillingAddress.ValidateName.Label.Error');
    }
    if (name === ProfileConstants.POSTAL_CODE) {
      type = ProfileConstants.NUMBER;
      if (!ValidationService.isValidNumber(value)) {
        errorText = I18n.translate('ProfileEditBillingAddress.ValidateZipCode.Label.Error');
      }
    }
    return (
      <div className={`form-item l-formcol-${formcol}`}>
        <Input
          name = {name}
          value = {value}
          className = {className}
          onChange = {this.handleModelChange}
          type = {type}
          labelClassName = {errorText ? 'form__label form__text_field-label form__label__text text-left form_error' : 'form__label form__text_field-label form__label__text text-left'}
          label = {errorText ? errorText : this.getFieldLabel(name)}
          onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}
          tooltipId = {name}
        />
      </div>
    );
  }

  renderName(): JSX.Element {
    const {addressForm} = this.state;
    return (
      <div className='form-row'>
        {this.inputFormLabeled(ProfileConstants.FIRST_NAME, addressForm.firstName || '', 'form_input', '3of6', this.handleModelChange)}
        {this.inputFormLabeled(ProfileConstants.LAST_NAME, addressForm.lastName || '', 'form_input', '3of6', this.handleModelChange)}
      </div>
    );
  }

  renderLocation(): JSX.Element {
    const {addressForm} = this.state;
    return (
      <div className='form-row'>
        {this.inputFormLabeled(ProfileConstants.POSTAL_CODE, addressForm.postalCode || '', 'form_input', '2of6', this.handleModelChange)}
        {this.inputFormLabeled(ProfileConstants.TOWN, addressForm.town || '', 'form_input', '4of6', this.handleModelChange)}
      </div>
    );
  }

  renderStreet(): JSX.Element {
    const {addressForm} = this.state;
    return (
      <div className='form-row'>
        {this.inputFormLabeled(ProfileConstants.STREET_NAME, addressForm.streetName || '', 'form_input', '4of6', this.handleModelChange)}
        {this.inputFormLabeled(ProfileConstants.STREET_NUMBER, addressForm.streetNumber || '', 'form_input', '2of6', this.handleModelChange)}
      </div>
    );
  }

  renderCountry(): JSX.Element {
    const {addressForm} = this.state;
    const {countries} = this.props;

    return (
      <div className='form-row'>
        <div className='form-item l-formcol-3of6'>
          <Select
            options={countries}
            name={ProfileConstants.COUNTRY_NAME}
            value={addressForm.countryIsocode || ''}
            className={'form_input'}
            labelClassName = {'form__label form__text_field-label form__label__text text-left'}
            label = {this.getFieldLabel(ProfileConstants.COUNTRY_NAME)}
            tooltipId = {ProfileConstants.COUNTRY_NAME}
            onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayPopup(e)}
            onChange = {this.handleCountryChange}
          />
        </div>
      </div>
    );
  }

  handleModelChange = (fieldName: string, value: string): void => {
    const addressForm: AddressForm = {...this.state.addressForm}
    addressForm[fieldName] = value;
    this.setState({addressForm});
  }

  handleSalutationChange = (fieldName: string, value: any): void => {
    const selectedSalutationOption: any = this.getSalutationOptions().find((option: any) => option.value === value );
    const addressForm: AddressForm = {...this.state.addressForm}
    addressForm.salutation = value;
    this.setState({
      addressForm,
      salutationName : selectedSalutationOption.name
    });
  }

  handleCountryChange = (fieldName: string, value: string): void => {
    const {countries} = this.props;
    let selectedCountryOption: any = {};
    if (countries !== null) {
      selectedCountryOption = countries.find((option: any) => option.isocode === value );
    }
    const addressForm: AddressForm = {...this.state.addressForm}
    addressForm.countryIsocode = value;
    this.setState({
      addressForm,
      countryName : selectedCountryOption.name
    });
  }

  renderForm(): JSX.Element {
    return (
      <div className='form'>
        {this.renderSalutation()}
        {this.renderName()}
        <br />
        {this.renderLocation()}
        {this.renderStreet()}
        {this.renderCountry()}
        {this.renderBillingAddress()}
      </div>
    );
  }

  renderFormStep(): JSX.Element {
    const {step} = this.state;
    switch (step) {
      case ProfileConstants.STEP1:
        return (
          <div className='content-box small_content_box bigger_vertical_padding'>
            {this.renderProgressBar()}
            {this.renderLargeTitle(I18n.translate('ProfileEditBillingAddress.Label.BillingAddress'))}
            {this.renderSmallTitle(I18n.translate('ProfileEditBillingAddress.Label.AddressInformation'))}
            {this.renderForm()}
          </div>
        );
      case ProfileConstants.STEP2:
        return (
          <div className='content-box small_content_box bigger_vertical_padding'>
            {this.renderProgressBar()}
            {this.renderLargeTitle(I18n.translate('ProfileEditBillingAddress.Label.InformationTitle'))}
            {this.renderSmallTitle()}
            {this.renderConfirmationSection()}
          </div>
        );
      case ProfileConstants.STEP3:
      case ProfileConstants.STEP4:
        return (
          <div className='content-box small_content_box bigger_vertical_padding'>
            {this.renderSubmit()}
          </div>
        );
      default:
        return (
          <Loader />
        );
    }
  }

  renderMainForm(): JSX.Element {
    return (
      <div className='l-col l-1of1'>
        {this.renderFormStep()}
      </div>
    );
  }

  renderConfirmationSection(): JSX.Element[] {
    const {addressForm, sameAsCustomerAddress} = this.state;
    const {countries, account, addressValidity} = this.props;
    const selectedSalutationOption: any = this.getSalutationOptions().find((option: any) => option.value === addressForm.salutation );
    let selectedCountryOption: any = {};
    let primaryAddress: any = {};

    if (countries !== null) {
      selectedCountryOption = countries.find((option: any) => option.isocode === addressForm.countryIsocode );
    }
    if (account !== null && account.primaryAddress !== null) {
      primaryAddress = account.primaryAddress;
    }

    const oldAddress: JSX.Element = (
      <span className='grey-18'>
        {caseChange.pascalCase(primaryAddress.salutation)}. {primaryAddress.firstName} {primaryAddress.lastName} <br />
        {primaryAddress.streetName} {primaryAddress.streetNumber}<br />
        {primaryAddress.postalCode} {primaryAddress.town}<br />
        {primaryAddress.countryName}
      </span>
    );
    const newAddress: JSX.Element = (
      <span className='grey-18'>
          {selectedSalutationOption !== undefined ? selectedSalutationOption.name : caseChange.pascalCase(addressForm.salutation || '')}. {addressForm.firstName} {addressForm.lastName} <br />
        {addressForm.streetName} {addressForm.streetNumber}<br />
        {addressForm.postalCode} {addressForm.town}<br />
        {selectedCountryOption.name}
        </span>
    );

    return ([
      <div className='content-box smaller_60_content_box' key={ProfileConstants.STEP1}>
        <div className='text-left page-title_medium--grey'>{sameAsCustomerAddress ? I18n.translate('ProfileEditBillingAddress.Label.CustomerAddress') : `${addressValidity.status === AddressValidityStatus.SUGGESTION ? I18n.translate('ProfileEditBillingAddress.Label.SuggestedBillingAddress') : I18n.translate('ProfileEditBillingAddress.Label.NewBillingAddress')}`}</div>
        <br />
        {sameAsCustomerAddress ? oldAddress : newAddress}
      </div>,
      <div className='form' key={ProfileConstants.STEP2}>
        {this.renderBillingAddress()}
      </div>
    ]);
  }

  renderSubmit(): JSX.Element[] {
    const {imgPayingBills} = this.props;
    const successText: JSX.Element = (
      <div className='text-small centered-text'>{I18n.translate('ProfileEditBillingAddress.BillingAddress.Label.Success')}</div>
    );
    const failureText: JSX.Element = (
      <div className='form__label form__label--highlighted'>{I18n.translate('ProfileEditBillingAddress.BillingAddress.Label.ErrorTitle')}</div>
    );
    const {step} = this.state;
    return ([
      <div className='centered-text' key={ProfileConstants.STEP0}>
        <img src={imgPayingBills || ''} />
      </div>,
      <h2 className='title-middle--grey centered-text' key={ProfileConstants.STEP1}>{I18n.translate('ProfileEditBillingAddress.BillingAddress.Label.PayBills')}</h2>,
      <br key={ProfileConstants.STEP2}/>,
      <React.Fragment  key={ProfileConstants.STEP3}>{step === ProfileConstants.STEP4 ? failureText : successText}</React.Fragment>,
      <div className='centered-text' key={ProfileConstants.STEP4}>
        <Link to= {{
          pathname: ProfileRoutes.PROFILE_HOME,
        }} className='button'>
          {I18n.translate('ProfileEditBillingAddress.BillingAddress.Button.BackToProfile')}
        </Link>
      </div>
    ]);
  }

  render(): React.ReactNode {
    const {step, isTooltipPopup} = this.state;
    return (
      <div className='l-center-l'>
        {isTooltipPopup && this.renderTooltipPopup()}
        <div className='l-grid'>
          {step === ProfileConstants.STEP1 && this.renderUpdateBillingAddress()}
          {this.onValidateAddressError()}
          {this.renderMainForm()}
        </div>
      </div>
    );
  }
}

const mapStateToProps: any = ({ profileReducer }: any) => {
  return {
    account: profileReducer.account,
    accountError: profileReducer.accountError,
    setBillingAddressPayload:  profileReducer.setBillingAddressPayload,
    setBillingAddressPayloadError: profileReducer.setBillingAddressPayloadError,
    countries: profileReducer.countries,
    countriesError: profileReducer.countriesError,
    addressValidity: profileReducer.addressValidityStatus,
    addressValidityError: profileReducer.addressValidityError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({ fetchAccount, setBillingAddress, resetBillingAddress, fetchCountries, validateAddress}, dispatch);
};

export default connect<ProfileEditBillingAddressProps>(mapStateToProps, mapDispatchToProps)(ProfileEditBillingAddress);
