class DataLanguageService {
  getLanguageCode = (): string => {
    const bodyElement: HTMLElement | null = document.getElementsByTagName('body')[0];
    let code: string | null = '';
    if (bodyElement !== null && bodyElement.getAttribute('data-language') !== null) {
      code = bodyElement.getAttribute('data-language')
    }
    if (code === null || typeof code !== 'string' || code === '') {
      return 'en'
    }
    return code;
  }
}

export default new DataLanguageService();