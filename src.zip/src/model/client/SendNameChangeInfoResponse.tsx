import { SendNameChangeInfoPayload } from '../../model/types.d';
export interface SendNameChangeInfoResponse {
  sendNameChangeInfo: SendNameChangeInfoPayload;
}