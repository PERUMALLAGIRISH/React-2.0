import { BillAnonymizationLevelPayload } from '../../model/types.d';
export interface BillAnonymizationLevelResponse {
  setBillAnonymizationLevel: BillAnonymizationLevelPayload;
}