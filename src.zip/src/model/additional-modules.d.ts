declare module 'react-load-script';
declare const Datatrans: any;
// declare const window: any;
