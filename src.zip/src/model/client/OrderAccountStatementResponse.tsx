import { OrderAccountStatementPayload } from '../../model/types.d';
export interface OrderAccountStatementResponse {
    orderAccountStatement: OrderAccountStatementPayload;
  }