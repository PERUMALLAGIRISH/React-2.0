import { SetBillDeliveryMethodPayload } from '../../model/types.d';
export interface SetBillDeliveryMethodResponse {
  setBillDeliveryMethod: SetBillDeliveryMethodPayload;
}