import * as React from 'react';
import {fetchChangeOwner, resetChangeOwner, sendChangeOwner, resetSendChangeOwner} from './SubscriptionDetailChangeOwnerAction';
import {Account} from '../../../model/types.d';
import {Dispatch, ActionCreatorsMapObject, bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import { History, Location } from 'history';
import moment from 'moment';
import I18n from '../../../utils/helper/I18n';
import { DataList } from '../../../components/DataList/DataList';
import { Popup } from '../../../components/Popup/Popup';
import DateService from '../../../utils/DateService';
import { Button } from '../../../components/Form/Button/Button';
import { Loader } from '../../../components/Loader/Loader';
import SubscriptionDetailChangeOwnerService from './SubscriptionDetailChangeOwnerService';
import {SubscriptionDetailChangeOwnerConstants} from './SubscriptionDetailChangeOwnerConstants';
import {SubscriptionDetailRoutes} from '../SubscriptionDetailRoutes.enum';
import { Input } from '../../../components/Form/Input/Input';
declare let window: any;

export interface SubscriptionDetailChangeOwnerProps {
  account: Account;
  accountError: Error;
  changeOwner: any;
  fetchChangeOwner: (changeOwner: any) => void;
  resetChangeOwner: () => void;
  sendChangeOwner: () => void;
  resetSendChangeOwner: () => void;
  location: Location;
  history: History;
}

interface SubscriptionDetailChangeOwnerState {
  isLoading: boolean;
  scheduledDate: {
    field: string;
    value: string;
  };
  eligibilityErrorType: {
    title: string;
    description: string;
  }
  rcToBc: boolean;
  rcToBcParams: object;
  progressImpossible: boolean;
  isEmailPopupOpen: boolean;
  step: number,
  scheduledDateInput: string;
}

class SubscriptionDetailChangeOwner extends React.Component<SubscriptionDetailChangeOwnerProps, SubscriptionDetailChangeOwnerState> {
   datePickerInput: any = null;
  constructor(props: SubscriptionDetailChangeOwnerProps) {
    super(props);
    this.state = {
      isLoading: true,
      scheduledDate: {
        field: 'scheduledDate',
        value: moment().format()
      },
      eligibilityErrorType: {
        title: '',
        description: ''
      },
      rcToBc: false,
      rcToBcParams: {},
      progressImpossible: false,
      isEmailPopupOpen: false,
      step: 1,
      scheduledDateInput: ''

    }
  }

  componentDidMount(): void {
    const {fetchChangeOwner, changeOwner} = this.props;
    fetchChangeOwner(this.props);
    if (changeOwner) {
      const {eligibilityFail} = changeOwner
      if (!this.state.progressImpossible) {
        this.checkEligibility(eligibilityFail);
      }
    }
  }

  componentWillUnmount(): void {
    const {resetChangeOwner} = this.props;
    resetChangeOwner();
    resetSendChangeOwner();
  }

  static getDerivedStateFromProps(nextProps: SubscriptionDetailChangeOwnerProps, prevState: SubscriptionDetailChangeOwnerState): any | null {
    if (nextProps.changeOwner && ((nextProps.changeOwner.accessStatus === SubscriptionDetailChangeOwnerConstants.ERROR) || (nextProps.changeOwner.accountStatus === SubscriptionDetailChangeOwnerConstants.ERROR) || (nextProps.changeOwner.modemStatus === SubscriptionDetailChangeOwnerConstants.ERROR) || (nextProps.changeOwner.summaryStatus === SubscriptionDetailChangeOwnerConstants.ERROR) || !nextProps.changeOwner.polltoken || nextProps.changeOwner.polltoken === '')) {
      clearInterval(window.changeOwner);console.log('dd', window.changeOwner);
    }
    return null;
  }

  checkEligibility = (eligibilityFail: any) => {
    if (eligibilityFail.failAction === SubscriptionDetailChangeOwnerConstants.ERROR) {
      const {eligibilityErrorType} = this.state;
      const eligibilityError: string = eligibilityFail.failType;
      const errorInformation: any = SubscriptionDetailChangeOwnerService.getEligibilityErrorType(eligibilityError);
      eligibilityErrorType['title'] = errorInformation.title;
      eligibilityErrorType['description'] = errorInformation.description;
      this.setState({progressImpossible: true, eligibilityErrorType});
    }
  }
  renderEmailTooltip = (): JSX.Element => {
    return (
      <Popup
        title = {<I18n code='SubscriptionDetailChangeOwner.EmailTitle.ToolTip'/>}
        data = {[I18n.translate('SubscriptionDetailChangeOwner.EmailDescription.ToolTip')]}
        buttonLabel = {<I18n code='SubscriptionDetailChangeOwner.EmailButton.ToolTip'/>}
        onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayClosePopup(e)}
      />);
  }

  displayClosePopup(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
    const {isEmailPopupOpen} = this.state;
    this.setState({
      isEmailPopupOpen: !isEmailPopupOpen
    });
  }

  handleClickCancel = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    const {history} = this.props;
    history.push({
      pathname: SubscriptionDetailRoutes.SUBSCRIPTION_DETAIL_HOME
    });
  }
  handleBackClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    this.setState({
      step: 1
    });
  }

  handleNextClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.preventDefault();
    this.setState({
      step: 2
    });
  }
  handleChangeOwnerConfirm = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {changeOwner} = this.props;
    // // const {scheduledDate} = this.state;
    event.preventDefault();
    const ServiceSerial: string = SubscriptionDetailChangeOwnerService.getServiceSerial(changeOwner);
    // // const dateObject: any = this.state.scheduledDate;
    const scheduledDate: object = { scheduledDate: ''};
    // const info: any = { ServiceSerial: ServiceSerial, scheduledDate: scheduledDate};
    console.log('demo');
    sendChangeOwner(ServiceSerial, scheduledDate);
  }

  renderProgressBar(): JSX.Element {
    const {step} = this.state;
    return (
      <div className='progress_tracker centered-text'>
        <div className={`inline_progress_sign progress_step_number--${step === SubscriptionDetailChangeOwnerConstants.STEP1 ? 'mobile-' : ''}small progress_step_sign    progress_tracker__break_words`}>
          <div className='progress_step_number'>{SubscriptionDetailChangeOwnerConstants.STEP1}</div>
          <div className='progress_step_title text-small bold'>{<I18n code='SubscriptionDetailChangeOwner.Label.Address' />}</div>
        </div>
        <div className='progress_tracker__dash'></div>
        <div className={`inline_progress_sign progress_step_number--${step === SubscriptionDetailChangeOwnerConstants.STEP2 ? 'mobile-' : ''}small progress_step_sign progress_tracker__break_words`}>
          <div className='progress_step_number'>{SubscriptionDetailChangeOwnerConstants.STEP2}</div>
          <div className='progress_step_title text-small bold'>{<I18n code='SubscriptionDetailChangeOwner.Label.Date' />}</div>
        </div>
      </div>
    );
  }

  renderEligibilityError(): JSX.Element | null {
    const {progressImpossible, eligibilityErrorType} = this.state;
    const {changeOwner} = this.props;
    const currentOwnerAddress: string[] = SubscriptionDetailChangeOwnerService.getCurrentOwnerAddress(changeOwner);
    const currentOwnerBirthday: string = SubscriptionDetailChangeOwnerService.getCurrentOwnerBirthDate(changeOwner);
    if (progressImpossible) {
      return (
        <div className='content-box'>
          <div className='vert-centered-text'>
            <img className='inline_text' src={'/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/error.svg'}/>
            <div className='text-s-14px t-bold red-error to-upper-case inline_text'>&nbsp;{eligibilityErrorType.title}</div>
          </div>
          <div className='vertical_spacer x8'></div>
          <div className='text-s-12px t-w-500 grey-brown'>
            {eligibilityErrorType.description}
          </div>
          <div className='p-flexbox p-flex-left content-box--flexbox-mobile-column'>
            <div className='form-item subscriber_name__T03-04-05'>
              <div className='form__label'>
                {<I18n code='SubscriptionDetailChangeOwner.Name.Label' />}
              </div>
              <div className='form__text'>
               {currentOwnerAddress[0]}
              </div>
            </div>
            <div className='form-item no-bottom-margin'>
              <div className='form__label'>
                <I18n code='SubscriptionDetailChangeOwner.CurrentOwner.MyBirthday.Label' />
              </div>
              <div className='form__text'>
               {DateService.formatDate(currentOwnerBirthday)}
              </div>
            </div>
          </div>
        </div>
      );
    }
    return null
  }

  renderPhoneNumber(): JSX.Element {
    const {changeOwner} = this.props;
    const {step} = this.state;
    const subscribtionData: string[] = SubscriptionDetailChangeOwnerService.getphoneNumber(changeOwner);
    return(
      <React.Fragment>
        <div className='title-large text-pad-lr-70'>
          {step === SubscriptionDetailChangeOwnerConstants.STEP1 ? <I18n code= 'SubscriptionDetailChangeOwner.SubscriberInformation.PhoneNumber.Title' /> : <I18n code= 'SubscriptionDetailChangeOwner.DateTransfer.PhoneNumber.Title' /> }
        </div>
        <div className= {step === SubscriptionDetailChangeOwnerConstants.STEP1 ? 'text-s-14px centered-text text-pad-lr-70' : 'text-s-14px centered-text'}>
          {step === SubscriptionDetailChangeOwnerConstants.STEP1 ? <I18n code= 'SubscriptionDetailChangeOwner.SubscriberInformation.PhoneNumber.Description' /> : <I18n code= 'SubscriptionDetailChangeOwner.DateTransfer.PhoneNumber.Description' />}
        </div>
        <div className='centered-text'>
          <div className='content-box fit-content content_box--padding-y10--2'>
            <div className='text-s-14px t-bold'>
              {subscribtionData}
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  renderSelectedDate(): JSX.Element {
    return (
      <React.Fragment>
        <div className='vertical_spacer x16'></div>
        <div className='form__label centered-text'>
        <I18n code='SubscriptionDetailChangeOwner.SelectedDate.Title'/>
        </div>
        <div className='title-large extra_margin_small ok-color-aquamarine'>
        19.11.2018
        </div>
      </React.Fragment>
    );
  }
  renderOwnerEmail(): JSX.Element {
    const {changeOwner} = this.props;
    const ownerEmail: string[] = SubscriptionDetailChangeOwnerService.getOwnerEmail(changeOwner);
    return (
      <div className='content-box content_box--padding-y20'>
        <DataList
          data = {ownerEmail}
          label = {I18n.translate('SubscriptionDetailChangeOwner.Email.Label')}
          hasTooltip= {ownerEmail.length > 0 ? true : false}
          onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayClosePopup(e)}
        />
      </div>
    );
  }

  renderSubscriptionInformation(): JSX.Element {
    const {changeOwner} = this.props;
    const subscriptionInformation: any = SubscriptionDetailChangeOwnerService.getSubscriptionInformation(changeOwner);
    const list: object[] = [];
    subscriptionInformation.forEach((element: any, index: any) => {
      list.push(<DataList data={[element['value']]} label={element['key']}/>)
    });
    return (
      <div className='l-col-flexbox l-col-flexbox-even l-col-flexbox-full-width--mobile'>
        <div className='content-box content_box--padding-y20'>
          <div className='form-item no-bottom-margin no-min-height'>
            <div className='form__label red extra-margin'>
             <I18n code = 'SubscriptionDetailChangeOwner.SubscriberInformation.Title' />
            </div>
          </div>
          {list}
        </div>
      </div>
    );
  }

  renderSubscriptionCurrentOwner(): JSX.Element {
    const {changeOwner} = this.props;
    const currentOwnerAddress: string[] = SubscriptionDetailChangeOwnerService.getCurrentOwnerAddress(changeOwner);
    const currentOwnerBirthday: string = SubscriptionDetailChangeOwnerService.getCurrentOwnerBirthDate(changeOwner);
    return (
      <div className='l-col-flexbox l-col-flexbox-even l-col-flexbox-full-width--mobile'>
        <div className='content-box content_box--padding-y20'>
          <div className='form-item no-bottom-margin no-min-height'>
            <div className='form__label red extra-margin'>
              <I18n code='SubscriptionDetailChangeOwner.CurrentOwner.Title' />
            </div>
          </div>
          <DataList
            data = {currentOwnerAddress}
            label = {<I18n code='SubscriptionDetailChangeOwner.CurrentOwner.Address.Label' />}
          />
          <DataList
            data = {[DateService.formatDate(currentOwnerBirthday)]}
            label = {<I18n code='SubscriptionDetailChangeOwner.CurrentOwner.MyBirthday.Label' />}
          />
        </div>
     </div>
    );
  }

  renderSubscription(): JSX.Element {
    return (
      <div className='l-flexbox-row'>
        {this.renderSubscriptionInformation()}
        {this.renderSubscriptionCurrentOwner()}
      </div>
    );
  }

  scheduledDateChanges = (fieldName: any, value: string): void => {
    this.setState({scheduledDateInput: moment(value).format(I18n.translate('Global.Format.Date.ISO.WithTime'))});
  }

  renderCalender(): JSX.Element {
    const {scheduledDateInput} = this.state;
    return (
      <React.Fragment>
        <div className='content-box'>
        <Input
            type = {'text'}
            name = {'scheduleddate'}
            value = {scheduledDateInput}
            className = {'form_input'}
            tooltipId = {'Date'}
            labelClassName = {'form__label form__text_field-label form__label__text'}
            label = {'Date'}
            onChange = {this.scheduledDateChanges}
            onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayClosePopup(e)}
          />
        </div>
      </React.Fragment>
    );
  }

  renderSteps(): JSX.Element {
    const {step, progressImpossible} = this.state;
    const cancelButton: string = step === SubscriptionDetailChangeOwnerConstants.STEP1 ?  I18n.translate('ProfileEditBillingAddress.Button.Cancel')  : I18n.translate('ProfileEditBillingAddress.Button.Back') ;
    const nextButton: string = step === SubscriptionDetailChangeOwnerConstants.STEP1 ? I18n.translate('ProfileEditBillingAddress.Button.Next')  : I18n.translate('ProfileEditBillingAddress.Button.Confirm') ;
    return (
      <div className='form-item'>
      <div className='form-item__button full_width_on_mobile'>
          <Button
            className='button extra_wide full_width_on_mobile transparent_background'
            handleClick={step === SubscriptionDetailChangeOwnerConstants.STEP1 ? ((e: React.MouseEvent<HTMLButtonElement>) => this.handleClickCancel(e)) : ((e: React.MouseEvent<HTMLButtonElement>) => this.handleBackClick(e))}
            label = {cancelButton}
          />
          <Button
            className='button extra_wide full_width_on_mobile'
            handleClick={step === SubscriptionDetailChangeOwnerConstants.STEP1 ? ((e: React.MouseEvent<HTMLButtonElement>) => this.handleNextClick(e)) : ((e: React.MouseEvent<HTMLButtonElement>) => this.handleChangeOwnerConfirm(e))}
            label = {nextButton}
            disabled = {!progressImpossible ? false : false}
          />
      </div>
      </div>
    );
  }

  renderFormStep(): JSX.Element {
    const {step} = this.state;
    switch (step) {
      case SubscriptionDetailChangeOwnerConstants.STEP1:
        return (
          <React.Fragment>
            {this.renderProgressBar()}
            {this.renderPhoneNumber()}
            {this.renderEligibilityError()}
            {this.renderOwnerEmail()}
            {this.renderSubscription()}
          </React.Fragment>
        );
      case SubscriptionDetailChangeOwnerConstants.STEP2:
        return (
          <React.Fragment>
            {this.renderProgressBar()}
            {this.renderPhoneNumber()}
            {this.renderSelectedDate()}
            {this.renderCalender()}
          </React.Fragment>
        );
      default:
        return (
          <Loader />
        );
    }
  }
  render(): React.ReactNode {
    const {isEmailPopupOpen} = this.state;
    const {changeOwner} = this.props;
    if (!changeOwner) {
      return (<Loader />);
    }
    return (
      <div className='l-center-l'>
      {isEmailPopupOpen ? this.renderEmailTooltip() : null}
        <div className='l-grid'>
          <div className='l-col l-1of1'>
            <div className='content-box content_box--padding-x83-y48'>
              {this.renderFormStep()}
              {this.renderSteps()}
            </div>
          </div>
        </div>
        </div>
    );
  }
}

const mapStateToProps: any = ({subscriptionDetailReducer, subscriptionDetailChangeOwnerReducer}: any) => {
  return {
    account: subscriptionDetailReducer.account,
    accountError: subscriptionDetailReducer.accountError,
    changeOwner: subscriptionDetailChangeOwnerReducer.changeOwner,
    sendChangeOwner: subscriptionDetailChangeOwnerReducer.sendChangeOwner,
    sendChangeOwnerError: subscriptionDetailChangeOwnerReducer.sendChangeOwnerError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({fetchChangeOwner, resetChangeOwner, sendChangeOwner, resetSendChangeOwner}, dispatch);
};

export default connect<SubscriptionDetailChangeOwnerProps>(mapStateToProps, mapDispatchToProps)(SubscriptionDetailChangeOwner);
