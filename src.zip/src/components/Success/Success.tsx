import * as React from 'react';
import {Button} from '../Form/Button/Button';
export interface SuccessProps {
    imageSource: string;
    heading: string;
    text: string;
    button: string;
    href?: string;
    handleClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
}

export const Success: React.StatelessComponent<SuccessProps> = (props) => {

  const {text, imageSource, heading, href, button, handleClick} = props;
  const content: any = { __html: text};

  return (
    <div className='content-box screen-pane'>
      <div className='centered-text'>
          <img src={imageSource} />
      </div>
      <h2 className='title-large'>
          {heading}
      </h2>
      <div className='text-small centered-text' dangerouslySetInnerHTML={content}>
      </div>
      <div className='vertical_spacer x16'></div>
      <div className='centered-text'>
          {href && href !== '' ?
          <a className='button' href={href}>{button}</a> :
          (handleClick) ? <Button className= 'button button--flex extra_wide full_width_on_mobile' handleClick={handleClick} label={button}/> : ''}
      </div>
    </div>
  );
};
