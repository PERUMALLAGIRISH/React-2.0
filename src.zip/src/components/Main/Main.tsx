import './Main.scss';
import * as React from 'react';
import {Route} from 'react-router-dom';
import {Footer} from '../Footer/Footer';
import {Navigation} from '../Navigation/Navigation';

interface MainProps {
  component: any;
  path?: string;
}

const Main: React.StatelessComponent<MainProps> = (props) => {
  const { component: Component, ...rest } = props;
  return <Route {...rest} render={matchProps =>
    <div className='wrapper'>
      <Navigation />
      <Component {...matchProps} />
      <Footer />
    </div>
  } />
}

export default Main;