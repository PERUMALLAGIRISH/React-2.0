const AjaxService: any = {
  ajax: (args: any, successCallback: ((response: {}) => void)) => {
      fetch(args.url, {
          method: args.method,
      })
      .then(response => response.json())
      .then(data => {
          successCallback(data);
      }).catch((error) => {
      });
  }
}

export default AjaxService;