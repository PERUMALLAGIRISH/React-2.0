import './Navigation.scss';
import * as React from 'react';
import {Link} from 'react-router-dom';

interface NavigationProps {
}

export class Navigation extends React.Component<NavigationProps> {
  constructor(props: NavigationProps) {
    super(props);
  }
  render(): React.ReactNode {
    return (
      <div className='navigation'>
        <div className='navigation-logo'>
          <nav className='navbar navbar-default'>
            <div className='container-fluid'>
              <div className='navbar-header'>
                <button type='button' className='navbar-toggle collapsed' data-toggle='collapse' data-target='#nav-logo' aria-expanded='false'>
                  <span className='icon-bar'></span>
                  <span className='icon-bar'></span>
                  <span className='icon-bar'></span>
                </button>
                <a className='navbar-brand' href='/'><span>Sunrise</span></a>
              </div>
              <div className='collapse navbar-collapse' id='nav-logo'>
                <ul className='nav navbar-nav navbar-right'>
                  <li><Link to='/'>My Sunrise</Link></li>
                  <li><Link to='/profile'>Profile</Link></li>
                  <li><Link to='/dashboard'>Dashboard</Link></li>
                  <li><Link to='/settings'>Settings</Link></li>
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    )
  }
}
