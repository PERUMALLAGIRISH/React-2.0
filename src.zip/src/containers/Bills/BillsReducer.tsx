import {
  BillsActionType,
  FetchBillsInfoAction,
  FetchBillsInfoErrorAction,
  OrderBillCopyAction,
  OrderBillCopyErrorAction,
  ResetOrderBillCopyAction,
  OrderBillCopyActionType,
  RequestDunningJokerAction,
  RequestDunningJokerErrorAction,
  ResetRequestDunningJokerAction,
  RequestDunningJokerActionType,
  RequestDunningDeblockOnTrustAction,
  RequestDunningDeblockOnTrustErrorAction,
  ResetRequestDunningDeblockOnTrustAction,
  RequestDunningDeblockOnTrustActionType,
  SetPaymentMethodActionType,
  SetPaymentMethodAction,
  SetPaymentMethodErrorAction,
  PaymentStateActionType,
  PaymentStateAction,
  OrderAdditionalPaymentSlipAction,
  OrderAdditionalPaymentSlipErrorAction,
  OrderAdditionalPaymentSlipActionType,
  BillAnonymizationLevelAction,
  BillAnonymizationLevelErrorAction,
  ResetBillAnonymizationLevel,
  BillDeliveryMethodAction,
  BillDeliveryMethodErrorAction,
  ResetBillDeliveryMethod,
  BillAnonymizationLevelActionType,
  BillDeliveryMethodActionType,
  ResetBillsScreenAction,
  OrderAccountStatementAction,
  OrderAccountStatementErrorAction,
  ResetOrderAccountStatement,
  RequestAccountStatementActionType
} from './BillsAction';
import {Account, OrderBillCopyPayload, AccountStatementMethod, OrderAccountStatementPayload, RequestDunningJokerPayLoad, RequestDunningDeblockOnTrustPayLoad, PaymentMethodTypePayload, OrderAdditionalPaymentSlipPayload, BillAnonymizationLevelPayload, SetBillDeliveryMethodPayload} from '../../model/types.d';

export interface InitialState {
  account: Account | null;
  accountError: Error | null;
  orderBillCopyPayload: OrderBillCopyPayload | null;
  orderBillCopyPayloadError: Error | null;
  requestAccountStatement: AccountStatementMethod | null;
  requestAccountStatementError: Error | null;
  requestAccountStatementPayload: OrderAccountStatementPayload | null;
  requestAccountStatementPayloadError: Error | null;
  requestDunningJokerPayLoad: RequestDunningJokerPayLoad | null;
  requestDunningJokerPayLoadError: Error | null;
  requestDunningDeblockOnTrustPayLoad: RequestDunningDeblockOnTrustPayLoad | null;
  requestDunningDeblockOnTrustPayLoadError: Error | null;
  paymentMethodTypePayload: PaymentMethodTypePayload | null;
  paymentMethodTypePayloadError: Error | null;
  orderAdditionalPaymentSlip: OrderAdditionalPaymentSlipPayload | null;
  orderAdditionalPaymentSlipError: Error | null;
  billAnonymizationLevelPayload: BillAnonymizationLevelPayload | null;
  billAnonymizationLevelPayloadError: Error | null;
  billDeliveryMethodPayload: SetBillDeliveryMethodPayload | null;
  billDeliveryMethodPayloadError: Error | null;
  OrderAccountStatementPayload: OrderAccountStatementPayload | null;
  orderAccountStatementPayloadError: Error | null;
}

const initialState: InitialState = {
  account: null,
  accountError: null,
  orderBillCopyPayload: null,
  orderBillCopyPayloadError: null,
  requestAccountStatement: null,
  requestAccountStatementError: null,
  requestAccountStatementPayload: null,
  requestAccountStatementPayloadError: null,
  requestDunningJokerPayLoad: null,
  requestDunningJokerPayLoadError: null,
  requestDunningDeblockOnTrustPayLoad: null,
  requestDunningDeblockOnTrustPayLoadError: null,
  paymentMethodTypePayload: null,
  paymentMethodTypePayloadError: null,
  orderAdditionalPaymentSlip: null,
  orderAdditionalPaymentSlipError: null,
  billAnonymizationLevelPayload: null,
  billAnonymizationLevelPayloadError: null,
  billDeliveryMethodPayload: null,
  billDeliveryMethodPayloadError: null,
  OrderAccountStatementPayload: null,
  orderAccountStatementPayloadError: null
};

type BillsAction = FetchBillsInfoAction |
  FetchBillsInfoErrorAction |
  OrderBillCopyAction |
  OrderBillCopyErrorAction |
  ResetOrderBillCopyAction |
  ResetBillsScreenAction |
  RequestDunningJokerAction |
  RequestDunningJokerErrorAction |
  ResetRequestDunningJokerAction |
  RequestDunningDeblockOnTrustAction |
  RequestDunningDeblockOnTrustErrorAction |
  ResetRequestDunningDeblockOnTrustAction |
  SetPaymentMethodAction |
  SetPaymentMethodErrorAction |
  OrderAdditionalPaymentSlipAction |
  OrderAdditionalPaymentSlipErrorAction |
  BillAnonymizationLevelAction |
  BillAnonymizationLevelErrorAction |
  ResetBillAnonymizationLevel |
  BillDeliveryMethodAction |
  BillDeliveryMethodErrorAction |
  ResetBillDeliveryMethod |
  OrderAccountStatementAction |
  OrderAccountStatementErrorAction |
  ResetOrderAccountStatement;

export default (state = initialState, action: BillsAction | PaymentStateAction) => {
  switch (action.type) {
    case BillsActionType.FETCH_BILLS_INFO:
      return {
        ...state,
        account: action.payload
      };
    case BillsActionType.FETCH_BILLS_INFO_ERROR:
      return {
        ...state,
        accountError: action.payload
      };
    case RequestDunningJokerActionType.REQUEST_DUNNING_JOKER:
      return {
        ...state,
        requestDunningJokerPayLoad: action.payload
      };
    case RequestDunningJokerActionType.REQUEST_DUNNING_JOKER_ERROR:
      return {
        ...state,
        requestDunningJokerPayLoadError: action.payload
      };
    case RequestDunningJokerActionType.RESET_REQUEST_DUNNING_JOKER:
      return { ...state, ...initialState };
    case RequestDunningDeblockOnTrustActionType.REQUEST_DUNNING_DEBLOCK_ON_TRUST:
      return {
        ...state,
        requestDunningDeblockOnTrustPayLoad: action.payload
      };
    case RequestDunningDeblockOnTrustActionType.REQUEST_DUNNING_DEBLOCK_ON_TRUST_ERROR:
      return {
        ...state,
        requestDunningDeblockOnTrustPayLoadError: action.payload
      };
    case RequestDunningDeblockOnTrustActionType.RESET_REQUEST_DUNNING_DEBLOCK_ON_TRUST:
      return { ...state, ...initialState };
    case PaymentStateActionType.FETCH_PAYMENT_STATE:
      return {
        ...state,
        paymentState: action.payload
      };
    case PaymentStateActionType.FETCH_PAYMENT_STATE_ERROR:
      return {
        ...state,
        paymentStateError: action.payload
      };
    case OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP:
      return {
        ...state,
        orderAdditionalPaymentSlip: action.payload
      };
    case OrderAdditionalPaymentSlipActionType.ORDER_ADDITIONAL_PAYSLIP_ERROR:
      return {
        ...state,
        orderAdditionalPaymentSlipError: action.payload
      };
    case BillAnonymizationLevelActionType.BILL_ANONYMIZATION_LEVEL:
      return {
        ...state,
        billAnonymizationLevelPayload: action.payload
      };
    case BillAnonymizationLevelActionType.BILL_ANONYMIZATION_LEVEL_ERROR:
      return {
        ...state,
        billAnonymizationLevelPayloadError: action.payload
      };
    case BillAnonymizationLevelActionType.RESET_BILL_ANONYMIZATION_LEVEL:
      return { ...state, ...initialState };
    case BillDeliveryMethodActionType.BILL_DELIVERY_METHOD:
      return {
        ...state,
        billDeliveryMethodPayload: action.payload
      };
    case BillDeliveryMethodActionType.BILL_DELIVERY_METHOD_ERROR:
      return {
        ...state,
        billDeliveryMethodPayloadError: action.payload
      };
    case BillDeliveryMethodActionType.RESET_BILL_DELIVERY_METHOD:
      return { ...state, ...initialState };
    case BillsActionType.RESET_BILLS_SCREEN:
      return { ...state, ...initialState };
    case OrderBillCopyActionType.ORDER_BILL_COPY:
      return {
        ...state,
        orderBillCopyPayload: action.payload
      };
    case OrderBillCopyActionType.ORDER_BILL_COPY_ERROR:
      return {
        ...state,
        orderBillCopyPayloadError: action.payload
      };
    case OrderBillCopyActionType.RESET_ORDER_BILL_COPY:
      return { ...state, orderBillCopyPayload: null, orderBillCopyPayloadError: null };
    case RequestAccountStatementActionType.ORDER_ACCOUNT_STATEMENT:
      return {
        ...state,
        orderAccountStatementPayload: action.payload
      };
    case RequestAccountStatementActionType.ORDER_ACCOUNT_STATEMENT_ERROR:
      return {
        ...state,
        orderAccountStatementPayloadError: action.payload
      };
    case SetPaymentMethodActionType.SET_PAYMENT_METHOD:
      return {
        ...state,
        paymentMethodTypePayload: action.payload  };
    case SetPaymentMethodActionType.SET_PAYMENT_METHOD_ERROR:
        return {
          ...state,
          paymentMethodTypePayloadError: action.payload  };
    case RequestAccountStatementActionType.RESET_ORDER_ACCOUNT_STATEMENT:
      return { ...state, orderAccountStatementPayload: null, orderAccountStatementPayloadError: null };
    default:
      return state;
  }
};
