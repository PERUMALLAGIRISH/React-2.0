import { Provider }		from 'react-redux';
import * as React	from 'react';
import * as ReactDOM	from 'react-dom';

export default class ReduxDomFactory {

	constructor(store = null) {
		this.store = store;
	}

	inject(module, props = {}, target) {

		if (target) {

			ReactDOM.render(
				React.createElement(
					Provider,
					{ store: this.store },
					React.createElement(module, props),
				),
				target,
			);

		} else {
			console.warn('Target element is null or undefined. Cannot inject component');
		}
	}

	dispose(target) {
		if (target) {
			ReactDOM.unmountComponentAtNode(target);
		}
	}
}
