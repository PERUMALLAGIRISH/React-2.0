import {Action, Dispatch} from 'redux';
import AjaxService from '../../../utils/AjaxService';
declare let window: any;

export enum ChangeOwnerActionType {
  CHANGE_OWNER = 'CHANGE_OWNER',
  RESET_CHANGE_OWNER = 'RESET_CHANGE_OWNER'
};

export interface ChangeOwnerAction extends Action {
  type: ChangeOwnerActionType.CHANGE_OWNER;
  payload: any;
}

export interface ChangeOwnerResetAction extends Action {
  type: ChangeOwnerActionType.RESET_CHANGE_OWNER;
  payload: null;
}

export interface ChangeOwnerResponse {
  ChangeOwner: any;
}

export enum SendChangeOwnerActionType {
  SEND_CHANGE_OWNER = 'Send_CHANGE_OWNER',
  SEND_CHANGE_OWNER_ERROR = 'Send_CHANGE_OWNER_ERROR',
  RESET_CHANGE_OWNER = 'RESET_CHANGE_OWNER'
};

export interface SendChangeOwnerAction extends Action {
  type: SendChangeOwnerActionType.SEND_CHANGE_OWNER;
  payload: any;
}

export interface SendChangeOwnerErrorAction extends Action {
  type: SendChangeOwnerActionType.SEND_CHANGE_OWNER_ERROR;
  payload: Error;
}

export interface SendChangeOwnerResetAction extends Action {
  type: SendChangeOwnerActionType.RESET_CHANGE_OWNER;
  payload: null;
}

export interface SendChangeOwnerResponse {
  SendChangeOwner: any;
}

export const fetchChangeOwner: any = (ChangeOwner: any) => {
  let url: string = `${window.ReactApp.Env.urlHybris}users/current/site/products/${ChangeOwner.match.params.serviceSerial}/ownerchange?lang=en`;
  if (ChangeOwner && (ChangeOwner.polltoken || ChangeOwner.caseId)) {
    url = `${window.ReactApp.Env.urlHybris}users/current/site/products/${ChangeOwner.match.params.serviceSerial}/${ChangeOwner.match.params.ratePlanId}/connectioncheck?polltoken=${ChangeOwner.polltoken}&caseId=${ChangeOwner.caseId}&lang=en`;
  }
  return (dispatch: Dispatch) => {
    AjaxService.ajax(
    {
      url: url,
      method: 'GET',
    }, (response: ChangeOwnerResponse) => {
      if (response) {
        dispatch({type: ChangeOwnerActionType.CHANGE_OWNER, payload: response});
      }
    });
  };
};

export const resetChangeOwner: () => void = () => {
  return (dispatch: Dispatch) => {
    dispatch({ type: ChangeOwnerActionType.RESET_CHANGE_OWNER, payload: null });
  };
}

export const sendChangeOwner: any = (ServiceSerial: string, scheduledDate: object) => {
  console.log('demo11');
  let url: string = `${window.ReactApp.Env.urlHybris}users/current/site/products/${ServiceSerial}/ownerchange?lang=en`;
  return (dispatch: Dispatch) => {
  AjaxService.ajax(
    {
      url: url,
      method: 'POST',
      data: scheduledDate,
    }, (response: SendChangeOwnerResponse) => {
      if (response) {
        dispatch({type: SendChangeOwnerActionType.SEND_CHANGE_OWNER, payload: response});
      } else {
        dispatch({ type: SendChangeOwnerActionType.SEND_CHANGE_OWNER_ERROR, payload: response });
      }
    },
    (error: Error) => {
      dispatch({ type: SendChangeOwnerActionType.RESET_CHANGE_OWNER, payload: error });
    });
  };
};

export const resetSendChangeOwner: () => void = () => {
  return (dispatch: Dispatch) => {
    dispatch({ type: SendChangeOwnerActionType.RESET_CHANGE_OWNER, payload: null });
  };
}