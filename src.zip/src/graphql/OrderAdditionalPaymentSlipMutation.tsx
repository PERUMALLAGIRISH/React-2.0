import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const OrderAdditionalPaymentSlipMutation: DocumentNode = gql`
mutation orderAdditionalPaymentSlip($input: OrderAdditionalPaymentSlipInput) {
  orderAdditionalPaymentSlip(input: $input){
    payloadStatus
  }
}`;

export default OrderAdditionalPaymentSlipMutation;