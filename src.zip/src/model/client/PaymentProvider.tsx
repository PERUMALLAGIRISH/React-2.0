export interface PaymentProvider {
  providerUrl: string
  merchantId: string
  amount: number
  currency: string
  referenceNumber: string
  sign: string
  uppReturnMaskedCc?: string
  paymentCards: PaymentCard[]
  paymentServices: PaymentServiceType[]
}

export enum PaymentCard {
  ECA = 'ECA',
  VIS = 'VIS',
  AMX = 'AMX',
  PEF = 'PEF',
  PFC = 'PFC'
}

export enum PaymentServiceType {
  MPW = 'MPW',
  PAP = 'PAP'
}