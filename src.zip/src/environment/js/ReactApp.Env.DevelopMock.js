(function () {

	var currentUrl = location.protocol + '//' + location.hostname;
	/**
	 *
	 * ENVIRONMENT Local
	 *
	 */
	ReactApp.Env.urlShopApi = currentUrl + ':3001/rest/v2';
	ReactApp.Env.urlGql = 'https://t3-digi-as-01:10443/graphql';
	ReactApp.Env.urlHybris = 'https://t1-wwwhyb-as-01.swi.srse.net/sunrisecommercewebservices/v2/web/';


}());
