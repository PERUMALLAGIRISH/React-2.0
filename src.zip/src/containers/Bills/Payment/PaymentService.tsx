import {PaymentMethodOption} from '../../../model/client/PaymentMethodOption';
import {PaymentState} from '../../../model/client/PaymentState';

class PaymentService {
  getPaymentObject = (paymentMethod: PaymentMethodOption, paymentState: PaymentState, urls: object, saveCreditCard?: boolean, amount?: number) => {
    if (paymentMethod && paymentState && paymentState.paymentProvider) {
      let paymentData: any = {
        merchantId: paymentState.paymentProvider.merchantId,
        sign: paymentState.paymentProvider.sign,
        amount: amount ? amount : paymentState.paymentProvider.amount,
        currency: paymentState.paymentProvider.currency,
        refno: paymentState.paymentProvider.referenceNumber,
        uppWebResponseMethod: 'GET',
        uppReturnMaskedCc: paymentState.paymentProvider.uppReturnMaskedCc,
        language: 'de'
      };
      if (paymentState && paymentMethod === PaymentMethodOption.REGISTERED_CARD
        && paymentState.registeredCards && paymentState.registeredCards.length > 0) {
        const registeredCard: any = paymentState.registeredCards[0] || {};
        const registeredCardData: any = {
          aliasCC: registeredCard.aliasCc,
          expy: registeredCard.expiryYear,
          expm: registeredCard.expiryMonth,
          number: registeredCard.number
        };
        paymentData = {...paymentData, ...registeredCardData};
      }

      const useAlias: any = {'useAlias': paymentMethod === PaymentMethodOption.CREDIT_CARD && saveCreditCard};
      const registeredCard: any = paymentState && paymentState.registeredCards && paymentState.registeredCards[0] || {};
      paymentData = {...paymentData, ...useAlias};

      let paymentMethods: string | undefined;
      switch (paymentMethod) {
        case PaymentMethodOption.CREDIT_CARD:
          paymentMethods = this.encodePaymentMethods(paymentState.paymentProvider.paymentCards);
          break;
        case PaymentMethodOption.PAYMENT_SERVICE:
          paymentMethods = this.encodePaymentMethods(paymentState.paymentProvider.paymentServices);
          break;
        case PaymentMethodOption.REGISTERED_CARD:
          paymentMethods = registeredCard.paymentCard;
          break;
        default:
      }
      paymentData = {...paymentData, ...urls};
      if (paymentMethods !== undefined) {
        paymentData.paymentmethod = paymentMethods;
      }
      return paymentData;
    }
    return '';
  }

  getPaymentScriptUrl = (paymentState: PaymentState) => {
    if (paymentState && paymentState.paymentProvider) {
      return `${paymentState.paymentProvider.providerUrl}/upp/payment/js/datatrans-2.0.0.js`;
    }
    return '';
  }

  getPaymentParams = (queryUrl: string) => {
    let urlParams: any,
    match: RegExpExecArray | null;
    const search: RegExp = /([^&=]+)=?([^&]*)/g;

    urlParams = {};
    while (match = search.exec(queryUrl)) {
      urlParams[match[1]] = match[2];
    }
    return urlParams;
  }

  encodePaymentData = (data: any) => {
    return Object.keys(data).map(key => `${encodeURIComponent(key)}=${encodeURIComponent(data[key])}`).join('&');
  }

  encodePaymentMethods = (data: any) => {
    return Object.keys(data).map(key => `${encodeURIComponent(data[key])}`).join(',');
  }

  getPaymentInput = (params: any, paymentMethod: PaymentMethodOption) => {
    return {
      amount: params.amount / 100,
      paymentTransaction: {
        acqAuthorizationCode: params.acqAuthorizationCode,
        authorizationCode: params.authorizationCode,
        uppTransactionId: params.uppTransactionId,
        merchantId: params.merchantId,
        paymentCard: paymentMethod !== PaymentMethodOption.PAYMENT_SERVICE ? params.pmethod : null,
        paymentService: paymentMethod === PaymentMethodOption.PAYMENT_SERVICE ? params.pmethod : null,
        useAlias: params.useAlias,
        aliasCc: params.aliasCC,
        expiryMonth: params.expm,
        expiryYear: params.expy,
        number: params.maskedCC
      }
    };
  }
}
export const paymentService: PaymentService = new PaymentService();