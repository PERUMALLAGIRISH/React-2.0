import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const CountriesQuery: DocumentNode = gql`
query countries {
  countries {
    isocode
    name
  }
}`;

export default CountriesQuery;