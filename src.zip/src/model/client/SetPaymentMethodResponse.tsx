import { PaymentMethodTypePayload } from '../types.d';

export interface SetPaymentMethodResponse {
    setPaymentMethod: PaymentMethodTypePayload;
}