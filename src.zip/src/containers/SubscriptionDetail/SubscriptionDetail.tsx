import * as React from 'react';
import {fetchServices} from './SubscriptionDetailAction';
import {Account} from '../../model/types.d';
import {Dispatch, ActionCreatorsMapObject, bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import { History, Location } from 'history';

export interface SubscriptionDetailProps {
  account: Account;
  accountError: Error;
  fetchServices: () => void;
  location: Location;
  history: History;
}

interface SubscriptionDetailState {
  isLoading: boolean;
}

class SubscriptionDetail extends React.Component<SubscriptionDetailProps, SubscriptionDetailState> {
  constructor(props: SubscriptionDetailProps) {
    super(props);
    this.state = {
      isLoading: true
    }
  }

  static getDerivedStateFromProps(nextProps: SubscriptionDetailProps, prevState: SubscriptionDetailState): any | null {
    if ((nextProps.account || nextProps.accountError) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  componentDidMount(): void {
    const {fetchServices} = this.props;
    fetchServices();
  }

  render(): React.ReactNode {
    const {account} = this.props;
    if (account) {
      return (
        <div className='container-fluid'>
          <div className='l-center-l'>
          <div className='l-grid'>
              Subscription Detail Page
            </div>
          </div>
        </div>
      )
    } else {
      return <React.Fragment />;
    }
  }
}

const mapStateToProps: any = ({ subscriptionDetailReducer }: any) => {
  return {
    account: subscriptionDetailReducer.account,
    accountError: subscriptionDetailReducer.accountError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({fetchServices}, dispatch);
};

export default connect<SubscriptionDetailProps>(mapStateToProps, mapDispatchToProps)(SubscriptionDetail);
