import * as React from 'react';
import I18n from '../../../utils/helper/I18n';
import {SubscriptionDetailChangeOwnerConstants} from './SubscriptionDetailChangeOwnerConstants';
import DateService from '../../../utils/DateService';
import CurrencyFormatService from '../../../utils/CurrencyFormatService';
class SubscriptionDetailChangeOwnerService {
  getEligibilityErrorType = (errorType: string) => {
    const data: any = {};
    switch (errorType) {
      case SubscriptionDetailChangeOwnerConstants.PENDING_TRANSFER_CASES:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.PendingTransfer.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.PendingTransfer.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.IN_DUNNING_PROCESS:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.DunningProcess.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.DunningProcess.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.NOT_ELIGIBLE_FOR_MTV_PRODUCTS:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.NotEligibleForMtvProd.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.NotEligibleForMtvProd.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.TRANSFER_DEVICE_PLAN:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.TransferDevicePlan.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.TransferDevicePlan.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.OPEN_INVOICES_30_DAYS_PAST:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.OpenInvoices30DaysPast.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.OpenInvoices30DaysPast.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.APPLY_ETF_AMOUNT:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.ApplyEtfAmount.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.ApplyEtfAmount.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.WAIVE_OFF_ETF:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.WaiveOffEtf.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.WaiveOffEtf.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.DATA_SHARING_PRODUCT_IS_ACTIVE:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.DataSharingProductIsActive.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.DataSharingProductIsActive.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.DIFF_SUBSCRIBER_INFO:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.DiffSubscriberInfo.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.DiffSubscriberInfo.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.AMOUNT_ACCESSORIES_EXCEED_5_ITEMS:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.AmountAccessoriesExceed5Items.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.AmountAccessoriesExceed5Items.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.INVALID_SERIAL_NUMBER:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.InvalidSerialNumber.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.InvalidSerialNumber.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.SUNRISE_PROD_NOT_ALLOWED_FOR_CUSTOMER:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.SunProdNotAllowed.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.SunProdNotAllowed.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.CAN_NOT_TRANSFER_ON_SAME_SITE:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CanNotTransferOnSameSite.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CanNotTransferOnSameSite.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.CREDIT_CHECK_FAILED:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CreditCheckFailed.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CreditCheckFailed.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.MAX_SUB_REACHED:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.MaxSubsReached.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.MaxSubsReached.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.CAN_NOT_TRANSFER_BUS_TO_RES:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CanNotTransferBusToRes.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CanNotTransferBusToRes.Title');
        return data;
      case SubscriptionDetailChangeOwnerConstants.CAN_NOT_TRANSFER_RES_TO_BUS:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CanNotTransferResToBus.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.CanNotTransferResToBus.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.HALBTAX_OPTION:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.HalbtaxOption.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.HalbtaxOption.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.UNKNOWN_ERROR:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.Unknown.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.Unknown.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.UNKNOWN_WARNING:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.Unknown.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Warning.Unknown.Description');
        return data;
      case SubscriptionDetailChangeOwnerConstants.NOT_ELIGIBLE_FOR_OWNER_CHANGE:
        data.title = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.Title');
        data.description = I18n.translate('SubscriptionDetailChangeOwner.Eligibility.Error.Description');
        return data;
      default:
        data.title = '';
        data.description = '';
        return data;
      }
    }

    // const streetDetails: string = `${account.primaryAddress.streetName || null} ${account.primaryAddress.streetNumber || null}`,
    //     cityDetails: string = `${account.primaryAddress.postalCode || null} ${account.primaryAddress.town || null}`;

  getphoneNumber = (data: any) => {
    const	subscribtionData: string[] = [];
    const serviceRatePlan: any = data.serviceRatePlan;
    if (serviceRatePlan) {
      const address: any = serviceRatePlan.address;
      const	phone: string = serviceRatePlan.phoneNumber;
      if (!address || Object.keys(address).length === 0) {
        subscribtionData.push(phone);
      } else {
        const streetDetails: string = `${address.streetName || null} ${address.streetNumber || null}`;
        const cityDetails: string = `${address.postalCode || null} ${address.town || null}`;
        subscribtionData.push(streetDetails, cityDetails);
      }
    }
    return subscribtionData;
  }

  getServiceSerial = (data: any) => {
    const	serviceSerial: string = '';
    const serviceRatePlan: any = data.serviceRatePlan;
    if (serviceRatePlan) {
      return serviceRatePlan.serviceSerial;
    }
    return serviceSerial;
  }

  getOwnerEmail = (data: any) => {
    const email: string[] = [];
    const currentOwnerEmail: any = data.currentOwner;
    if (currentOwnerEmail && currentOwnerEmail.email) {
        email.push(currentOwnerEmail.email);
    }
    return email;
  }

  getCurrentOwnerAddress = (data: any) => {
    const ownerInformation: string[] = [];
    if (data) {
      const owner: any = data.currentOwner;
      const ownerdefaultAddress: any = owner.defaultAddress;
      const ownerTitleName: string = `${owner.title} ${owner.name}`;
      if (ownerTitleName) {
        ownerInformation.push(ownerTitleName);
      }
      const streetDetails: string = `${ownerdefaultAddress.streetName} ${ownerdefaultAddress.streetNumber}`;
      if (streetDetails) {
        ownerInformation.push(streetDetails);
      }
      const cityDetails: string = `${ownerdefaultAddress.postalCode} ${ownerdefaultAddress.town}`;
      if (cityDetails) {
        ownerInformation.push(cityDetails);
      }
    }
    return ownerInformation;
  }
  getCurrentOwnerBirthDate = (data: any) => {
    if (data && data.currentOwner) {
      const birthDate: string = data.currentOwner.dateOfBirth;
      return birthDate;
    }
    return '';
  }
  getSubscriptionInformation = (data: any) => {
    const subscriptionInfo: any = [];
    if (data) {
      const serviceRatePlan: any = data.serviceRatePlan;
      const ratePlans: object[] = serviceRatePlan.ratePlans;
      const contractStartDate: string = serviceRatePlan.contractStartDate;
      const contractEndDate: string = serviceRatePlan.contractEndDate;
      const installAddress: any = this.getinstallAddress(serviceRatePlan.address);
      const secondSimInfo: string [] = this.getSecondSimData(data);
      const equipmentPlan: any = this. getDevicePlanData(data);
      const subscriptionInfoLabels: string[] = [];
      const subscriptionInfoValues: string[] = [];
      const keyValueData: any = [];
      const phoneNumber: string = serviceRatePlan && serviceRatePlan.phoneNumber ? serviceRatePlan.phoneNumber : '';
      const options: any = this.getOptions(data.options);
      if (serviceRatePlan.address) {
        subscriptionInfo['SubscriptionName'] = this.getSubscriptionName(data, ratePlans, data.targetProductId);
        if (contractStartDate && contractEndDate) {
          subscriptionInfo['ContractDuration'] = <I18n code='SubscriptionDetailChangeOwner.SubscriberInformation.ContractDuration.Text' arguments={`${DateService.formatDate(contractStartDate)},${DateService.formatDate(contractEndDate)}`} argumentsSplitter=',' />
        }
        subscriptionInfo['PhoneNumber'] = phoneNumber;
      } else {
        subscriptionInfo['PhoneNumber'] = phoneNumber;
        subscriptionInfo['SubscriptionName'] = this.getSubscriptionName(data, ratePlans, data.targetProductId);
      }
      if (secondSimInfo) {
        subscriptionInfo['SecondSim'] = secondSimInfo;
      }
      if (equipmentPlan) {
        subscriptionInfo['EquipmentPlan'] = equipmentPlan;
      }
      if (options) {
        subscriptionInfo['Options'] = options;
      }
      if (installAddress.length) {
        subscriptionInfo['InstallationAddress'] = [
          installAddress,
          I18n.translate('SubscriptionDetailChangeOwner.SubscriberInformation.AddressNotification')
        ];
      }
      this.initSubscriptionInfoDataListArrays(subscriptionInfo, subscriptionInfoLabels, subscriptionInfoValues);

      for (let i = 0; i < Object.keys(subscriptionInfo).length; i++) {
        keyValueData.push({
          key: subscriptionInfoLabels[i],
          value: subscriptionInfoValues[i]
        });
      }
      return keyValueData;
    }
    return subscriptionInfo;
  }
  getinstallAddress = (installAddress: any) => {
    const	installAddressData: string[] = [];
    if (installAddress) {
        const streetDetails: string = `${installAddress.streetName || null} ${installAddress.streetNumber || null}`;
        const cityDetails: string = `${installAddress.postalCode || null} ${installAddress.town || null}`;
        installAddressData.push(streetDetails, cityDetails);
    }
    return installAddressData;
  }

  getOptions = (data: any) => {
    const options: any = data ? data : null;
    let optionNames: string[] = [];
    if (!options || !Array.isArray(options) || options.length === 0) {
      return null;
    }
    optionNames = options.map((option) => {
      const optionName: string = option.option && option.option.name ? option.option.name : '';
      const earliestDeactivation: string = option.earliestDeactivationDate ? `,
      ${I18n.translate('SubscriptionDetailChangeOwner.SubscriberInformation.MinDuration.Options')} ${DateService.formatDate(option.earliestDeactivationDate)}` : '';
      return optionName + earliestDeactivation;
    });
    return optionNames;
  }
  getSubscriptionName = (data: any, ratePlans: any, targetProductId: string) => {
    let ratePlanIds: any = [];
    const ratePlansNr: any = ratePlans.length;
    if (data.serviceFamily.toLocaleUpperCase() === SubscriptionDetailChangeOwnerConstants.MOBILE || targetProductId.toUpperCase() === SubscriptionDetailChangeOwnerConstants.SUNRISE_HOME_UNLIMITED) {
      return targetProductId;
    }
    if (!ratePlans || ratePlansNr === 0 || !(ratePlans instanceof Array)) { return ''; }
    // ratePlanIds = `${targetProductId} - `;
    ratePlans.forEach((plan, index) => {
      ratePlanIds += plan.ratePlanId;
      if (ratePlansNr > 1 && index !== ratePlansNr - 1) {
        ratePlanIds += ', ';
      }
    });
    return ratePlanIds;
  }

  getSecondSimData = (data: any) => {
    const secondSimCard: any = data.simCardList && data.simCardList.length > 0 ? data.simCardList[0] : null;
    const secondSimCardProduct: any = secondSimCard && secondSimCard.ratePlans && secondSimCard.ratePlans.length > 0 ? secondSimCard.ratePlans[0] : null;
    if (!secondSimCardProduct) { return ''; }
    return secondSimCardProduct.ratePlanId ? secondSimCardProduct.ratePlanId : (secondSimCardProduct.product ? (secondSimCardProduct.product.oneLineTitle || secondSimCardProduct.product.name) : secondSimCardProduct.phoneNumber || '');
  }
  getDevicePlanData = (data: any) => {
    const devicePlan: any = data && data.devicePlan ? data.devicePlan : '';
    if (!devicePlan) { return ''; }
    const remainingBalanceDevicePlan: any = [];
    const devicePlanStartEndDate: any = [];
    return [
      <I18n code='SubscriptionDetailChangeOwner.SubscriberInformation.DevicePlan.RemainingBalance' arguments={...remainingBalanceDevicePlan(devicePlan.outstandingMonths, CurrencyFormatService.getCurrencyFormat(devicePlan.monthlyInstallment), CurrencyFormatService.getCurrencyFormat(devicePlan.outstandingAmount))} argumentsSplitter={','}/>,
      <I18n code='SubscriptionDetailChangeOwner.SubscriberInformation.DevicePlan.Duration' arguments={...devicePlanStartEndDate(DateService.formatDate(devicePlan.contractStartDate), DateService.formatDate(devicePlan.contractEndDate) )} argumentsSplitter={','}/>
    ];
  }
  initSubscriptionInfoDataListArrays = (subscriptionInfo: any, subscriptionInfoLabels: any, subscriptionInfoValues: string[]) => {
    if (!(subscriptionInfo && subscriptionInfoLabels && subscriptionInfoValues)) { return; }
    // subscriptionInfo.forEach((element: any, key: string) => {
    //   subscriptionInfoLabels.push(<I18n code='SubscriptionDetailChangeOwner.SubscriberInformation.Options' />);
    //   if (subscriptionInfo[key]) {
    //     console.log('key', key);
    //     // subscriptionInfo[key] = subscriptionInfo[key].join(',<br />');
    //   }
    //   subscriptionInfoValues.push(subscriptionInfo[key]);
    // });
    Object.keys(subscriptionInfo).map((key) => {
      subscriptionInfoLabels.push(<I18n code={`SubscriptionDetailChangeOwner.SubscriberInformation.${key}`} />);
      if (subscriptionInfo[key] instanceof Array) {
            subscriptionInfo[key] = subscriptionInfo[key].join(',');
        }
      subscriptionInfoValues.push(subscriptionInfo[key]);
    });
  };
}

export default new SubscriptionDetailChangeOwnerService();