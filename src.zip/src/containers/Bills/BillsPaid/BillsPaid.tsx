import * as React from 'react';
import {BillsInvoiceButtons} from '../BillsInvoiceButtons/BillsInvoiceButtons';
import CurrencyFormatService  from '../../../utils/CurrencyFormatService';
import I18n from '../../../utils/helper/I18n';
import {OrderBillCopyPayload} from '../../../model/types.d';

export interface BillsPaidProps {
  id: string;
  billDate: string;
  amount: number;
  digitalInvoiceUrl: string;
  downloadUrl: string;
  orderBillCopyPayload: OrderBillCopyPayload;
  orderBillCopyPayloadError: Error | null;
  imgPaid: string | undefined;
  setOrderBillCopy: () => void;
  resetOrderBillCopy: () => void;
}
interface BillsPaidState {
  showInvoiceButtons: boolean;
}

export class BillsPaid extends React.Component<BillsPaidProps, BillsPaidState> {
  constructor(props: BillsPaidProps) {
    super(props);
    this.state = {
      showInvoiceButtons: false
    }
  }

  showInvoiceButtons = (event: React.MouseEvent<HTMLImageElement, MouseEvent>): void => {
    const {showInvoiceButtons} = this.state;
    event.preventDefault();
    this.setState({
      showInvoiceButtons: !showInvoiceButtons
    });
  }

  render(): React.ReactNode {
    const {id, amount, billDate, digitalInvoiceUrl, downloadUrl, setOrderBillCopy, orderBillCopyPayloadError, orderBillCopyPayload, resetOrderBillCopy, imgPaid} = this.props;
    const {showInvoiceButtons} = this.state;
    return (
      <div className='l-col l-1of2 l-1of1-mobile'>
        <div className='content-box--container no-bottom-margin'>
          <div className='content-box smaller_vertical_padding no-bottom-margin'>
            <div className='payed_bill__top_row'>
              <div className='payed_bill__top_row--already-payed'>
                <img src={imgPaid}/>
                <div className='text-small t-strong inline'>
                  {I18n.translate('BillsPaid.AlreadyPay.Label')}
                </div>
              </div>
              <div className='text-right'>
                <div className='text-small pale-grey t-strong-slight inline no-bottom-margin'>
                  {I18n.translate('BillsPaid.BillingDate.Label')}
                </div> <div className='text-small grey-brown t-strong-slight inline'>
                  {billDate}
                </div>
              </div>
            </div>
            <div className='bills-price bills-price--inactive centered-text'>
              {CurrencyFormatService.getCurrencyFormat(amount)}
              </div>
            <div className='payed_bill__bottom_row'>
              <div>
                <div className='text-small pale-grey t-strong-slight inline no-bottom-margin'>
                  {I18n.translate('BillsPaid.BillNo.Label')}
                </div> <div className='text-small grey-brown t-strong-slight inline'>
                  {id}
                </div>
              </div>
              <img className='vert-upside-down' src={'/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/arrow-down.svg'} onClick={(e: React.MouseEvent<HTMLImageElement, MouseEvent>) => this.showInvoiceButtons(e)}/>
            </div>
          </div>
          {showInvoiceButtons ?
            <BillsInvoiceButtons
              digitalInvoiceUrl= {digitalInvoiceUrl}
              downloadUrl= {downloadUrl}
              id = {id}
              setOrderBillCopy = {setOrderBillCopy}
              orderBillCopyPayloadError = {orderBillCopyPayloadError}
              orderBillCopyPayload = {orderBillCopyPayload}
              resetOrderBillCopy = {resetOrderBillCopy}
            />  : null
          }
        </div>
      </div>
    );
  }
}
