import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const SendNameChangeInfoMutation: DocumentNode = gql`
  mutation sendNameChangeInfo {
    sendNameChangeInfo {
      payloadStatus
    }
  }
`;

export default SendNameChangeInfoMutation;