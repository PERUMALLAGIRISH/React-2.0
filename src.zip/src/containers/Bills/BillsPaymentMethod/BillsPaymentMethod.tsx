import * as React from 'react';
import {connect} from 'react-redux';
import {Button} from '../../../components/Form/Button/Button';
import {Input} from '../../../components/Form/Input/Input';
import {Success} from '../../../components/Success/Success';
import {Account, PaymentMethodTypeInput, PaymentMethodType, PayloadStatus, PaymentMethodTypePayload, DirectDebitFormFields, BillInfo, Optional, BillSettings} from '../../../model/types.d';
import {ActionCreatorsMapObject, Dispatch, bindActionCreators} from 'redux';
import {fetchBillsInfo, setPaymentMethodRequest} from '../BillsAction';
import {Popup} from '../../../components/Popup/Popup';
import DataLanguageService from '../../../utils/DataLanguageService';
import ValidationService from '../../../utils/ValidationService';
import {FormErrors} from '../../../components/Form/FormErrors/FormErrors';
import I18n from '../../../utils/helper/I18n';
import {BillsPaymentMethodConstants} from '../BillsConstants';
import {BillsRoutes} from '../BillsRoutes.enum';
import {History} from 'history';
import { Loader } from '../../../components/Loader/Loader';
import { Radio } from '../../../components/Radio/Radio';
declare let window: any;

export interface BillsPaymentMethodProps {
  paymentMethodTypePayload: PaymentMethodTypePayload;
  account: Account;
  fetchBillsInfo: () => void;
  paymentMethodTypePayloadError: Error | null;
  setPaymentMethodRequest: (updatePaymentMethodInput: PaymentMethodTypeInput) => any;
  history: History;
}

interface BillsPaymentMethodState {
  disabled: boolean;
  formStatus: boolean;
  paymentSuccess: boolean;
  directDebitFormFields: DirectDebitFormFields;
  formErrors: string[],
  paymentMethod: string,
  renderLSVForm: boolean,
  step: number,
  isHelpPopup: boolean,
  isTooltipPopup: boolean,
  selectedPopup: string;
  isLoading: boolean;
}

class BillsPaymentMethod extends React.Component<BillsPaymentMethodProps, BillsPaymentMethodState> {
  constructor(props: BillsPaymentMethodProps) {
    super(props);
    this.state = {
      disabled: true,
      formStatus: false,
      paymentSuccess: false,
      directDebitFormFields: {
        iban: '',
        bankName: '',
        nameHolder: '',
        city: '',
        zipCode: ''
      },
      formErrors: [],
      paymentMethod: '',
      renderLSVForm: false,
      step: 1,
      isHelpPopup: false,
      isTooltipPopup: false,
      selectedPopup: '',
      isLoading: true
    }
  }

  static getDerivedStateFromProps(nextProps: BillsPaymentMethodProps, prevState: BillsPaymentMethodState): any | null {
    if ((nextProps.paymentMethodTypePayload || nextProps.paymentMethodTypePayloadError || !prevState.paymentSuccess) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  componentDidMount(): void {
    const {fetchBillsInfo, account} = this.props;
    if (!account) {
      fetchBillsInfo();
    }
    window.scrollTo(0, 0);
  }

  /* render Spineer if isLoading = true*/
  renderLoader(): JSX.Element | null {
    const {isLoading} = this.state;
    if (isLoading) {
      return (
        <Loader />
      );
    }
    return null;
  }

  enablePaySlip = (id: string): void => {
    if (PaymentMethodType.DIRECT_DEBIT === id) {
      this.setState({
        disabled: true,
        formStatus: true,
        paymentMethod: PaymentMethodType.DIRECT_DEBIT
      });
    } else if (PaymentMethodType.PAY_SLIP === id) {
      this.setState({
        disabled: false,
        formStatus: false,
        paymentMethod: PaymentMethodType.PAY_SLIP
      });
    } else if (PaymentMethodType.EBILL === id) {
      this.setState({
        disabled: false,
        formStatus: false,
        paymentMethod: PaymentMethodType.EBILL
      });
    }
  }

  handleHelpPopup(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
    const {isHelpPopup} = this.state;
    this.setState({
      isHelpPopup: !isHelpPopup
    });
  }

  renderXmlPopup = (): JSX.Element => {
    return (
      <Popup
        title =  {I18n.translate('BillsPaymentMethod.EBillPopup.Title')}
        data = {[I18n.translate('BillsPaymentMethod.EBillPopup.Description')]}
        buttonLabel = {I18n.translate('BillsPaymentMethod.Popup.Button.Close')}
        onClick = {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.handleHelpPopup(e)}
      />);
  }

  handleDebitCardValue = (fieldName: any, value: string): void => {
    this.setState(prevState => ({ directDebitFormFields :
      {...prevState.directDebitFormFields, [fieldName]: value
      }
    } as Pick<BillsPaymentMethodState, keyof BillsPaymentMethodState>));
    this.setState({[fieldName] : value} as Pick<BillsPaymentMethodState, keyof BillsPaymentMethodState>);
  }

  getPopupData = (name: string) => {
    const data: any = {};
    switch (name) {
      case BillsPaymentMethodConstants.IBAN:
        data.title = I18n.translate('BillsPaymentMethod.Tooltip.Iban.Title');
        data.text = I18n.translate('BillsPaymentMethod.Tooltip.Iban.Validation.Text');
        data.buttonLabel = I18n.translate('BillsPaymentMethod.Tooltip.Iban.Button.Ok');
        return data;
      case BillsPaymentMethodConstants.BANKNAME:
        data.title = I18n.translate('BillsPaymentMethod.Tooltip.Bank.Title');
        data.text = I18n.translate('BillsPaymentMethod.Tooltip.Bank.Validation.Text');
        data.buttonLabel = I18n.translate('BillsPaymentMethod.Tooltip.Bank.Button.Ok');
        return data;
      case BillsPaymentMethodConstants.NAMEHOLDER:
        data.title = I18n.translate('BillsPaymentMethod.Tooltip.AccountHolder.Title');
        data.text = I18n.translate('BillsPaymentMethod.Tooltip.AccountHolder.Validation.Text');
        data.buttonLabel = I18n.translate('BillsPaymentMethod.Tooltip.AccountHolder.Button.Ok');
        return data;
      case BillsPaymentMethodConstants.ZIPCODE:
        data.title = I18n.translate('BillsPaymentMethod.Tooltip.ZipCode.Title');
        data.text = I18n.translate('BillsPaymentMethod.Tooltip.ZipCode.Validation.Text');
        data.buttonLabel = I18n.translate('BillsPaymentMethod.Tooltip.ZipCode.Button.Ok');
        return data;
      case BillsPaymentMethodConstants.CITY:
        data.title = I18n.translate('BillsPaymentMethod.Tooltip.City.Title');
        data.text = I18n.translate('BillsPaymentMethod.Tooltip.City.Validation.Text');
        data.buttonLabel = I18n.translate('BillsPaymentMethod.Tooltip.City.Button.Ok');
        return data;
      default:
        data.title = '';
        data.text = '';
        data.buttonLabel = I18n.translate('BillsPaymentMethod.Tooltip.City.Button.Ok');
        return data;
    }
  }

  displayHideTooltipPopup(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
    const element: HTMLButtonElement = event.currentTarget as HTMLButtonElement;
    event.persist();
    const {isTooltipPopup} = this.state;
    this.setState({
      isTooltipPopup: !isTooltipPopup,
      selectedPopup: element.id
    });
  }

  renderTooltipPopup = (): JSX.Element => {
    const {selectedPopup} = this.state;
    const data: any = this.getPopupData(selectedPopup);
    return (
      <Popup
        title = {data.title}
        data = {[data.text]}
        buttonLabel = {data.buttonLabel}
        onClick = { (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayHideTooltipPopup(e) }
      />
    );
  }

  renderDebitCardForm(): JSX.Element | null {
    const {directDebitFormFields, formStatus} = this.state;
    if (formStatus) {
      return (
        <React.Fragment>
          <div className='vertical_spacer x32'></div>
          <div className='form'>
            {this.onValidationError()}
            <div className='form-item item-tooltip'>
              <Input
                type = {'text'}
                name = {BillsPaymentMethodConstants.IBAN}
                value = {directDebitFormFields.iban || ''}
                className = 'form_input'
                labelClassName = {'form__label form__text_field-label form__label__text text-left'}
                label = {I18n.translate('BillsPaymentMethod.DirectDebit.Iban.Label')}
                tooltipId = {'iban'}
                onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayHideTooltipPopup(e)}
                onChange = {this.handleDebitCardValue}
              />
            </div>
            <div className='form-item'>
              <Input
                type = {'text'}
                name = {BillsPaymentMethodConstants.BANKNAME}
                value = {directDebitFormFields.bankName || ''}
                className = 'form_input'
                labelClassName = {'form__label form__text_field-label form__label__text text-left'}
                label = {I18n.translate('BillsPaymentMethod.DirectDebit.Bank.Label')}
                tooltipId = {BillsPaymentMethodConstants.BANKNAME}
                onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayHideTooltipPopup(e)}
                onChange = {this.handleDebitCardValue}
              />
            </div>
            <div className='form-item item-tooltip'>
              <Input
                type = {'text'}
                name = {BillsPaymentMethodConstants.NAMEHOLDER}
                value = {directDebitFormFields.nameHolder || ''}
                className = 'form_input'
                labelClassName = {'form__label form__text_field-label form__label__text text-left'}
                label = {I18n.translate('BillsPaymentMethod.DirectDebit.AccountHolder.Label')}
                tooltipId = {BillsPaymentMethodConstants.NAMEHOLDER}
                onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayHideTooltipPopup(e)}
                onChange = {this.handleDebitCardValue}
              />
            </div>
            <div className='form-row'>
              <div className='form-item l-formcol-2of6'>
                <Input
                  type = {'number'}
                  name = {BillsPaymentMethodConstants.ZIPCODE}
                  value = {directDebitFormFields.zipCode || ''}
                  className = 'form_input'
                  labelClassName = {'form__label form__text_field-label form__label__text text-left'}
                  label = {I18n.translate('BillsPaymentMethod.DirectDebit.ZipCode.Label')}
                  tooltipId = {BillsPaymentMethodConstants.ZIPCODE}
                  onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayHideTooltipPopup(e)}
                  onChange = {this.handleDebitCardValue}
                />
              </div>
              <div className='form-item l-formcol-4of6'>
                <Input
                  type = {'text'}
                  name = {BillsPaymentMethodConstants.CITY}
                  value = {directDebitFormFields.city || ''}
                  className = 'form_input'
                  labelClassName = {'form__label form__text_field-label form__label__text text-left'}
                  label = {I18n.translate('BillsPaymentMethod.DirectDebit.City.Label')}
                  tooltipId = {BillsPaymentMethodConstants.CITY}
                  onClick= {(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayHideTooltipPopup(e)}
                  onChange = {this.handleDebitCardValue}
                />
              </div>
            </div>
          </div>
        </React.Fragment>
      );
    }
    return null;
  }

  onPaymentSuccess(): JSX.Element | null {
    const {paymentMethodTypePayloadError, paymentMethodTypePayload} = this.props;
    const {paymentSuccess} = this.state;
    let label: string = '';
    let title: string = '';
    if (paymentMethodTypePayloadError || (paymentMethodTypePayload && paymentMethodTypePayload.payloadStatus === PayloadStatus.NOK)) {
      label = I18n.translate('BillsPaymentMethod.PaymentMethod.Error.Label');
      title = I18n.translate('BillsPaymentMethod.PaymentMethod.Error.Title');
    } else if (paymentMethodTypePayload && paymentMethodTypePayload.payloadStatus === PayloadStatus.OK) {
      label = I18n.translate('BillsPaymentMethod.PaymentMethod.Success.Label');
      title = I18n.translate('BillsPaymentMethod.PaymentMethod.Success.Title');
    }
    if (paymentSuccess) {
      return (
        <Success
          imageSource={'/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/overall_success_mail.png'}
          heading = {title}
          text = {label}
          button = {I18n.translate('BillsPaymentMethod.BackToProfile.Button.Label')}
          href = {'#/'}
        />
      );
    }
    return null;
  }

  handleSave(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    const {setPaymentMethodRequest, history, account} = this.props;
    const {paymentMethod} = this.state;
    const updatePaymentMethodInput: any = {} || null;
    updatePaymentMethodInput.paymentMethodType = paymentMethod;
    const billInfo: Optional<BillInfo> = account && account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const defaultPaymentMethod: any =  billSettings && billSettings.paymentMethod ;
    const setPaymentMethodInput: PaymentMethodTypeInput = {
      paymentMethodType: updatePaymentMethodInput.paymentMethodType || defaultPaymentMethod
    }

    if (paymentMethod !== PaymentMethodType.DIRECT_DEBIT) {
      this.setState({ paymentSuccess: true, isLoading: true});
      setPaymentMethodRequest(setPaymentMethodInput);
    } else {
      event.preventDefault();
      history.push({
        pathname: BillsRoutes.BILLS_HOME
      });
    }

  }

  onValidationError(): JSX.Element | null {
    const {formErrors} = this.state;
    if (Object.keys(formErrors).length) {
      return (
        <FormErrors formErrors={formErrors} />
      );
    }
    return null;
  }

  handleNext(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    const {directDebitFormFields, formErrors, paymentMethod} = this.state;
    if (paymentMethod === PaymentMethodType.DIRECT_DEBIT) {
      if (directDebitFormFields.iban && ValidationService.isValidIBANNumber(directDebitFormFields.iban)) {
        this.setState({
          renderLSVForm: true,
          paymentSuccess: false
        });
      } else {
        const fieldValidationErrors: any = formErrors;
        fieldValidationErrors.iban = I18n.translate('BillsPaymentMethod.Iban.Error.Text')
        this.setState({
          formErrors: fieldValidationErrors
        });
      }
    }
  }

  downloadPdf(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    const {iban, bankName, nameHolder, zipCode, city} = this.state.directDebitFormFields;
    let downloadUrl: string = `${window.ReactApp.Env.urlShopApi}${BillsPaymentMethodConstants.DOWNLOAD_URL}`;
    downloadUrl = `${downloadUrl}?name=${bankName}&zip=${zipCode}&city=${city}&iban=${iban}&accountOwner=${nameHolder}&lang=${DataLanguageService.getLanguageCode()}`;
    window.open(downloadUrl, '_blank');
  }

  renderSaveButton(): JSX.Element {
    const {directDebitFormFields, paymentMethod} = this.state;
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account && account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const defaultPaymentMethod: any =  billSettings && billSettings.paymentMethod ;
    let buttonDisabled: boolean = true;
    if ((directDebitFormFields.iban &&
      directDebitFormFields.bankName &&
      directDebitFormFields.nameHolder &&
      directDebitFormFields.zipCode &&
      directDebitFormFields.city) || defaultPaymentMethod !== PaymentMethodType.DIRECT_DEBIT) {
      buttonDisabled = false;
    }
    return (
      <Button
        className= {buttonDisabled ? 'button extra_pale extra_wide full_width_on_mobile' : 'button extra_wide full_width_on_mobile'}
        handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => paymentMethod === PaymentMethodType.DIRECT_DEBIT ?  this.handleNext(e) : this.handleSave(e)}
        label = {paymentMethod === PaymentMethodType.DIRECT_DEBIT ? I18n.translate('BillsPaymentMethod.Next.Button.Label') : I18n.translate('BillsPaymentMethod.Save.Button.Label')}
        disabled = {buttonDisabled}
      />
    );
  }

  handleCancel(event: React.MouseEvent<HTMLButtonElement>): void {
    const {history} = this.props;
    event.preventDefault();
    history.push({
      pathname: BillsRoutes.BILLS_HOME
    });
  }

  handleBack(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    this.setState({
      renderLSVForm: false,
      paymentSuccess: false,
      formStatus: false
    });
  }

  renderPaymentProgressBar(): JSX.Element | null {
    const {paymentSuccess, renderLSVForm, paymentMethod} = this.state;
    if (!paymentSuccess) {
      return (
        <div className='progress_tracker centered-text'>
          <div className={`inline_progress_sign progress_step_number--${!renderLSVForm ? 'mobile-' : ''}small progress_step_sign  progress_tracker__break_words`}>
            <div className='progress_step_number'>
              1
            </div>
            <div className='progress_step_title text-small bold width-auto'>
              {I18n.translate('BillsPaymentMethod.PaymentMethod.Progress.Title')}
            </div>
          </div>
          {paymentMethod === PaymentMethodType.DIRECT_DEBIT ?
            <React.Fragment>
              <div className='progress_tracker__dash'></div>
              <div className={`inline_progress_sign progress_step_number--${renderLSVForm ? 'mobile-' : ''}small progress_step_sign progress_tracker__break_words`}>
                <div className='progress_step_number'>
                  2
                </div>
                <div className='progress_step_title text-small bold width-auto'>
                {I18n.translate('BillsPaymentMethod.LSVForm.Label')}
                </div>
              </div>
            </React.Fragment> : null }
        </div>
      );
    }
    return null;
  }

  renderLSVForm(): JSX.Element | null {
    const {paymentSuccess, renderLSVForm} = this.state;
    const postMailingAddressContent: any = {__html : I18n.translate('BillsPaymentMethod.PostMailingAddress.Content.Text')};
    if (renderLSVForm && !paymentSuccess) {
      return (
        <React.Fragment>
          <div className='title-large no-top-margin'>
              {I18n.translate('BillsPaymentMethod.LSVForm.Title')}
            </div>
            <div className='centered-text text-small extra_margin'>
              {I18n.translate('BillsPaymentMethod.LSVForm.Description')}
            </div>
            <div className='l-flexbox-row'>
              <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
                <div className='content-box'>
                  <div className='form'>
                    <div className='form-item'>
                      <div className='form__label'>
                      {I18n.translate('BillsPaymentMethod.PostMailingAddress.Title')}
                      </div>
                      <div className='form__text' dangerouslySetInnerHTML={postMailingAddressContent}>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
                <div className='content-box'>
                  <div className='form'>
                    <div className='form-item'>
                      <div className='form__label'>
                      {I18n.translate('BillsPaymentMethod.BankMailingAddress.Title')}
                      </div>
                      <div className='form__text'>
                      {I18n.translate('BillsPaymentMethod.BankMailingAddress.Content.Text')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='vertical_spacer x16'></div>
            <div className='centered-text'>
              <Button
                className= {'button full_width_on_mobile'}
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) =>
                  this.downloadPdf(e)}
                label = {I18n.translate('BillsPaymentMethod.DownloadLSV.Button.Label')}
              />
            </div>
            <div className='vertical_spacer x16'></div>
            <div className='centered-text text-small extra_margin'>
            {I18n.translate('BillsPaymentMethod.DirectDebit.SigningUp.Description')}
            </div>
            <div className='form-item'>
              <div className='form-item__button full_width_on_mobile'>
                <Button
                  className= {'button extra_wide full_width_on_mobile transparent_background'}
                  handleClick= {(e: React.MouseEvent<HTMLButtonElement>) =>
                    this.handleBack(e)}
                  label = {I18n.translate('BillsPaymentMethod.Back.Button.Label')}
                />
                <Button
                  className= {'button extra_wide full_width_on_mobile'}
                  handleClick= {(e: React.MouseEvent<HTMLButtonElement>) =>
                    this.handleSave(e)}
                  label = {I18n.translate('BillsPaymentMethod.Done.Button.Label')}
                />
              </div>
            </div>
          </React.Fragment>
      )
    }
    return null;
  }
  renderPaymentMethod(): JSX.Element | null {
    const {paymentSuccess, renderLSVForm, isTooltipPopup, paymentMethod} = this.state;
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account && account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    const defaultPaymentMethod: any = paymentMethod === '' ? billSettings && billSettings.paymentMethod : paymentMethod;
    if (!paymentSuccess && !renderLSVForm) {
      return (
        <React.Fragment>
          <h2 className='title-large'>
            {I18n.translate('BillsPaymentMethod.PaymentMethod.Title')}
          </h2>
          <div className='text-small centered-text'>
          {I18n.translate('BillsPaymentMethod.PaymentMethod.Content.Text')}
          </div>
          <div className='vertical_spacer x8'></div>
          {isTooltipPopup && this.renderTooltipPopup()}
          <div className='product_item'>
            <div className='no-right-margin p-flex-column p-flex-justify-center p-flexbox product_item__content'>
              <div>
                <Radio
                  id= {'bills_payment_method_selection_1'}
                  name= {'bills_payment_method_selection'}
                  htmlFor= {'bills_payment_method_selection_1'}
                  onChange= { (e: React.ChangeEvent<HTMLInputElement>) => this.enablePaySlip(PaymentMethodType.PAY_SLIP) }
                  value= {PaymentMethodType.PAY_SLIP}
                  checked = {defaultPaymentMethod === PaymentMethodType.PAY_SLIP}
                  disabled={defaultPaymentMethod === PaymentMethodType.EBILL ? true : false}
                />
                <label className='form_radio_label' htmlFor='bills_payment_method_selection_1' >
                  <div className='form__label no-bottom-margin'>
                  {I18n.translate('BillsPaymentMethod.PaymentMethod.PayInSlip.Label')}
                  </div>
                </label>
              </div>
            </div>
            <div className='product_item__price_2'>
              <div className='product_item__price_string'></div>
            </div>
          </div>
          <div className='product_item product_item__stiched_bellow'>
            <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
              <div>
                  <Radio
                    id= {'bills_payment_method_selection_2'}
                    name= {'bills_payment_method_selection'}
                    htmlFor= {'bills_payment_method_selection_2'}
                    onChange= { (e: React.ChangeEvent<HTMLInputElement>) => this.enablePaySlip(PaymentMethodType.DIRECT_DEBIT) }
                    value= {PaymentMethodType.DIRECT_DEBIT}
                    checked = {defaultPaymentMethod === PaymentMethodType.DIRECT_DEBIT}
                    disabled={defaultPaymentMethod === PaymentMethodType.EBILL ? true : false}
                  />
                  <label className='form_radio_label' htmlFor='bills_payment_method_selection_2' >
                    <div className='text-s-14px t-bold text-left'>
                      <span className='margin-right-16'>
                        {I18n.translate('BillsPaymentMethod.PaymentMethod.DirectDebit.Label')}
                      </span>
                      <span className='soft_blue inline'>
                        {I18n.translate('BillsPaymentMethod.PaymentMethod.SunriseRecommends.Label')}
                      </span>
                    </div>
                  </label>
                {this.renderDebitCardForm()}
              </div>
            </div>
            <div className='product_item__price_2'>
              <div className='product_item__price_string'></div>
            </div>
          </div>
          <div className='product_item product_item__stiched_bellow'>
            <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
                  <Radio
                    id= {'bills_payment_method_selection_3'}
                    name= {'bills_payment_method_selection'}
                    htmlFor= {'bills_payment_method_selection_3'}
                    onChange= { (e: React.ChangeEvent<HTMLInputElement>) => this.enablePaySlip(PaymentMethodType.EBILL) }
                    value= {PaymentMethodType.EBILL}
                    checked = {defaultPaymentMethod === PaymentMethodType.EBILL}
                    disabled={defaultPaymentMethod === PaymentMethodType.EBILL ? false : true}
                  />

                  <label className='form_radio_label' htmlFor='bills_payment_method_selection_3'>
                    <div className='text-s-14px t-bold text-left'>
                      <span className='very-light-pink'>
                        {I18n.translate('BillsPaymentMethod.PaymentMethod.Ebill.Label')}
                      </span>
                      <span className='margin-left-16 italic black margin-right-16'>
                        {I18n.translate('BillsPaymentMethod.PaymentMethod.eBill.Title')}
                      </span>
                      <span className='soft_blue inline'>
                        {I18n.translate('BillsPaymentMethod.PaymentMethod.SunriseRecommends.Label')}
                      </span>
                    </div>
                  </label>
              <div className='vertical_spacer x16'></div>
              <div className='p-flexbox margin-left-50'>
                <div className='text-s-14px dark-grey padding-right-48'>
                  {I18n.translate('BillsPaymentMethod.PaymentMethod.Ebilling.SingUp.Text')}
                </div>
                <div className='text-right'>
                  <Button
                    className= 'button button__no-responsive-arrow--mobile-right cta-button extra_wide'
                    handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.handleHelpPopup(e)}
                    label = {I18n.translate('BillsPaymentMethod.PaymentMethod.Help.Button.Label')}
                  />
                </div>
              </div>
              <div className='vertical_spacer x16'></div>
            </div>
            <div className='product_item__price_2'>
              <div className='product_item__price_string'></div>
            </div>
          </div>
          <div className='form-item'>
            <div className='form-item__button full_width_on_mobile'>
              <Button
                className= 'button full_width_on_mobile transparent_background'
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.handleCancel(e)}
                label = {I18n.translate('BillsPaymentMethod.PaymentMethod.Cancel.Button.Label')}
              />
              {this.renderSaveButton()}
            </div>
          </div>
        </React.Fragment>
      )
    }
    return null;
  }

  render(): React.ReactNode {
    const {isHelpPopup} = this.state;
    return (
      <div className='l-center-l'>
        <div className='l-grid'>
          <div className='l-col l-1of1'>
            <div className='content-box screen-pane bigger_horizontal_padding'>
              {isHelpPopup ? this.renderXmlPopup() : null}
              {this.renderLoader()}
              {this.onPaymentSuccess()}
              {this.renderPaymentProgressBar()}
              {this.renderPaymentMethod()}
              {this.renderLSVForm()}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps: any = ({ billsReducer }: any) => {
  return {
    account: billsReducer.account,
    paymentMethodTypePayload:  billsReducer.paymentMethodTypePayload,
    paymentMethodTypePayloadError: billsReducer.paymentMethodTypePayloadError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({ fetchBillsInfo, setPaymentMethodRequest }, dispatch);
};

export default connect<BillsPaymentMethodProps>(mapStateToProps, mapDispatchToProps)(BillsPaymentMethod);
