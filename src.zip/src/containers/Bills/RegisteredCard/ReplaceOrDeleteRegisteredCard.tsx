import * as React from 'react';
import {Loader} from '../../../components/Loader/Loader';
import {Button} from '../../../components/Form/Button/Button';
import {DeleteRegisteredCardPayload, PayloadStatus, Optional} from '../../../model/types.d';
import {RegisteredCard} from '../../../model/client/RegisteredCard';
import I18n from '../../../utils/helper/I18n';

interface ReplaceOrDeleteRegisteredCardProps {
  step: number;
  registeredCard: Optional<RegisteredCard>;
  deleteRegisteredCard: DeleteRegisteredCardPayload | null;
  deleteRegisteredCardError: Error | null;
  deleteRegisteredCardReset: () => void;
  onClickCancel(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void;
  handleConfirmDeleteRegisteredCardClick(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void;
  handleReplaceRegisteredCardClick(event: React.MouseEvent<HTMLButtonElement>): void;
  handleDeleteRegisteredCardClick(event: React.MouseEvent<HTMLButtonElement>): void;
}

interface ReplaceOrDeleteRegisteredCardState {
}

class ReplaceOrDeleteRegisteredCard extends React.Component<ReplaceOrDeleteRegisteredCardProps, ReplaceOrDeleteRegisteredCardState> {
  constructor(props: ReplaceOrDeleteRegisteredCardProps) {
    super(props);
  }

  componentWillUnmount(): void {
    const {deleteRegisteredCardReset} = this.props;
    deleteRegisteredCardReset();
  }

  renderReplaceOrDeleteRegisterdCardOverlay(): JSX.Element {
    const {handleReplaceRegisteredCardClick, handleDeleteRegisteredCardClick} = this.props;
    return (
      <React.Fragment>
        <div className='page-title_medium--red font-s-24px t-bold--mobile text-width-20rem'>
          {I18n.translate('Registeredcard.Replace.Text')}
        </div>
        <div className='l-flexbox-row l-flexbox-row--centered'>
          <Button
            className = {'button extra_wide full_width_on_mobile'}
            handleClick = {handleReplaceRegisteredCardClick}
            label = {I18n.translate('Registeredcard.Replace.Label')}
          />
          <Button
            className = {'button extra_wide full_width_on_mobile'}
            handleClick = {handleDeleteRegisteredCardClick}
            label = {I18n.translate('Registeredcard.Delete.Button.Label')}
          />
        </div>
      </React.Fragment>
    );
  }

  renderSuccessOrErrorOverlay(): JSX.Element {
    const {deleteRegisteredCard, deleteRegisteredCardError, onClickCancel, step} = this.props;
    if (deleteRegisteredCard === null && deleteRegisteredCardError === null && step === 2) {
      return (<Loader />);
    }
    return (
      <React.Fragment>
        <div className='popup-message-box'>
          <img src='../../img/new/overall_success_mail.png' />
          <div className='title-middle--grey font-s-24px t-bold--mobile text-width-20rem'>
            {deleteRegisteredCard && deleteRegisteredCard.payloadStatus && deleteRegisteredCard.payloadStatus === PayloadStatus.OK ? I18n.translate('Registeredcard.DeleteCard.Success.Title') :
            ((deleteRegisteredCardError && deleteRegisteredCardError !== null) ||
            (deleteRegisteredCard && deleteRegisteredCard.payloadStatus && deleteRegisteredCard.payloadStatus === PayloadStatus.NOK)) ? I18n.translate('Registeredcard.DeleteCard.Text') : ''}
          </div>
          <div className='vertical_spacer x16'></div>
          <div className='centered-text'>
            <Button
              className = {'button extra_wide'}
              handleClick = {onClickCancel}
              label = {I18n.translate('Registeredcard.OK.Button.Label')}
            />
          </div>
        </div>
      </React.Fragment>
    );
  }

  renderDeleleRegisteredCardOverlay(): JSX.Element | null {
    const {handleConfirmDeleteRegisteredCardClick, onClickCancel, registeredCard} = this.props;
    return (
      <React.Fragment>
        <div className='page-title_medium--red font-s-24px t-bold--mobile text-width-20rem'>
        {I18n.translate('Registeredcard.Delete.Text')}
        </div>
        <div className='centered-text text-small t-strong no-bottom-margin'>
          {registeredCard ? I18n.translate(`Global.${registeredCard.paymentCard.toUpperCase()}`) : ''}<br />
        </div>
        <div className='centered-text text-small'>
          {registeredCard ? registeredCard.number : ''}
        </div>
        <div className='vertical_spacer x16'></div>
        <div className='l-flexbox-row l-flexbox-row--centered l-flexbox-row--mobile-column-reverse'>
          <Button
            className = {'button extra_wide full_width_on_mobile transparent_background'}
            handleClick = {onClickCancel}
            label = {I18n.translate('Registeredcard.Cancel.Button.Label')}
          />
          <Button
            className = {'button extra_wide full_width_on_mobile'}
            handleClick = {handleConfirmDeleteRegisteredCardClick}
            label = {I18n.translate('Registeredcard.Yes.Button.Label')}
          />
        </div>
      </React.Fragment>
    );
  }

  renderMainOverlay(): JSX.Element {
    const {step} = this.props;
    switch (step) {
      case 0 :
      return (
        <div className='popup-message-box'>
          {this.renderReplaceOrDeleteRegisterdCardOverlay()}
        </div>
      );
      case 1 :
      return (
        <div className='popup-message-box'>
          {this.renderDeleleRegisteredCardOverlay()}
        </div>
      );
      case 2 :
      case 3 :
      return (
        <div className='popup-message-box'>
          {this.renderSuccessOrErrorOverlay()}
        </div>
      );
      default:
      return (
        <Loader />
      );
    }
  }

  render(): React.ReactNode {
    return (
      <React.Fragment>
        <div className='overlay overlay--darker'></div>
        <div className='popup__container'>
          <div className='popup'>
            {this.renderMainOverlay()}
          </div>
        </div>
      </React.Fragment>
    )
  }
}

export default ReplaceOrDeleteRegisteredCard;