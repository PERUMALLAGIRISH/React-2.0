import * as React from 'react';
import {Loader} from '../../../components/Loader/Loader';
import {ProfileConstants} from '../ProfileConstants';

interface ProfileEmailValidationProps {
  title?: string;
  description?: string;
  buttonLabel?: string;
  result?: string;
  isLoading?: boolean;
  imgMailVerify: string | undefined;
  imgMailFailure: string | undefined;
  onClick? (event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void;
}

export class ProfileEmailValidation extends React.Component<ProfileEmailValidationProps> {
  constructor(props: ProfileEmailValidationProps) {
    super(props);
  }
  renderEmailValidation: () => JSX.Element = () => {
    const {isLoading, title, description, buttonLabel, onClick} = this.props;
    if (isLoading) {
      return <Loader />;
    }
    return (
      <React.Fragment>
        <h2 className='email__validation__title'>
          {title}
        </h2>
        <p className='email__validation__description'>
          {description}
        </p>
        <div className='form centered-text'>
          <button className='button button--flex cta-button' onClick={onClick}>
            <div className='button__button-content'>{buttonLabel}</div>
          </button>
        </div>
      </React.Fragment>);
  };

  renderSuccess: (result: string) => JSX.Element = (result: string) => {
    const {isLoading, title, description, imgMailVerify, imgMailFailure, buttonLabel, onClick} = this.props;
    const src: string = result === ProfileConstants.SUCCESS ? imgMailVerify || '' : imgMailFailure || '';
    if (isLoading) {
      return <Loader />;
    }
    return (
      <React.Fragment>
        <img className='content-box__link__icon--mail--verify' src= {src} />
        <p className='email__validation__description'>
          <span className='content-box__link__icon--mail--verify--text--strong'>{title}</span> {description}
        </p>
        <div className='form centered-text'>
          <button className='button' onClick={onClick}>
            <div className='button'>{buttonLabel}</div>
          </button>
        </div>
      </React.Fragment>);
  };
  render(): React.ReactNode {
    const {result} = this.props;
    return (
      <div className='content-box'>
        {result ? this.renderSuccess(result) : this.renderEmailValidation()}
      </div>
    )
  }
}
