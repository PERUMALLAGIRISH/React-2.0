/*eslint-env node */
//var users = require('../users.config');

var config = {

  'build': [
    'build-i18n',
    'build-scriptsBase'
  ],

	'build-i18n': [
		'concat:i18n',
		'properties:i18n',
		'properties_to_xml:i18n',
    'xmlstoke:i18n_tmp',
    'xmlstoke:i18n',
    'replace:lt'
	],

  'build-scriptsBase': [
		'concat:scriptsBase'
	]

};

module.exports = config;
