/*eslint-env node */

module.exports = function() {

	'use strict';

	return {

		i18n: {
			options: {
				namespace: 'ReactAppI18n'
			},
			files: [
				{
					expand: true,
					flatten: true,
					src: ['<%= cfg.dirs.messages %>/*.properties'],
					dest: '<%= cfg.dirs.dist %>/js',
					ext: '.js',
					extDot: 'last'
				}
			]
		}
	};
};
