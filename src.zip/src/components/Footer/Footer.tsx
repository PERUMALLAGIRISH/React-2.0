import './Footer.scss';
import * as React from 'react';

export class Footer extends React.Component {
  render(): React.ReactNode {
    return (
      <footer>
        <div className='container-fluid footer'>
          <div className='row'>
            <div className='col-md-12'>
              <ul className='pull-right list-unstyled'>
                <li>
                  <a href=''>Contact us</a>
                </li>
                <li>
                  © {new Date().getFullYear()} Sunrise Communications AG
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    )
  }
}
