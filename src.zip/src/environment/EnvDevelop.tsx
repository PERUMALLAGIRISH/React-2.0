export enum EnvDevelop {
  urlShopApi = 'https://www-t04.sunrise.ch/'
}