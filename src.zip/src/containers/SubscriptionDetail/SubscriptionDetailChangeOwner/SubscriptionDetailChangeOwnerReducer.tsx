import {
    ChangeOwnerAction,
    ChangeOwnerActionType,
    ChangeOwnerResetAction,
    SendChangeOwnerActionType,
    SendChangeOwnerAction,
    SendChangeOwnerErrorAction,
    SendChangeOwnerResetAction
  } from './SubscriptionDetailChangeOwnerAction';

export interface InitialState {
    changeOwner: any;
    sendChangeOwner: any;
    sendChangeOwnerError: any;
  }

const initialState: InitialState = {
    changeOwner: null,
    sendChangeOwner: null,
    sendChangeOwnerError: null
  };

type SubscriptionDetailChangeOwner = ChangeOwnerAction | ChangeOwnerResetAction | SendChangeOwnerAction | SendChangeOwnerErrorAction | SendChangeOwnerResetAction;

export default (state = initialState, action: SubscriptionDetailChangeOwner) => {
    switch (action.type) {
        case ChangeOwnerActionType.CHANGE_OWNER:
        return {
          ...state,
          changeOwner: action.payload
        };
      case ChangeOwnerActionType.RESET_CHANGE_OWNER:
        return {
          ...state,
          changeOwner: null
        };
      case SendChangeOwnerActionType.SEND_CHANGE_OWNER:
        return {
          ...state,
          sendChangeOwner: action.payload
        };
      case SendChangeOwnerActionType.SEND_CHANGE_OWNER_ERROR:
        return {
          ...state,
          sendChangeOwnerError: action.payload
        };
      case SendChangeOwnerActionType.RESET_CHANGE_OWNER:
        return {
          ...state,
          sendChangeOwner: null,
          sendChangeOwnerError: null
        };
      default:
        return state;
    }
  };
