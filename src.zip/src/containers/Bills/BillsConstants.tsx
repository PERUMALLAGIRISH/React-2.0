
export interface Map<T> {
    [key: string]: T;
}
export const BillsConstants: Map<any> = {
    REGISTER_CARD_AMOUNT  :   1,
    SUCCESS               : 'success',
    ERROR                 : 'error',
    PAYMENTSTATUS         : 'PaymentStatus',
    PAYMENTERROR          : 'PaymentError',
    PAYMENT_GATEWAY_ERROR : 'PaymentGatewayError',
    MANAGE_CREDITCARD     : 'ManageCreditCard',
    EDIT_PROFILE          : 'https://www-t04.sunrise.ch/mysunrise/en/residential/profile.html#/EditProfile',
    OVERDUE               : 'OVERDUE',
    DUNNED                : 'DUNNED'
}
export const BillsDueConstants: Map<string> = {
DUNNED          : 'DUNNED',
CH              :  'CH'
}
export const BillsPaymentMethodConstants: Map<any> = {
    IBAN            : 'iban',
    BANKNAME        : 'bankName',
    NAMEHOLDER      : 'nameHolder',
    ZIPCODE         : 'zipCode',
    CITY            : 'city',
    DOWNLOAD_URL    : '/users/current/site/billingprofile/lsv'
    }
export const BillsPayOutStandingConstants: Map<any> = {
    CREDITCARD            : 'creditCard',
    SUCCESS               : 'success',
    ERROR                 : 'error',
    PAYMENTSTATUS         : 'PaymentStatus',
    PAYMENTERROR          : 'PaymentError',
    PAYMENT_GATEWAY_ERROR : 'PaymentGatewayError',
    MANAGE_CREDITCARD     : 'ManageCreditCard',
    REGISTERED_CREDITCARD : 'registeredCreditCard',
    EBANKING              : 'eBanking',
    PAYINSLIP             : 'payInSlip',
    PAYPAL                : 'payPal'
    }
export const BillsDeliveryConstants: Map<string> = {
    EMAIL_WITH_LINK           : 'emailwithlink',
    EMAIL_WITH_PDF            : 'emaillinkwithpdf',
    PAPERBILL_WITHOUT_CALL    : 'paperbillwithoutcall',
    PAPERBILL_WITH_CALL       : 'paperbillwithcall',
    SHOW_MORE                 : 'Show more',
    EMAIL                     : 'email',
    ORDER_ACCOUNT             : 'orderAccount',
    POST                      : 'post'
}
