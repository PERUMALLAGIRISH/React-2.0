import gql from 'graphql-tag';
import { DocumentNode } from 'graphql';

const setBillDeliveryMethodMutation: DocumentNode = gql`
  mutation setBillDeliveryMethod($input: SetBillDeliveryMethodInput!) {
    setBillDeliveryMethod(input: $input) {
      payloadStatus
    }
  }
`;

export default setBillDeliveryMethodMutation;