import * as React from 'react';
import {Account, BillInfo, Optional, PaymentProvider, OrderAdditionalPaymentSlipInput, PayloadStatus, OrderAdditionalPaymentSlipPayload, PaymentInput, PaymentPayload} from '../../../model/types.d';
import {fetchBillsInfo, resetBills, setOrderAdditionalPaymentSlip} from '../BillsAction';
import {Dispatch, ActionCreatorsMapObject, bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {Loader} from '../../../components/Loader/Loader';
import {Button} from '../../../components/Form/Button/Button';
import {Success} from '../../../components/Success/Success';
import {Radio} from '../../../components/Radio/Radio';
import {fetchPaymentState, makePaymentRequest, makePaymentReset} from '../Payment/PaymentAction';
import {PaymentState} from '../../../model/client/PaymentState';
import {paymentService} from '../Payment/PaymentService';
import PaymentGateway from '../Payment/PaymentGateway';
import {PaymentMethodOption} from '../../../model/client/PaymentMethodOption';
import PaymentStatus from '../Payment/PaymentStatus/PaymentStatus';
import {RegisteredCard} from '../../../model/client/RegisteredCard';
import CurrencyFormatService from '../../../utils/CurrencyFormatService';
import I18n from '../../../utils/helper/I18n';
import {BillsPayOutStandingConstants} from '../BillsConstants';
import {BillsRoutes} from '../BillsRoutes.enum';
import {History} from 'history';

export interface BillsPayOutstandingProps {
  account: Account;
  accountError: Error;
  orderAdditionalPaymentSlip: OrderAdditionalPaymentSlipPayload;
  imgPaymentThankyou?: string;
  orderAdditionalPaymentSlipError: Error | null;
  fetchBillsInfo: () => void;
  resetBills: () => void;
  setOrderAdditionalPaymentSlip: (orderAdditionalPaymentSlipInput: OrderAdditionalPaymentSlipInput) => void;
  history: History;
  fetchPaymentState: (amount: number) => void;
  paymentState: PaymentState;
  makePaymentRequest: (paymentInput: PaymentInput) => void;
  makePaymentReset: () => void;
  makePayment: PaymentPayload | null;
  makePaymentError: Error | null;
  match: any;
}

interface BillsState {
  isLoading: boolean;
  isPopup: boolean;
  activeMethod: number;
  paymentMethod: string;
  isOSAmtChecked: boolean;
  payAmount: Optional<number>;
  successStatus: boolean;
  invokePayment: boolean;
  overlay: string;
  registerCardStep: number;
  isCreditCardSaved: boolean;
}

class BillsPayOutstanding extends React.Component<BillsPayOutstandingProps, BillsState> {
  constructor(props: BillsPayOutstandingProps) {
    super(props);
    this.state = {
      isLoading: true,
      isPopup: false,
      activeMethod: 1,
      paymentMethod: BillsPayOutStandingConstants.CREDITCARD,
      isOSAmtChecked: true,
      payAmount: 0,
      successStatus: false,
      overlay: '',
      registerCardStep: 0,
      invokePayment: false,
      isCreditCardSaved: true
    }
  }

  static getDerivedStateFromProps(nextProps: BillsPayOutstandingProps, prevState: BillsState): any | null {

    if ((nextProps.orderAdditionalPaymentSlip || nextProps.orderAdditionalPaymentSlipError || !prevState.successStatus) && (nextProps.account || nextProps.accountError) && prevState.isLoading) {
      return { isLoading: false };
    }
    return null;
  }

  componentDidMount(): void {
    const {fetchBillsInfo, makePaymentRequest, account} = this.props;
    if (!account) {
      fetchBillsInfo();
    }
    const paymentParams: any = paymentService.getPaymentParams(window.location.hash.substring(22));
    if (Object.keys(paymentParams).length > 0 && paymentParams.status === BillsPayOutStandingConstants.SUCCESS) {
      this.overlayListener(BillsPayOutStandingConstants.PAYMENTSTATUS);
      makePaymentRequest(paymentService.getPaymentInput(paymentParams, PaymentMethodOption.CREDIT_CARD));
    } else if (Object.keys(paymentParams).length > 0 && (paymentParams.status === BillsPayOutStandingConstants.ERROR)) {
      this.overlayListener(BillsPayOutStandingConstants.PAYMENTERROR);
    } else {
      this.overlayListener();
    }

  }

  componentWillUnmount(): void {
    const {resetBills} = this.props;
    resetBills();
  }

  overlayListener = (overlayId?: string): void => {
    const {match} = this.props;
    if (match && match.params && Object.keys(match.params).length > 0 && match.params.overlay && match.params.overlay !== '') {
      this.setState({
        overlay: match.params.overlay
      });
    } else if (overlayId && overlayId !== undefined) {
      this.setState({
        overlay: overlayId
      });
    }
  }

  closeOverlay = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void => {
    const {history} = this.props;
    history.push('/');
    this.setState({
      overlay: '',
      registerCardStep: 0
    });
  }

  renderPaymentSuccessOrError = (): string => {
    const {makePayment, makePaymentError} = this.props;
    if (makePayment && makePayment.payloadStatus && makePayment.payloadStatus === PayloadStatus.OK) {
      return I18n.translate('BillsPayOutstanding.Payment.Success.Description');
    } else if ((makePayment && makePayment.payloadStatus && makePayment.payloadStatus === PayloadStatus.NOK) ||
    (makePaymentError && makePaymentError !== null)) {
      return I18n.translate('BillsPayOutstanding.Payment.Error.Description');
    }
    return '';
  }

  renderOverlay = (): JSX.Element | null => {
    const {overlay} = this.state;
    switch (overlay) {
      case BillsPayOutStandingConstants.PAYMENTSTATUS:
        return (
          <PaymentStatus
            text = {this.renderPaymentSuccessOrError()}
            onClick = {this.closeOverlay}
          />
        );
      case BillsPayOutStandingConstants.PAYMENTERROR:
        return (
          <PaymentStatus
            text = {I18n.translate('BillsPayOutstanding.Payment.Error.Text')}
            onClick = {this.closeOverlay}
          />
        );
      case BillsPayOutStandingConstants.PAYMENT_GATEWAY_ERROR:
        return (
          <PaymentStatus
            text = {I18n.translate('BillsPayOutstanding.Payment.GateWayError.Text')}
            onClick = {this.closeOverlay}
          />
        );
      default:
        return null;
    }
  }

  getRegisteredCard = (): RegisteredCard | undefined => {
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account.billInfo;
    if (billInfo && billInfo.registeredCards &&
      billInfo.registeredCards.length > 0) {
      const registerCard: RegisteredCard = billInfo.registeredCards[0]!;
      return registerCard;
    }
  }

  onCancelled = () => {
    this.setState({
      invokePayment: false
    });
  }

  getRedirectUrls(): object {
    return {
      successUrl: window.location.href,
      errorUrl: window.location.href,
      cancelUrl: window.location.href
    };
  }

  getPaymentObject(paymentState: PaymentState): any {
    const {paymentMethod, isCreditCardSaved, payAmount} = this.state;
    const payOutstandingAmount: any = payAmount ? payAmount : 0 ;
    let paymentMethodOption: PaymentMethodOption = PaymentMethodOption.CREDIT_CARD;
    if (paymentMethod === BillsPayOutStandingConstants.PAYPAL) {
      paymentMethodOption = PaymentMethodOption.PAYMENT_SERVICE;
    } else if (paymentMethod === BillsPayOutStandingConstants.REGISTERED_CREDITCARD) {
      paymentMethodOption = PaymentMethodOption.REGISTERED_CARD;
    }
    return paymentService.getPaymentObject(paymentMethodOption, paymentState, this.getRedirectUrls(), isCreditCardSaved, payOutstandingAmount * 100);
  }

  handleOpenRegisterCardOverlay = (event: React.MouseEvent<HTMLButtonElement>) => {
    this.setState({
      invokePayment : true
    });
    const {payAmount} = this.state;
    const {fetchPaymentState} = this.props;
    const payOutstandingAmount: any = payAmount ? payAmount : 0;
    if (fetchPaymentState) {
      fetchPaymentState(payOutstandingAmount);
    }
  }

  handleScriptError = () => {
    return this.overlayListener(BillsPayOutStandingConstants.PAYMENT_GATEWAY_ERROR);
  }

  renderRegisterCardSection = (): JSX.Element => {
    return (
      <React.Fragment>
        <Button
          className = {'button extra_wide full_width_on_mobile'}
          handleClick = {(e: React.MouseEvent<HTMLButtonElement>) => this.handleOpenRegisterCardOverlay(e)}
          label = {I18n.translate('BillsPayOutstanding.Next.Button.Label')}
        />
      </React.Fragment>
    );
  }

  payAmount(event: React.MouseEvent<HTMLButtonElement>, step: number): void {
    event.preventDefault();
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account.billInfo;
    const totalOutstandingAmount: Optional<number> = billInfo && billInfo.totalOutstandingAmount;
    this.setState({
      activeMethod: step,
      payAmount: totalOutstandingAmount,
      isOSAmtChecked: true
    })
  }

  onRequestPayment(): JSX.Element | null {
    const {orderAdditionalPaymentSlipError, orderAdditionalPaymentSlip } = this.props;
    const {successStatus} = this.state;
    let label: string = '';
    let title: string = '';
    if (orderAdditionalPaymentSlipError !== null || (orderAdditionalPaymentSlip !== null && orderAdditionalPaymentSlip.payloadStatus === PayloadStatus.NOK)) {
      label = I18n.translate('BillsPayOutstanding.RequestPayment.Error.Label');
      title = I18n.translate('BillsPayOutstanding.RequestPayment.Error.Title');
    } else if (orderAdditionalPaymentSlip !== null && orderAdditionalPaymentSlip.payloadStatus === PayloadStatus.OK) {
      label = I18n.translate('BillsPayOutstanding.RequestPayment.Success.Label');
      title = I18n.translate('BillsPayOutstanding.RequestPayment.Success.Title');
    }
    if (successStatus) {
      return (
        <Success
          imageSource={'/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/payment_thankyou.png'}
          heading = {title}
          text = {label}
          button = {I18n.translate('BillsPayOutstanding.BackToBills.Button.Label')}
          href = {BillsRoutes.BILLS_SUCCESS}
        />
      );
    }
    return null;
  }

  requestPayment(event: React.MouseEvent<HTMLButtonElement>, step: number): void {
    event.preventDefault();
    const {payAmount} = this.state;
    const setOrderAdditionalPaymentSlipInput: OrderAdditionalPaymentSlipInput = {
        amount: payAmount
      };
    const {setOrderAdditionalPaymentSlip} = this.props;
    setOrderAdditionalPaymentSlip(setOrderAdditionalPaymentSlipInput);
    this.setState({
      activeMethod: step,
      successStatus: true,
      isLoading: true
    });
  }

  nextStep(event: React.MouseEvent<HTMLButtonElement>, step: number): void {
    event.preventDefault();
    this.setState({
      activeMethod: step
    })
  }

  handleCancel(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    const {history} = this.props;
    history.push({
      pathname: BillsRoutes.BILLS_HOME
    })
  }

  handlePayment(event: React.ChangeEvent<HTMLInputElement>, paymentMethod: string): void {
    this.setState({
      paymentMethod: paymentMethod
    });
  }

  handleOutstanding = (): void => {
    const {isOSAmtChecked} = this.state;
    this.setState({
      isOSAmtChecked: !isOSAmtChecked
    });
  }

  handleSavedCardChange = (): void => {
    const {isCreditCardSaved} = this.state;
    this.setState({
      isCreditCardSaved: !isCreditCardSaved
    });
  }

  renderAmount = (): JSX.Element | null => {
    const {activeMethod, isOSAmtChecked} = this.state;
    if (activeMethod === 1) {
      const {account} = this.props;
      const billInfo: Optional<BillInfo> = account.billInfo;
      const totalOutstandingAmount: Optional<number> = billInfo && billInfo.totalOutstandingAmount;
      return(
        <React.Fragment>
          <div className='title-large responsive_content_box'>
            {I18n.translate('BillsPayOutstanding.Payment.Open.Title')}
          </div>
          <div className='text-small centered-text responsive_content_box'>
          {I18n.translate('BillsPayOutstanding.Payment.PayBills.Title')}
          </div>
          <div className='vertical_spacer x32'></div>
          <div className='padding_15 partial-payment product_item product_item__grey_pink'>
            <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
              <div>
                <div className='text-small bold red'>
                  <input id='amount' type='checkbox'></input>
                  <label
                    className='checkbox__bck_img form_radio_label img__tickmark--square--grey inline t-bold text-small'
                    htmlFor='amount'
                    onClick={() => this.handleOutstanding()}
                  >{I18n.translate('BillsPayOutstanding.Payment.OutStanding.Title')}:</label>
                </div>
              </div>
            </div>
            <div className='product_item__price_2'>
              <div className='product_item__price_string'>{totalOutstandingAmount ? CurrencyFormatService.getCurrencyFormat(totalOutstandingAmount) : null}</div>
            </div>
          </div>
          <div className='vertical_spacer x32'></div>
          <div className='form-item'>
            <div className='form-item__button full_width_on_mobile'>
              <Button
                className= 'button extra_wide full_width_on_mobile transparent_background'
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.handleCancel(e)}
                label = {I18n.translate('BillsPayOutstanding.Cancel.Button.Label')}
              />
              <Button
                className= 'button extra_wide full_width_on_mobile'
                disabled= {isOSAmtChecked ? true : false }
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.payAmount(e, 2)}
                label = {I18n.translate('BillsPayOutstanding.Next.Button.Label')}
              />
            </div>
          </div>
        </React.Fragment>
      );
    } else {
      return null
    }
  }

  renderTransactionMethod = (id: string, name: string, status: boolean): JSX.Element => {
    return(
      <React.Fragment>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <div className='extra_margin_small'></div>
            <Radio
              id= {id}
              name={'transation'}
              className='text-small bold inline'
              checked= {status}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => this.handlePayment(e, id)}
              htmlFor={id}
              label={name}
            />
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'></div>
        </div>
      </React.Fragment>
    );
  }

  renderXmlSaveCard = (): JSX.Element => {
    const {isCreditCardSaved} = this.state;
    return(
      <div className='indented--checkbox padding_10 partial-payment product_item'>
        <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
          <div>
            <div className='text-small'>
              {isCreditCardSaved ?
                <input id='savedCard' type='checkbox' defaultChecked onChange = {(e: React.ChangeEvent<HTMLInputElement>) => this.handleSavedCardChange()}></input> :
                <input id='savedCard' type='checkbox' onChange = {(e: React.ChangeEvent<HTMLInputElement>) => this.handleSavedCardChange()}></input>
              }
              <label className='checkbox__bck_img form_radio_label img__tickmark--square--grey' htmlFor='savedCard'>
                <div className='text-small inline'>
                 {I18n.translate('BillsPayOutstanding.Payment.UpComing.Title')}
                </div>
              </label>
            </div>
          </div>
        </div>
        <div className='product_item__price_2'>
          <div className='product_item__price_string'></div>
        </div>
      </div>
    )
  }

  renderRegisterdCard = (): JSX.Element | null => {
    const {paymentMethod} = this.state;
    const registeredCard: RegisteredCard | undefined = this.getRegisteredCard();
    const expiryMonth:  number = registeredCard ? Number(registeredCard.expiryMonth) : 0;
    const expiryYear:   number = registeredCard ? Number(registeredCard.expiryYear) : 0;
    const currentDate: Date = new Date ();
    const currentMonth: number  = Number(currentDate.getMonth());
    const currentYear:  number =  Number(currentDate.getFullYear().toString().substring(2));
    let creditCardExpiredStatus: boolean = false;
    if ((expiryMonth && expiryMonth <= currentMonth) && (expiryYear && expiryYear <= currentYear)) {
      creditCardExpiredStatus = true;
    }
    if (registeredCard) {
      return(
        <div className='no-margin padding_10 product_item product_item__stiched_above'>
          <div className='product_item__content p-flexbox p-flex-column p-flex-justify-center'>
            <div>
              <Radio
                id= {BillsPayOutStandingConstants.REGISTERED_CREDITCARD}
                name={'transation'}
                className='text-small bold inline'
                checked= {paymentMethod === BillsPayOutStandingConstants.REGISTERED_CREDITCARD}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => this.handlePayment(e, BillsPayOutStandingConstants.REGISTERED_CREDITCARD)}
                htmlFor={BillsPayOutStandingConstants.REGISTERED_CREDITCARD}
              />
              <label className='form_radio_label' htmlFor={BillsPayOutStandingConstants.REGISTERED_CREDITCARD}>
                <div className='label-and-number'>
                  <div className='text-small bold'>
                    {I18n.translate('BillsPayOutstanding.Registered.CreditCard.Label')}
                  </div>
                  <span className='text-small pinkish-grey-two'>
                    {registeredCard.number}
                  </span>
                </div>
              </label>
              {creditCardExpiredStatus && paymentMethod === BillsPayOutStandingConstants.REGISTERED_CREDITCARD ? <div className='has-left-margin notice'>
                <img className='notice-icon' src={'/etc.clientlibs/mysunrise/clientlibs/react/resources/dist/img/new/error.svg'}/>
                <h2 className='notice-title'>
                  {I18n.translate('BillsPayOutstanding.CreditCard.Expired.Title')}
                </h2>
                <p className='notice-text'>
                 {I18n.translate('BillsPayOutstanding.CreditCard.Expired.Text')}
                </p>
              </div> : null}
            </div>
          </div>
        </div>
      )
    }
    return null;
  }

  renderPayment = (): JSX.Element | null => {
    const {activeMethod, paymentMethod} = this.state;
    const registeredCard: RegisteredCard | undefined = this.getRegisteredCard();
    if (activeMethod === 2) {
      return(
        <React.Fragment>
          <div className='title-large responsive_content_box'>
            {I18n.translate('BillsPayOutstanding.Payment.Pay.Title')}
          </div>
          <div className='text-small centered-text responsive_content_box'>
            {I18n.translate('BillsPayOutstanding.Payment.Method.Text')}
          </div>
          <div className='vertical_spacer x32'></div>
          <div className='border-top'></div>
          <div className='no-margin padding_10 product_item product_item__stiched_above'>
            {this.renderTransactionMethod('creditCard', I18n.translate('BillsPayOutstanding.Payment.CreditCard.Label'), paymentMethod === 'creditCard') }
          </div>
          {paymentMethod === 'creditCard' && !registeredCard ? this.renderXmlSaveCard() : null}
          {registeredCard !== undefined ? <div className='border-top'></div> : null}
          {registeredCard !== undefined ? this.renderRegisterdCard() : null}
          <div className='padding_15 product_item'>
            {this.renderTransactionMethod(BillsPayOutStandingConstants.EBANKING, I18n.translate('BillsPayOutstanding.Payment.EBanking.Label'), paymentMethod === BillsPayOutStandingConstants.EBANKING) }
          </div>
          <div className='padding_15 product_item product_item__stiched_bellow'>
            {this.renderTransactionMethod(BillsPayOutStandingConstants.PAYINSLIP, I18n.translate('BillsPayOutstanding.Payment.Slip.Label'), paymentMethod === BillsPayOutStandingConstants.PAYINSLIP) }
          </div>
          <div className='padding_15 product_item product_item__stiched_bellow'>
            {this.renderTransactionMethod(BillsPayOutStandingConstants.PAYPAL, I18n.translate('BillsPayOutstanding.Payment.PayPal.Label'), paymentMethod === BillsPayOutStandingConstants.PAYPAL) }
          </div>
          <div className='vertical_spacer x32'></div>
          <div className='form-item'>
            <div className='form-item__button full_width_on_mobile'>
              <Button
                className= 'button extra_wide full_width_on_mobile transparent_background'
                handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.nextStep(e, 1)}
                label = {I18n.translate('BillsPayOutstanding.Back.Button.Label')}
              />
              {paymentMethod === BillsPayOutStandingConstants.CREDITCARD || paymentMethod === BillsPayOutStandingConstants.PAYPAL || paymentMethod === BillsPayOutStandingConstants.REGISTERED_CREDITCARD ?
                this.renderRegisterCardSection() :
                <Button
                  className= 'button extra_wide full_width_on_mobile'
                  handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.nextStep(e, 3)}
                  disabled= {paymentMethod === '' ? true : false }
                  label = {I18n.translate('BillsPayOutstanding.Next.Button.Label')}
                />
              }
            </div>
          </div>
        </React.Fragment>
      )
    } else {
      return null
    }
  }

  payInSlip = (): JSX.Element => {
    return(
      <React.Fragment>
        <div className='title-large responsive_content_box'>
          {I18n.translate('BillsPayOutstanding.Transaction.Label')}
        </div>
        <div className='text-small centered-text responsive_content_box'>
          {I18n.translate('BillsPayOutstanding.Payment.Slip.Description')}
        </div>
        <div className='vertical_spacer x32'></div>
        <div className='form-item'>
          <div className='form-item__button full_width_on_mobile'>
            <Button
              className= 'button extra_wide full_width_on_mobile transparent_background'
              handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.nextStep(e, 2)}
              label = {I18n.translate('BillsPayOutstanding.Back.Button.Label')}
            />
            <Button
              className= 'button extra_wide full_width_on_mobile'
              handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.requestPayment(e, 0)}
              label = {I18n.translate('BillsPayOutstanding.Request.PaySlip.Label')}
            />
          </div>
        </div>
      </React.Fragment>
    )
  }

  eBankingAccount = (): JSX.Element => {
    return(
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
        <div className='content-box no-bottom-margin'>
          <div className='form'>
            <div className='form-item'>
              <div className='form__label'>
                {I18n.translate('BillsPayOutstanding.Bills.Information.Text')}
              </div>
              <div className='form__text'>
                {I18n.translate('BillsPayOutstanding.Account.Label')} {I18n.translate('BillsPayOutstanding.Account.Text')}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  eBankingPayment = (): JSX.Element => {
    return(
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
        <div className='content-box no-bottom-margin'>
          <div className='form'>
            <div className='form-item'>
              <div className='form__label'>
                {I18n.translate('BillsPayOutstanding.PaymentFor.Label')}
              </div>
              <div className='form__text'>
                {I18n.translate('BillsPayOutstanding.CompanyName.Text')}<br/>
                {I18n.translate('BillsPayOutstanding.Address.Street.Text')} {I18n.translate('BillsPayOutstanding.Address.Number.Text')}<br/>
                {I18n.translate('BillsPayOutstanding.Location.Zip.Text')} {I18n.translate('BillsPayOutstanding.Location.City.Text')}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  eBankingAmount = (): JSX.Element => {
    const {payAmount} = this.state;
    return(
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
        <div className='content-box'>
          <div className='form'>
            <div className='form-item'>
              <div className='form__label'>
                {I18n.translate('BillsPayOutstanding.Amount.Label')}
              </div>
              <div className='form__text'>
                {payAmount}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  eBankingReference = (): JSX.Element => {
    const {paymentState} = this.props;
    const paymentProvider: Optional<PaymentProvider> = paymentState && paymentState.paymentProvider;
    return(
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
        <div className='content-box'>
          <div className='form'>
            <div className='form-item'>
            <div className='form__label'>
              {I18n.translate('BillsPayOutstanding.Reference.Label')}
            </div>
            <div className='form__text hyphens'>
              {paymentProvider.referenceNumber}
            </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  eBanking = (): JSX.Element => {
    return(
      <React.Fragment>
        <div className='title-large responsive_content_box'>
          {I18n.translate('BillsPayOutstanding.Transactions.Title')}
        </div>
        <div className='text-small centered-text responsive_content_box'>
          {I18n.translate('BillsPayOutstanding.Billing.Information.Title')}
        </div>
        <div className='l-flexbox-row'>
          {this.eBankingAccount()}
          { this.eBankingPayment()}
        </div>
        <div className='l-flexbox-row'>
          {this.eBankingAmount()}
          {this.eBankingReference()}
        </div>
        <div className='vertical_spacer x32'></div>
        <div className='form-item'>
          <div className='form-item__button full_width_on_mobile'>
            <Button
              className= 'button extra_wide full_width_on_mobile transparent_background'
              handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.nextStep(e, 2)}
              label = {I18n.translate('BillsPayOutstanding.Back.Button.Label')}
            />
            <Button
              className= 'button extra_wide full_width_on_mobile'
              handleClick= {(e: React.MouseEvent<HTMLButtonElement>) => this.handleCancel(e)}
              label = {I18n.translate('BillsPayOutstanding.Done.Button.Label')}
            />
          </div>
        </div>
      </React.Fragment>
    )
  }

  renderTransaction = (): JSX.Element | null => {
    const {activeMethod, paymentMethod} = this.state;
    if (activeMethod === 3) {
      switch (paymentMethod) {
        case BillsPayOutStandingConstants.PAYINSLIP: {
          return  (
            <React.Fragment>
              {this.payInSlip()}
            </React.Fragment>
          );
          break;
        }
        case BillsPayOutStandingConstants.EBANKING: {
          return  (
            <React.Fragment>
              {this.eBanking()}
            </React.Fragment>
          );
          break;
        }
        default: {
          return null;
          break;
        }
      }
    } else {
      return null
    }
  }

  renderProgressStep = (step: number, method: string): JSX.Element => {
    const {activeMethod} = this.state;
    let className: string = 'progress_step_sign inline_progress_sign progress_step_number--small progress_tracker__break_words';
    if (activeMethod === step) {
      className = 'progress_step_sign inline_progress_sign progress_step_number--mobile-small progress_tracker__break_words';
    }
    return(
      <div className= {className}>
        <div className='progress_step_number'>
          {step}
        </div>
        <div className='progress_step_title text-small bold width-auto'>
          {method}
        </div>
      </div>
    )
  }

  renderProgressBar = (): JSX.Element => {
    return(
      <div className='progress_tracker centered-text'>
        {this.renderProgressStep(1, I18n.translate('BillsPayOutstanding.Amount.Label'))}
        <div className='progress_tracker__dash'></div>
        {this.renderProgressStep(2,  I18n.translate('BillsPayOutstanding.PaymentMethod.Title'))}
        <div className='progress_tracker__dash'></div>
        {this.renderProgressStep(3,  I18n.translate('BillsPayOutstanding.Transaction.Label'))}
      </div>
    )
  }

  renderPaymentSteps = (): JSX.Element | null => {
    const {successStatus} = this.state;
    if (!successStatus) {
      return (
        <React.Fragment>
          {this.renderProgressBar()}
          {this.renderAmount()}
          {this.renderPayment()}
          {this.renderTransaction()}
        </React.Fragment>
      )
    } else {
      return (
        <React.Fragment>
          {this.onRequestPayment()}
        </React.Fragment>
      )
    }
  }

  renderPaymentGateway = (): JSX.Element | null => {
    const {paymentState} = this.props;
    const {invokePayment} = this.state;
    if (invokePayment) {
      return(
        <PaymentGateway
          invokePayment = {invokePayment}
          paymentScriptUrl = {paymentService.getPaymentScriptUrl(paymentState)}
          formId = {'paymentForm'}
          paymentObject = {this.getPaymentObject(paymentState)}
          handleScriptError = {this.handleScriptError}
          onCancelled = {this.onCancelled}
        />
      )
    }
    return null
  }
  render(): React.ReactNode {
    const {account} = this.props;
    const {isLoading} = this.state;
    if (isLoading) {
      return (<Loader />);
    }
    if (account) {
      return (
        <div className='l-center-l'>
          <div className='l-grid'>
            <div className='l-col l-1of1'>
              <div className='content-box small_content_box'>
                {this.renderPaymentSteps()}
              </div>
              {this.renderOverlay()}
              {this.renderPaymentGateway()}
            </div>
          </div>
        </div>
      )
    }
  }
}

const mapStateToProps: any = ({ billsReducer, registeredCardReducer, paymentReducer }: any) => {
  return {
    account: billsReducer.account,
    accountError: billsReducer.accountError,
    orderAdditionalPaymentSlip: billsReducer.orderAdditionalPaymentSlip,
    orderAdditionalPaymentSlipError: billsReducer.orderAdditionalPaymentSlipError,
    paymentState: paymentReducer.paymentState,
    makePayment: paymentReducer.makePayment,
    makePaymentError: paymentReducer.makePaymentError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({fetchBillsInfo, resetBills, setOrderAdditionalPaymentSlip, fetchPaymentState, makePaymentRequest, makePaymentReset}, dispatch);
};

export default connect<BillsPayOutstandingProps>(mapStateToProps, mapDispatchToProps)(BillsPayOutstanding);