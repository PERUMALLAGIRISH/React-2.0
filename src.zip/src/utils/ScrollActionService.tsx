/*
    @Docs
    behavior (Optional) ->
        Defines the transition animation.
        One of "auto" or "smooth". Defaults to "auto".

    block (Optional) ->
        Defines vertical alignment.
        One of "start", "center", "end", or "nearest". Defaults to "center".

    inline (Optional) ->
        Defines horizontal alignment.
        One of "start", "center", "end", or "nearest". Defaults to "nearest"

    Example: element.scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"});
*/

class ScrollActionService {
    scrollAction = (elementClassName: string, options: object): void => {
        if (elementClassName === '' || elementClassName === undefined) {
            return;
        }
        const element: Element | null = document.querySelector(elementClassName);
        if (element) {
          element.scrollIntoView(options);
        }
    }
}

export default new ScrollActionService();