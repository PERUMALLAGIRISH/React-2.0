import { PaymentMethodOption } from './PaymentMethodOption';
import { PaymentProvider } from './PaymentProvider';
import { RegisteredCard } from './RegisteredCard';

export interface PaymentState {
  paymentMethods: PaymentMethodOption[]
  paymentProvider: PaymentProvider
  registeredCards: RegisteredCard[]
}