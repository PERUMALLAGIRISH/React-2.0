import * as React from 'react';
declare let window: any;

interface I18nRendererOptions {
  code: string;
  arguments?: string;
  argumentsSplitter?: string;
}

export default class I18nRenderer extends React.Component<I18nRendererOptions> {

  constructor(props: I18nRendererOptions) {
    super(props);
  }

  i18n = () => {
    const code: string = this.props.code;

    // if (ReactApp.Env && ReactApp.Env.debug && ReactApp.DebugI18n) {
    //   return this.setArguments('Key: ' + code);
    // }

    // if (typeof(code) !== 'string') {
    //   if (typeof(console) === 'object') {
    //     /*eslint-disable */
    //     console.error('I18n: prop code required (code="#code#")');
    //     /*eslint-enable */
    //   }
    // }

    // if (typeof(window.ReactAppI18n) !== 'object') {
    //   if (typeof(console) === 'object') {
    //     /*eslint-disable */
    //     console.log('I18n: no property file found for code: '+code);
    //     /*eslint-enable */
    //   }
    //   return code;
    // }

    let value: string = window.ReactAppI18n[code];
    if (typeof(value) !== 'string') {
      // if (typeof(console) === 'object') {
      //   /*eslint-disable */
      //   console.error('I18n: no key "'+code+'" found!');
      //   /*eslint-enable */
      // }
      return code;
    }
    value = this.setArguments(value);
    return value;
  }

  setArguments = (value: string) => {
    const args: string = this.props.arguments || '';
    let splitter: string = ',';
    // if value === --empty--
    // return empty string, otherwise regular behaviour
    if (value === '--empty--') {
      value = '';
    } else {
      if (typeof(args) !== 'string') {
        return value;
      }

      if (typeof(this.props.argumentsSplitter) === 'string') {
        splitter = this.props.argumentsSplitter;
      }
      const arg: Array<string> = args.split(splitter);

      arg.map((argument: string, index: number) => {
        value = value.replace('{' + index + '}', argument);
      });
    }

    return value;
  }
}
