import * as React from 'react';
import I18nRenderer from '../../utils/helper/I18nRenderer';

interface I18nProps {
  code: string;
  arguments?: string;
  argumentsSplitter?: string;
}

interface I18nState {
}

export default class I18n extends React.Component<I18nProps, I18nState> {
  constructor(props: I18nProps) {
    super(props);
  }

  static translate = (code: string, args?: string, argsSplitter?: string) => {
    const i18nProps: any = {
      code: code,
      arguments: args,
      argumnetsSplitter: argsSplitter
    };
    const i18nRenderer: I18nRenderer = new I18nRenderer(i18nProps);
    return i18nRenderer.i18n();
  }

  render(): React.ReactNode {
    const i18nRenderer: I18nRenderer = new I18nRenderer(this.props);
    const value: any = {__html: i18nRenderer.i18n()};
    return (
      <div dangerouslySetInnerHTML={value}/>
    )
  }
}
