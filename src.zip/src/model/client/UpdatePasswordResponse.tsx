import { UpdatePasswordPayload } from '../../model/types.d';
export interface UpdatePasswordResponse {
    updatePassword: UpdatePasswordPayload;
}