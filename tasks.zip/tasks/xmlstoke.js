/*eslint-env node */

module.exports = function(grunt) {

	'use strict';

	return {
    i18n_tmp: {
      options: {
        namespaces: {
          'sling': 'http://sling.apache.org/jcr/sling/1.0',
          'jcr': 'http://www.jcp.org/jcr/1.0'
        },
        actions: [{
          type: 'C',
          xpath: '/',
          node: 'jcr:root',
          value: function (node) {
            var text = '';
            var childNodes = node.childNodes;
            for (var i = 0; i < node.childNodes.length; i++) {
              var innerText = '';
              var element = '';
              var childNode = childNodes.item(i);
              if(childNode.attributes != null && childNode.attributes.getNamedItem("key") != null) {
                element = childNode.attributes.getNamedItem("key").value;
                innerText += ' jcr:mixinTypes="[sling:Message]"';
                innerText += ' jcr:primaryType="nt:folder"';
                innerText += ' sling:key="' + element + '"';
                innerText += ' sling:message="';
                for (var j = 0; j < childNode.childNodes.length; j++) {
                  innerText += childNode.childNodes[j];
                }
                innerText += '"';
                text += "<" + element + " " + innerText + " />";
              }
            }
            return text;
          }
        },
        {
          type: 'R',
          xpath: '/jcr:root',
          saveAs: 'myFoo'
        }]
      },
      files: {
        '<%= cfg.dirs.messages %>/React-tmp.xml': '<%= cfg.dirs.messages %>/ReactApp.I18n.xml'
      }
    },

    i18n: {
      options: {
        namespaces: {
          'sling': 'http://sling.apache.org/jcr/sling/1.0',
          'jcr': 'http://www.jcp.org/jcr/1.0'
        },
        actions: [{
          xpath: '/jcr:root',
          value: function (node) { return grunt.option('myFoo'); }
        }]
      },
      files: {
        '<%= cfg.dirs.distTranslations %>/React.xml': '<%= cfg.dirs.messages %>/React.xml'
      }
    }
	};
};
