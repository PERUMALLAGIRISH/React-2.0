export enum BillsRoutes {
    BILLS_HOME = '/',
    BILLS_SUCCESS = '#/',
    BILLS_PAYMENT_METHOD = '/PaymentMethod',
    BILLS_PAY_OUTSTANDING    =  '/BillsPayOutstanding',
    BILLS_DELIVERY = '/Billsdelivery'
  }